#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("char's memory size: %d byte\n", sizeof(char));
    printf("short's memory size: %d bytes\n", sizeof(short));
    printf("float's memory size: %d bytes\n", sizeof(float));
    printf("double's memory size: %d bytes", sizeof(double));

    return 0;
}
