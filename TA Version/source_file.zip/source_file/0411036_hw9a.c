#include <stdio.h>

int SUM(int n);

int main(){
    int n;
	scanf("%d", &n);
	printf("%d\n", SUM(n));
}

int SUM(int n){
	return (n == 1) ? 1 : n+SUM(n-1);
}
