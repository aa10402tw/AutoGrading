#include <stdio.h>

int GCD(int,int);

int main(){
   int n1,n2;
   scanf("%d %d",&n1,&n2);
   printf("%d",GCD(n1,n2));
   return 0;
}

int GCD(int m,int n){
    if(n==0){
        return m;
    }else{
        return GCD(n,m%n);
    }
}
