#include <stdio.h>

void hanoi(int num,char a,char b,char c/* Write your code here */);
int k=0;
int main() {
    char a,b,c;
    int n;
    scanf("%d",&n);
    hanoi(n,a,b,c);
    printf("%d",k);
    return 0;
    /* Write your code here */
}

void hanoi(int num,char a,char b,char c/* Write your code here */){
     if(num>0){
        num=num-1;
        hanoi(num,a,c,b);
        k++;
        hanoi(num,b,a,c);
    }


    /* Write your code here */
}
