#include <stdio.h>

int SUM(/* Write your code here */ int n);

int main(){
	/* Write your code here */
	int n;
	scanf("%d",&n);
	printf("%d",SUM(n));
	return 0;
}

int SUM(/* Write your code here */ int n){
	/* Write your code here */
	if(n>0) return n+SUM(n-1);
	else return 0;
}
