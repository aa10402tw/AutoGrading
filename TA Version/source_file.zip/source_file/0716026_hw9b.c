#include <stdio.h>

int GCD(/* Write your code here */int ,int);

int main(){
   /* Write your code here */
   int a,b;
   scanf("%d %d",&a,&b);
   printf("%d",GCD(a,b));
   return 0;
}

int GCD(/* Write your code here */int a,int b){
    /* Write your code here */
    if(a>b)
    {
    	return GCD(a-b,b);
	}
	else if(a<b)
	{
		return GCD(a,b-a);
	}
	else if(a==b)
	{
		return a;
	}
}
