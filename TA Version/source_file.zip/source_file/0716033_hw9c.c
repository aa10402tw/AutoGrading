#include <stdio.h>


int binary_search(/* Write your code here */int L, int R, int target, int a[]);

int main(void){
	/* Write your code here */
	int n, a[101]={0}, target, i, j, c;
	scanf("%d", &n);
	for(i=0;i<n;i++)
        scanf("%d", &a[i]);
    for(i=n-1; i>0; i--)
    {
        for(j=0; j<i; j++)
        {
            if(a[j]>a[j+1])
            {
                c=a[j];
                a[j]=a[j+1];
                a[j+1]=c;
            }
        }
    }
    scanf("%d", &target);
    printf("%d", binary_search(0, n-1, target, a));
    return 0;
}

int binary_search(/* Write your code here */int L, int R, int target, int a[]){
   /* Write your code here */
    if(R>=L)
    {
        int mid=(L+R)/2;
        if(a[mid]==target)
            return mid;
        else if(target>a[mid])
        {
            return binary_search(mid+1, R, target, a);
        }
        else if(target<a[mid])
        {
            return binary_search(0, mid-1, target, a);
        }
    }
    else if(a[0]==target)
        return 0;
    return -1;
}
