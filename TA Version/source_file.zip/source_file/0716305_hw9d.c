#include <stdio.h>

void hanoi(int,char,char,char);

int time=0;

int main() {
    int num;
    scanf("%d",&num);
    hanoi(num,'A','B','C');
    printf("%d",time);
    return 0;
}

void hanoi(int n,char A,char B,char C){
     if(n==1){
        time++;
     }else{
        time++;
        hanoi(n-1,A,C,B);
        hanoi(n-1,B,A,C);
     }
}
