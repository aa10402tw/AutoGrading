#include <stdio.h>

int P ( int n ) {
	if ( n == 1 ) 
	 return 1 ;
	else
	 return ( 2 * P(n-1) + 1 ) ;
}

int main () {
	int n ;
	scanf ("%d", &n) ;
	printf ("%d", P(n)) ;
}
