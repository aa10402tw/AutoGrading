#include <stdio.h> 
#include <stdlib.h>
int binary_search(/* Write your code here */int *a,int l,int r,int tar);
int cmp(const void *a,const void *b){return *(int *)a-*(int *)b;}
int main(void){ 
	/* Write your code here */
	int n;
	scanf("%d",&n);
	int arr[n];
	for(int a=0;a<n;a++)scanf("%d",&arr[a]);
	qsort(arr,n,sizeof(int),cmp);
	int tar;
	scanf("%d",&tar);
	printf("%d\n",binary_search(arr,0,n,tar));
	return 0;
}

int binary_search(/* Write your code here */int *a,int l,int r,int tar){ 
   /* Write your code here */
	if(l==r||l>r){
		if(a[l]==tar)return l;
		return -1;
	}
	int m=(l+r)/2;
	if(a[m]==tar) return m;
	else if(a[m]>tar) return binary_search(a,l,m-1,tar);
	else return binary_search(a,m+1,r,tar);
}
