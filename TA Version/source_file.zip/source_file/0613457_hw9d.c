#include <stdio.h>

void hanoi(int *k,int n);

int main() {
    int n,k=0;
    //printf(":");
    scanf("%d",&n);
    hanoi(&k, n);
    printf("%d\n",k);
}

void hanoi(int *k,int n){
    if (n==1) {
        (*k)++;
    }else{
        hanoi(k,n-1);
        hanoi(k,1);
        hanoi(k,n-1);
    }
}
