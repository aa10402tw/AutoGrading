#include <stdio.h>

int binary_search(int num[],int target,int L,int R);

int main(void){
	int n;
	scanf("%d",&n);
	int num[n];
	for(int i=0;i<n;i++){
        scanf("%d",&num[i]);
	}
	int target;
	int temp;
    for(int i=0;i<n;i++){
        for(int j=0;j<n-1;j++){
            if(num[j]>num[j+1]){
                temp=num[j];
                num[j]=num[j+1];
                num[j+1]=temp;
            }
        }
    }
	scanf("%d",&target);
	printf("%d",binary_search(num,target,0,n-1));
}

int binary_search(int num[],int target,int L,int R){

    if(num[(L+R)/2]==target){
        return (L+R/2);
    }
    else if(num[(L+R)/2+1]==target){
        return (L+R)/2+1;
    }
    else if(R-L<=1){
        return -1;
    }
    else if(num[(L+R)/2]>target){
        return binary_search(num,target,L,(L+R)/2);
    }
    else if(num[(L+R)/2]<target){
        return binary_search(num,target,(L+R)/2,R);
    }
}
