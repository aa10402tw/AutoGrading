#include <stdio.h>

int SUM(int N/* Write your code here */);

int main(){
	/* Write your code here */
	int N;

    scanf("%d",&N);
	printf("%d",SUM(N));

	return 0;
}

int SUM(int N/* Write your code here */){
	/* Write your code here */
	if(N==1)
    {
        return 1;
    }
    else
    {
        return SUM(N-1)+N;
    }
}
