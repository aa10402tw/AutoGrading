#include <stdio.h>
int times=1;
void hanoi(int n);

int main() {
    int n;
    scanf("%d",&n);
    hanoi(n);
    return 0;
}

void hanoi(int n){
    if(n==1){
        printf("%d\n",times);
        return;
    }
    times=times*2+1;
    hanoi(n-1);
}
