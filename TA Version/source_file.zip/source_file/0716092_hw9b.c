#include <stdio.h>

int GCD(int a,int b/* Write your code here */);

int main(){
    int a,b;
    scanf("%d%d",&a,&b);
    printf("%d",GCD(a,b));
   /* Write your code here */
}

int GCD(int a,int b/* Write your code here */){
    /* Write your code here */
    if(b==0) return a;
    else return GCD(b,a%b);

}
