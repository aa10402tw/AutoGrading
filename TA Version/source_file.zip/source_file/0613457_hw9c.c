#include <stdio.h>

int binary_search(int R,int L,int *n,int N);
void b_sort(int *a,int l);

int main(void){
    int n[100]={},N,l;
    //printf(":");
    scanf("%d",&l);
    for (int i=0; i<l; i++) {
        scanf("%d",n+i);
    }
    scanf("%d",&N);
    b_sort(n,l);
    printf("%d\n",binary_search(0, l-1, n, N));
    return 0;
}

int binary_search(int L,int R,int *n,int N){
    int M=(R-L)/2+L;
    if (L>R) {
        return -1;
    }else if (n[M]==N){
        return (R-L)/2+L;
    }else if(n[M]>N){
        return binary_search(L,M-1,n,N);
    }else{
        return binary_search(M+1,R,n,N);
    }
}
void b_sort(int *a,int l){
    for (int i=l-1; i>=0; i--) {
        for (int j=0; j<i; j++) {
            if (a[j]>a[j+1]) {
                int tmp;
                tmp=a[j+1];
                a[j+1]=a[j];
                a[j]=tmp;
            }
        }
    }
}
