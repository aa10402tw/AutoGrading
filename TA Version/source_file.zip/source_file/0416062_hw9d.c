#include <stdio.h>

void hanoi(int n,int l,int s);

int main() {
    int n;

    scanf("%d",&n);
    hanoi(n,1,1);
}

void hanoi(int n,int l,int s){
    if(l==n)
    {
        printf("%d",s);
    }
    else
    {
        hanoi(n,l+1,2*s+1);
    }

}
