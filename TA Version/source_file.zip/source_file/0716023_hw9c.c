#include <stdio.h>
#include <stdlib.h>

int binary_search(int *array, int left, int right, int target);
int compar(const void *a, const void *b);

int compar(const void *a, const void *b)
{
    int na = *(int *)a;
    int nb = *(int *)b;
    return na < nb ? -1 : 1;
}

int main(void)
{
    int len;
    scanf("%d", &len);

    int array[len];
    int i;
    for (i = 0; i < len; i++)
    {
        scanf("%d", array + i);
    }
    qsort(array, len, sizeof(int), compar);

    int target;
    while (scanf("%d", &target) != EOF)
    {
        printf("%d\n", binary_search(array, 0, len, target));
    }
}

int binary_search(int *array, int left, int right, int target)
{
    int d = right - left;
    if (d == 1)
    {
        if (array[left] == target)
            return left;
        if (array[right] == target)
            return right;
        return -1;
    }
    if (d == 0)
    {
        return array[left] == target ? left : -1;
    }

    int mid = (left + right) / 2;
    if (array[mid] == target)
        return mid;

    return array[mid] > target ? binary_search(array, left, mid, target) : binary_search(array, mid, right, target);
}