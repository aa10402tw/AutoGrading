#include <stdio.h>

void hanoi(int n);
int t=0;
int main() {
	int n;
    scanf("%d",&n);
    hanoi(n);
    printf("%d",t);
} 

void hanoi(int n){
    if(n==1)
        t++;
    
    else{
        hanoi(n-1);
		hanoi(1);
		hanoi(n-1);
	}
}

