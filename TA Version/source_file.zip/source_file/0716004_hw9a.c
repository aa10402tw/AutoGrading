//
//  main.c
//  0716004_hw9a.c
//
//  Created by 成文瑄 on 2018/11/20.
//  Copyright © 2018年 成文瑄. All rights reserved.
//

#include <stdio.h>

int SUM( int n);

int main(){
    /* Write your code here */
    int n;
    scanf("%d", &n);
    printf("%d", SUM(n));
    
    
}

int SUM( int n){
    /* Write your code here */
    if( n==1)
        return 1;
    else
        return n+SUM(n-1);
}

