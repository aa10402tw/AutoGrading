#include <stdio.h>

int binary_search(int a[],int m,int n,int k/* Write your code here */);

int main(void){
    int n;
    scanf("%d",&n);
    int a[n];
    for(int i=0;i<n;i++)scanf("%d",&a[i]);
    int ch1=0,ch2=0;
    for(int i=0;i<n;i++)
    {
        ch1=a[i],ch2=i;
        for(int j=i;j<n;j++)
        {
            if(ch1>a[j])ch2=j,ch1=a[j];
        }
        a[ch2]=a[i],a[i]=ch1;
    }
    int index;
    scanf("%d",&index);

    printf("%d",binary_search(a,0,n-1,index));
	/* Write your code here */
}

int binary_search(int a[],int m,int n,int k/* Write your code here */){
   if((n-m)==1)
   {
       if(a[m]==k)return m;
       else if(a[n]==k)return n;
       else return -1;
   }
   else if(a[(m+n)/2]>k)return binary_search(a,m,(m+n)/2,k);
   else if(a[(m+n)/2]<k)return binary_search(a,(m+n)/2,n,k);/* Write your code here */
   else if(a[(m+n)/2]==k)return (m+n)/2;
}
