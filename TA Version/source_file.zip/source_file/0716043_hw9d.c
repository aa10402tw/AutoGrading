#include <stdio.h>

void hanoi(int);
int result;
int main()
{
    int input;
    scanf("%d", &input);
    hanoi(input);
    printf("%d",result);
    return 0;
}

void hanoi(int n)
{
    if(n == 0)
        return;
    else
    {
        hanoi(n - 1);
        result++;
        hanoi(n - 1);
    }
}
