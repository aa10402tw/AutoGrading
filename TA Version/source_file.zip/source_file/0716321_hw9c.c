#include <stdio.h> 
#include <stdlib.h>
int binary_search(int a,int *num,int r,int l,int times);
int binary_search(int a,int *num,int l,int r,int times){ 
    int pos=(r+l)/2;
    if(a==num[pos]) 
        return pos;
    else if(r < 1||l>times)
        return -2;
    else if(a>num[pos]) 
        return binary_search(a,num,pos+1,r,times);
    else 
        return binary_search(a,num,l,pos-1,times);
        
}
int cmp(const void*a,const void*b){
    return *(int *)a>*(int *)b?1:-1;
}
int main(void){ 
	int times,a;
    scanf("%i",&times);
    int num[times];
    for(int i = 0;i<times;i++)
        scanf("%i",&num[i]);
    qsort(num,times,4,cmp);
    scanf("%i",&a);
    printf("%i\n",binary_search(a,num,0,times,times));
}


