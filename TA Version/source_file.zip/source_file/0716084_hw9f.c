#include <stdio.h>

void queens(/* Write your code here */);

int main(){ 
    /* Write your code here */
}

void queens(/* Write your code here */){
    /* Write your code here */
}