#include<stdio.h>

int gcd(int,int);
void swap(int*,int*);

int main(void)
{
    int big,small;
    scanf("%d%d",&big,&small);
    swap(&big,&small);
    printf("%d",gcd(big,small));

    return 0;
}

int gcd(int a,int b)
{
    if(b==0)
        return a;
    while(a>=b)
        a-=b;
    return gcd(b,a);
}

void swap(int*a,int*b)
{
    int t;
    if(*a<*b)
    {
        t=*a;
        *a=*b;
        *b=t;
    }
}
