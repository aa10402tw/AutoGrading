#include <stdio.h>

int binary_search(int target,int input[],int result,int len);

int main(void){
	int len,target;
	scanf("%d",&len);
	int input[len+1];
	for(int i=0;i<len;i++)
        scanf("%d",input+i);
    scanf("%d",&target);
    for(int i=0;i<len;i++){
        for(int j=1;j<len;j++){
            if(input[j-1]>input[j]){
                char temp=input[j];
                input[j]=input[j-1];
                input[j-1]=temp;}}}
    printf("%d",binary_search(target,input,0,len));
    return 0;
}

int binary_search(int target,int input[],int result,int len){
    if(input[result]==target)
        return result;
    else if(result==len)
        return -1;
    else{
        result++;
        binary_search(target,input,result,len);
    }
}
