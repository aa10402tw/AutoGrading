#include <stdio.h>
#define max(a,b) a>b? a:b
#define min(a,b) a<b? a:b
int GCD(int a, int b);

int main(){
   int a,b;
   scanf("%d%d",&a,&b);
   printf("%d\n",GCD(a,b));
   return 0;
}

int GCD(int a, int b){
    int dividend=max(a,b),divisor=min(a,b),remainder=dividend%divisor;
    if(remainder==0)
      return divisor;
    
    return GCD(divisor,remainder);
}