#include <stdio.h>

int SUM(int n);

int main(){
	int n;
	scanf("%d",&n);
	printf("%d",SUM(n));
	return 0;
}

int SUM(int n){
	int sum=1;
	int i;
	if(n==1) return 1;
	sum=SUM(n-1)+n;
	return sum;
}
