#include <stdio.h>

void sort(int *a,int n);

int binary_search(int *a,int l,int r,int k);

int main(void){
	int n,a[100]={0},k,i,*p,x=0;
	p=&a;
	scanf("%d",&n);
	for(i=0;i<n;i++){
        scanf("%d",&a[i]);
	}
	scanf("%d",&k);
	sort(p,n);
	printf("%d\n",binary_search(a,x,n,k));
	return 0;
}

void sort(int *a,int n){
     int i=0,j=0,ex=0;
     for(i=0;i<n;i++){
        for(j=0;j<n;j++){
            if((*(a+j))>(*(a+i))){
                ex=*(a+j);
                *(a+j)=*(a+i);
                *(a+i)=ex;
            }
        }
     }
}

int binary_search(int *a,int l,int r,int k){
    int mid=(l+r)/2;
    if(l>r)
        return -1;
    if(*(a+mid)==k)
        return mid;
    else if(*(a+mid)>k){
        return binary_search(a,l,mid-1,k);
    }
    else if(*(a+mid)<k){
        return binary_search(a,mid+1,r,k);
    }


}
