#include <stdio.h>
#include <string.h>
int binary_search(/* Write your code here */int A[], int target);
int q;
int main(void)
{
    /* Write your code here */
    int a,b,c,A[100],i,temp,min,j;
    scanf("%d",&a);
    for(q=0; q<a; q++)
    {
        scanf("%d",&A[q]);

    }

    for(i=0; i<a; i++)
    {
        min=i;
        for(j=i+1; j<a; j++)
            if(A[min]>A[j])
                min=j;

        if(A[i]!=A[min])
        {
            temp=A[i];
            A[i]=A[min];
            A[min]=temp;

        }



    }
    scanf("%d",&b);
    printf("%d",binary_search(A,b));
}

int binary_search(/* Write your code here */int A[], int target)
{
    /* Write your code here */
    int L=0,R=q-1,M;

    while(L<=R)
    {
        M=(L+R)/2;
        if(A[M]==target)
            return M;
        else if(A[M]>target)
            R=M-1;
        else if(A[M]<target)
            L=M+1;
    }
    return -1;
}
