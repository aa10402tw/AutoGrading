#include <stdio.h>
int sum=2;

void hanoi(/* Write your code here */int n);

int main() {
    /* Write your code here */
    int n;
    scanf("%d", &n);
    hanoi(n);
    return 0;
}

void hanoi(/* Write your code here */int n){
    /* Write your code here */
    if(n==1)
        printf("%d", sum-1);
    else
    {
        sum*=2;
        hanoi(n-1);
    }
}
