#include <stdio.h>

int SUM(int n);

int main(){
	int n;
	while(scanf("%d",&n)==1){
        printf("%d\n",SUM(n));
	}

	return 0;
}

int SUM(int n){
    if(n<0){
        return 0;
    }
	return n+SUM(n-1);
}
