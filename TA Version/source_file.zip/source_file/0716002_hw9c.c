#include <stdio.h>

int binary_search(int ans[],int fa,int L,int R,int x);

int main(void)
{
    int n;
    scanf("%d",&n);
    int ans[n],fa,L=0,R=n-1,x;
    for(int i=0; i<n; i++)
        scanf("%d",&ans[i]);
    scanf("%d",&fa);
    for(int i=1; i<n; i++)
    {
        for(int j=0; j<n-1; j++)
        {
            if(ans[j]>ans[j+1])
            {
                int temp;
                temp=ans[j];
                ans[j]=ans[j+1];
                ans[j+1]=temp;
            }
        }
    }
    for(x=0;n>0;x++)
        n=n/2;
    printf("%d",binary_search(ans,fa,L,R,x));
    return 0;
}

int binary_search(int ans[],int fa,int L,int R, int x)
{

    x--;
    int m;
    m=(R+L)/2;
    if(x<0)return -1;
    if(ans[m]==fa)
        return m;
    if(ans[m]>fa)
        return binary_search(ans,fa,L, m-1,x);
    if(ans[m]<fa)
        return binary_search(ans,fa, m+1, R,x);



}
