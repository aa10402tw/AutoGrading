#include <stdio.h>

int GCD(int a,int b);

int main(){
   int a,b;
   scanf("%d %d",&a,&b);
   printf("%d",GCD(a,b));
   return 0;
}

int GCD(int a,int b){
    if(a==1||b==1) return 1;
    if(a>b){
        if(a%b==0) return b;
        a-=b;
        GCD(a,b);
    }
    else if(a<b){
        if(b%a==0) return a;
        b-=a;
        GCD(a,b);
    }
}
