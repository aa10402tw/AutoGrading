#include <stdio.h>

int binary_search(int start, int end, int k, int arr[]);

int main(void)
{
    int n, m, arr[100];
    scanf("%d", &n);

    for(int i=0; i<n; i++)
    {
        scanf("%d", &arr[i]);
    }

    scanf("%d", &m);
    printf("%d", binary_search(0, n, m, arr));
}

int binary_search(int start, int end, int k, int arr[])
{
    int i, j, s;
    for(i=1; i<end; i++)
    {
        for(j=0; j<end-1; j++)
        {
            if(arr[j]>arr[j+1])
            {
                s=arr[j];
                arr[j]=arr[j+1];
                arr[j+1]=s;
            }
        }
    }

    int mid=start+(end-start)/2; /*���������i��|����, �ҥH�Φ���k*/

    if(arr[mid]==k)
    {
        return mid;
    }
    else if(arr[mid]>k)
    {
        return binary_search(start, mid-1, k, arr);
    }
    else{
        return binary_search(mid+1, end, k, arr);
    }
}
