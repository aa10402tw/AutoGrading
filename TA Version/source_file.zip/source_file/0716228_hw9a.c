#include <stdio.h>

int SUM(/* Write your code here */);

int main(){
    int a;
	scanf("%d",&a);

	printf("%d",SUM(a));
}

int SUM(int n){
	if(n==1)
        return 1;
    else
        return SUM(n-1)+n;
}
