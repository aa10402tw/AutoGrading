#include <stdio.h>

int GCD(int n, int m);

int main(){
   int n, m;
   scanf("%d %d", &n, &m);
   printf("%d\n", GCD(n, m));
}

int GCD(int m, int n){
    return (n == 0) ? m : GCD(n, m%n);
}
