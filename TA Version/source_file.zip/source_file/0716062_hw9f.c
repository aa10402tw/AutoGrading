#include <stdio.h>
#define SIZE 20

int num;
int count=0;
int board[SIZE]={};

void queens(int l);
int check(int n);


int main()
{
   scanf("%d",&num);
   queens(0);
   printf("%d",count);
   return 0;
}

int check(int n)
{
   int t=1;
   for(int i=0;i<n-1;i++)
   {
      if(board[i]==board[n-1])
      {
         t=0;
         break;
      }
      else if(board[n-1]-n+1==board[i]-i)
      {
         t=0;
         break;
      }
      else if(board[n-1]+n-1==board[i]+i)
      {
         t=0;
         break;
      }
   }
   return t;
}


void queens(int l)
{
   if(check(l))
   {
      if(l<num)
      {
         for(int i=0;i<num;i++)
         {
            board[l]=i;
            queens(l+1);
         }
      }
      else
         count++;
   }
}
