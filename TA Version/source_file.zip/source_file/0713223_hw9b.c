#include <stdio.h>

int GCD(int a, int b/* Write your code here */);

int main(){
   /* Write your code here */
   int a, b;

   scanf("%d", &a);
   scanf("%d", &b);

   printf("%d", GCD(a, b));
}

int GCD(int a, int b/* Write your code here */){
    /* Write your code here */
    int r;

    if(b == 0)
        return a;

    r = a % b;
    a = b;
    b = r;

    return GCD(a, b);
}
