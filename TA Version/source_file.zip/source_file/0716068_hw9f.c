#include <stdio.h>
#include <string.h>

int n;

int row[100] = {0};
int col[100] = {0};
int xxl[100] = {0};
int xxr[100] = {0};

int a[100][100];

int sum = 0;

void queens(int);

int main()
{
    scanf("%d", &n);

    memset(a, 0, 100 * 100 * sizeof(int));

    queens(0);

    printf("%d",sum);
}

void queens(int i)
{

    if (i == n)
    {
        sum++;
        return;
    }

    int j;

    for (j = 0; j < n; j++)
    {
        if (row[i] || col[j] || xxl[i - j + n - 1] || xxr[i + j])
            continue;

        a[i][j] = 1;
        row[i] = 1;
        col[j] = 1;
        xxl[i - j + n - 1] = 1;
        xxr[i + j] = 1;
        /***************************/
        queens(i + 1);
        /***************************/
        a[i][j] = 0;
        row[i] = 0;
        col[j] = 0;
        xxl[i - j + n - 1] = 0;
        xxr[i + j] = 0;
    }
}