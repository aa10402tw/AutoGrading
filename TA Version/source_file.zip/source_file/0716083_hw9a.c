#include <stdio.h>

int SUM(int n);

int main()
{
    int k;
    scanf("%d", &k);
    printf("%d", SUM(k));

    return 0;

}

int SUM(int n)
{
    if(n==1)
        return 1;

    else
        return SUM(n-1)+n;
}
