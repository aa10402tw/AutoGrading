#include <stdio.h>

void hanoi(/* Write your code here */int n,int from,int temp,int to);
int c=0;
int main() {
    /* Write your code here */
	int n;
	scanf("%d",&n);
	hanoi(n,0,1,2);
	printf("%d\n",c);
	return 0;
} 

void hanoi(/* Write your code here */int n,int from,int temp,int to){  
    /* Write your code here */
    if (n==1) c++;//printf("Ring %d from %d to %d\n",n,from,to);  
    else{  
        hanoi(n-1,from,to,temp);
	c++;
        //printf("Ring %d from %d to %d\n",n,from,to);  
        hanoi(n-1,temp,from,to);  
    }  
}
