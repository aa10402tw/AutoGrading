#include <stdio.h>
int GCD(int x,int y);

int main(){
   int n,m;
   scanf("%d%d",&n,&m);
   printf("%d",GCD(n,m));
}

int GCD(int x,int y)
{
    while(x!=0&&y!=0)
    {
        if(x>=y)
        {
            x=x%y;
            return GCD(x,y);
        }
        else
        {
            y=y%x;
            return GCD(x,y);
        }
    }
    if(x==0)
    {
        return y;
    }
    else if(y==0)
    {
        return x;
    }
}
