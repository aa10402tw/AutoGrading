#include <stdio.h>

int binary_search(int q,int a[],int l,int r);

int main(void){
	int n;
	int a[105];
	scanf("%d",&n);
	for(int i=0;i<n;i++)
        scanf("%d",&a[i]);
    for(int i=0;i<n;i++){
        for(int j=1;j<n-i;j++){
            if(a[j-1]>a[j]){
                int temp=a[j-1];
                a[j-1]=a[j];
                a[j]=temp;
            }
        }
    }
    int query;
    scanf("%d",&query);
    printf("%d\n",binary_search(query,a,0,n-1));
}

int binary_search(int q,int a[],int l,int r){
    if(l==r){
        if(a[l]==q)
            return l;
        else
            return -1;
    }
   int mid=(l+r)/2;
   if(q>a[mid]){
        binary_search(q,a,mid+1,r);
   }
   else{
        binary_search(q,a,l,mid);
   }
}
