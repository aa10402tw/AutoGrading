#include<stdio.h>
#include<stdbool.h>
int count=0;
void queens(int row,int input,bool thecol[],bool slant1[],bool slant2[]);
int main(void){
    int input;
    scanf("%d",&input);
    bool thecol[input],slant1[input*2-1],slant2[input*2-1];
    queens(0,input,thecol,slant1,slant2);
    printf("%d",count);
}
void queens(int row,int input,bool thecol[],bool slant1[],bool slant2[]){
    if(row==input){
        count++;
        return;
    }
    for(int col=0;col<input;col++){
        int s1=(row+col)%(input*2-1);
        int s2=(row-col+(input*2-1))%(input*2-1);
        if(!thecol[col]&&!slant1[s1]&&!slant2[s2]){
            thecol[col]=true;
            slant1[s1]=true;
            slant2[s2]=true;
            queens(row+1,input,thecol,slant1,slant2);
            thecol[col]=false;
            slant1[s1]=false;
            slant2[s2]=false;
        }
    }
}
