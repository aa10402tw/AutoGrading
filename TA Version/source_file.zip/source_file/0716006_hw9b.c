#include <stdio.h>

int GCD(int,int);

int main(){
    int a,b;
    scanf("%d %d",&a,&b);
    printf("%d",GCD(a,b));
}

int GCD(int a,int b){
    int tmp;
    if(a<b){
        tmp = a;
        a = b;
        b = tmp;
    }
    if(b==0)
        return a;
    else
        return GCD(b,a%b);/*����۰��k*/
}
