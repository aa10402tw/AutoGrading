#include <stdio.h>

int binary_search(int *arr,int x,int y,int k);

int main(void){
	int n;
	scanf("%d",&n);
	int arr[n];
	for(int i=0;i<n;i++)
    {
        scanf("%d",&arr[i]);
    }
    int k;
    scanf("%d",&k);
    int ans=binary_search(arr,0,n-1,k);
    printf("%d",ans);
    return 0;
}

int binary_search(int *arr,int x,int y,int k){
    if(x<=y)
    {
        int m=(x+y)/2;
        if(arr[m]==k)
        {
            return m;
        }
        else if(k>=arr[m])
        {
            return binary_search(arr,m+1,y,k);
        }
        else if(k<arr[m])
        {
            return binary_search(arr,x,m-1,k);
        }
    }
    else
        return -1;
}
