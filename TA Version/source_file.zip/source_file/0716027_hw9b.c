#include <stdio.h>

int GCD(/* Write your code here */int a,int b);

int main(){
   /* Write your code here */
   int a,b;
   scanf("%d%d",&a,&b);
   printf("%d",GCD(a,b));
}

int GCD(/* Write your code here */int a,int b){
    /* Write your code here */
    if(a%b==0)
    {
        return(b);
    }
    if(a%b!=0)
    {
        return(GCD(b,a%b));

    }
}
