#include <stdio.h>
#include<string.h>

void permute(/* Write your code here */char s[],int n,int a);

int main(){
    /* Write your code here */
    char str[100000];
    int len,i,j,t;
    gets(str);
    len=strlen(str);

    for(j=0;j<len;j++)
    {
        for(i=0;i<len-1;i++)
        {
            if(str[i]>str[i+1])
            {
                t=str[i];
                str[i]=str[i+1];
                str[i+1]=t;
            }
        }
    }


    permute(str,len,0);
}

void permute(/* Write your code here */char s[],int n,int a){
    /* Write your code here */
    int i,j,t;

    if(n-a==1)
    {
        printf("%s\n",s);
    }
    else
    {
        for(i=a;i<n;i++)
        {
            if(a==i)
            {
            for(j=i;j>a;j--)
            {
                t=s[j];
                s[j]=s[j-1];
                s[j-1]=t;
            }
            permute(s,n,a+1);
            for(j=a;j<i;j++)
            {
                t=s[j];
                s[j]=s[j+1];
                s[j+1]=t;
            }
            }
            else if(a!=i&&s[a]!=s[i])
            {
            for(j=i;j>a;j--)
            {
                t=s[j];
                s[j]=s[j-1];
                s[j-1]=t;
            }
            permute(s,n,a+1);
            for(j=a;j<i;j++)
            {
                t=s[j];
                s[j]=s[j+1];
                s[j+1]=t;
            }
            }
        }

    }

}
