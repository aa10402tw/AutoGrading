#include <stdio.h>

int GCD(int n, int m);

int main(){
   int i, j;
   scanf("%d %d", &i, &j);
   printf("%d", GCD(i, j));

   return 0;
}

int GCD(int n, int m){
    if(n%m==0)
        return m;
    else
        return GCD(m, n%m);
}
