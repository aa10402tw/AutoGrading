#include <stdio.h>

int SUM(int a/* Write your code here */);

int main(){
	/* Write your code here */
	int a;
	scanf("%d",&a);
	printf("%d",SUM(a));
}

int SUM(int a/* Write your code here */){
	/* Write your code here */
	if(a>1) return a+SUM(a-1);
	else return 1;
}
