#include <stdio.h>

int SUM(int N);

int main(){
	int N;
	scanf("%d",&N);
	printf("%d",SUM(N));
}

int SUM(int N){
	if(N==1){
        return 1;
	}
	else{
        return N+SUM(N-1);
	}
}
