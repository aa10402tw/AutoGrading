#include <stdio.h>
static int count;
void hanoi(char a,char b,char c,int t);

int main() {
    int n;
    char a='a',b='b',c='c';
    scanf("%d",&n);
    hanoi(a, b, c, n);
    printf("%d\n",count);
}

void hanoi(char a,char b,char c,int t){
    if(t==1){
        count++;
    }else{
        hanoi(a,c,b, t-1);
        hanoi(a, b, c, 1);
        hanoi(b, a, c, t-1);
    }
}
