#include <stdio.h>
#define max(a,b) ((a)>(b)? (a):(b))

int GCD(/* Write your code here */int x,int y);

int main(){
   /* Write your code here */
   int x,y;
   scanf("%d%d",&x,&y);
   int a=GCD(x,y);
   printf("%d",a);
   return 0;
}

int GCD(/* Write your code here */int x,int y){
    /* Write your code here */
    int a,b;
   if(x>y)
    {
        a=x;
        b=y;
    }
    else
    {
        a=y;
        b=x;
    }
    if(a%b==0)
        return b;
    return GCD(b,(a%b));
}
