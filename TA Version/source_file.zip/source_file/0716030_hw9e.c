#include<stdio.h>
#include<string.h>
#include<memory.h>
void permute(char c_input[],int lenth,int left);

int main(){
    char c_input[15]="",c_output[15]="";
    char tem;
    int lenth;
    gets(c_input);


    lenth=strlen(c_input);
    for(int i=0;i<lenth;i++){
        for(int k=i;k<lenth;k++){
            if(c_input[i]>c_input[k]){
                tem=c_input[i];
                c_input[i]=c_input[k];
                c_input[k]= tem;
            }
        }
    }
    permute(c_input,lenth,0);
}
void permute(char c_input[],int lenth,int left){
    char tem;
    char temp[15];
    //printf("%d XDD\n",lenth);
    strcpy(temp,c_input);
    if(left==lenth)puts(c_input);
       //puts(tem);
    for(int i=left;i<lenth;i++){
        //printf("left=%d\n",left);
        //printf("c[left]=%c   c[i]=%c\n",c_input[left],c_input[i]);

        tem=c_input[i];
        for(int z=i;z>left;z--){
            //printf("換前%c %c\n",c_input[z],c_input[z-1]);
            c_input[z]=c_input[z-1];
            //printf("換後%c %c\n",c_input[z],c_input[z-1]);
        }
        c_input[left]=tem;


        permute(c_input,lenth,left+1);
        strcpy(c_input,temp);
    }



}
