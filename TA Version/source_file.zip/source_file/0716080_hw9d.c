#include <stdio.h>

void hanoi(int n);

int times = 0;

int main() {
    int n;

    scanf("%d", &n);
    hanoi(n);
    printf("%d", times);

    return 0;
}

void hanoi(int n){

    if(n==1)
       {
           times++;
       }
    else
    {
        hanoi(n-1);
        hanoi(1);
        hanoi(n-1);
    }

}
