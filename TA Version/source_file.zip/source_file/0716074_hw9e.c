#include <stdio.h>
#include <string.h>
static int uv=0;
static int t=0;
void swap(char *x, char *y)
{
    char temp;
    temp = *x;
    *x = *y;
    *y = temp;
}
void sort(char *arr, int n)
{
    for (int i = 0; i < n - 1; i++)
    {
        for (int j = 0; j < n - 1 - i; j++)
        {
            if (arr[j] > arr[j + 1])
            {
                swap(&arr[j], &arr[j + 1]);
            }
        }
    }
}

void dict(char* res[1000],int n)
{

    for(int i=0; i<n-1; i++)
    {
        for(int j=0; j<n-1-i ; j++)
        {
            if(strcmp(res[j], res[j+1])>0)
            {
                char temp[1000];
                strcpy(temp, res[j]);
                strcpy(res[j], res[j+1]);
                strcpy(res[j+1], temp);
            }
        }

    }

}
void permute(char *a, int l, int r,char* res[100],int n)
{

    int i;
    char b[1000][100];

    if (l == r) //遞迴深度=陣列長度->print
    {
        for(int i=0; i<100; i++)
        {
            b[t][i]=a[i];
        }
                res[uv] = b[t];
                t++;
        uv++;
        return;
    }
    else
    {
        for (i = l; i <= r; i++)
        {
            swap(&a[l], &a[i]);   //每一層的開頭有a.length種
            permute(a, l + 1, r,res,n); //進入下一層遞迴_level+1
            swap(&a[l],&a[i]);   //換回原本順序
        }
    }
}

int main()
{
    char result[100][100];
    char* res[100];
    char arr[100];
    int n;
 int r=1;
    for(int i=0; i<100; i++)
    {
        res[i] = result[i];
    }

    scanf("%s", arr);

    n = strlen(arr);
    for(int h=0;h<n;h++){

        r*=(h+1);
    }

    sort(arr, n);
    permute(arr, 0, n - 1,res,r);

    dict(res,r);
    for(int i=0; i<r; i++)
    {
      printf("%s\n",*(res+i));

    }
    return 0;
}
