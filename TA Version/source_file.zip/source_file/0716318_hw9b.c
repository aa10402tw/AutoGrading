#include <stdio.h>

int GCD(int num1,int num2,int a/* Write your code here */);

int main(){
   /* Write your code here */
    int num1,num2;
    scanf("%d %d",&num1,&num2);
    int a=num1;
    printf("%d",GCD(num1,num2,a));
    return 0;
}

int GCD(int num1,int num2,int a/* Write your code here */){
    /* Write your code here */
    if(num1%a==0&&num2%a==0)
        return a;
    else
    {
        a--;
        GCD(num1,num2,a);

    }
}
