#include <stdio.h>
#include<stdlib.h>
#include<time.h>
#include<stdbool.h>
void queens(int n, int order, int *sum, bool b[order][n] /* Write your code here */);

int main(){
    /* Write your code here */
    int n,s=0,*sum=&s,r=1;
    scanf("%d",&n);
    bool b[n][n];
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            b[i][j]=0;
        }
    }

    queens(n,n,sum,b);
    printf("%d",s);
}

void queens(int n, int order, int *sum, bool b[order][n] /* Write your code here */){
    /* Write your code here */

    if(order==1){


        for(int i=0;i<n;i++){
            if(b[0][i]==0)
                (*sum)++;
        }

    }
    if(order>1){
        bool c[order-1][n];
        for(int i=0;i<n;i++){
            if(b[0][i]==0){
                for(int k=1;k<order;k++){
                    for(int l=0;l<n;l++){
                        c[k-1][l]=b[k][l];
                    }
                }
                for(int k=1;k<order;k++){
                    for(int l=0;l<n;l++){
                        if((l==i)||(k-0==l-i)||(k-0==i-l))
                            c[k-1][l]=1;
                    }
                }
                queens(n,order-1,sum,c);
            }


        }
    }

}
