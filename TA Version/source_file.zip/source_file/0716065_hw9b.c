#include <stdio.h>

int GCD(int,int);

int main(){
   int x, y;
   scanf("%d%d", &x, &y);
   printf("%d", GCD(x, y));
   return 0;
}

int GCD(int s, int t){
    if(t==0)
        return s;
    return (GCD(t, s%t));
}
