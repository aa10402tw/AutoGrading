#include <stdio.h>

int GCD(int a,int b);

int main(){
   int a,b;
   scanf("%d",&a);
   scanf("%d",&b);
   printf("%d",GCD(a,b));
}

int GCD(int a,int b){
    if(b==0){
        return a;
    }
    else {
        return GCD(b,a%b);
    }
}
