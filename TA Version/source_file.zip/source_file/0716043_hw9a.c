#include <stdio.h>

int SUM(int n);

int main()
{
    int input;
    scanf("%d", &input);
    printf("%d", SUM(input));
    return 0;
}

int SUM(int n)
{
    return n == 1 ? 1 : SUM(n - 1) + n;
}
