#include<stdio.h>
#include<string.h>
char bokai[362880][9];
int counter=0;
void swap(char *a,char *b);

void bubble_sort(int len,char *input);

void permutation(char *array,int l,int r);

int fac(int n);

int main()
{
    char input[9];
    scanf("%s",input);
    int len=(int)strlen(input);
    bubble_sort(len,input);
    permutation(input,0,len-1);
    for(int i=0;i<fac(len);i++)
        for(int j=0;j<(fac(len))-1;j++)
            if(strcmp(bokai[j],bokai[j+1])>0)
            {
                char temp[9];
                strcpy(temp,bokai[j]);
                strcpy(bokai[j],bokai[j+1]);
                strcpy(bokai[j+1],temp);
            }
    for(int i=0;i<fac(len);i++)
        printf("%s\n",bokai[i]);
    return 0;
}

void swap(char *a,char *b)
{
    char temp=*a;
    *a=*b;
    *b=temp;
}

void bubble_sort(int len,char *input)
{
    for(int i=0;i<len;i++)
        for(int j=0;j<len-1;j++)
            if(input[j]>input[j+1])
                swap(input+j,input+(j+1));
}

void permutation(char *array,int l,int r)
{
    if(l==r)
    {
//        printf("%s\n",array);
        strcpy(bokai[counter],array);
        counter+=1;
    }
    else
    {
        for(int i=l;i<=r;i++)
        {
            swap((array+l),(array+i));
            permutation(array,l+1,r);
            swap((array+l),(array+i));
        }
    }
}
int fac(int n)
{
    if(n==1)
        return 1;
    else
        return n*fac(n-1);
}
