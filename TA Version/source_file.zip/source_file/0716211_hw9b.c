#include <stdio.h>
#define MAX(x,y) (((x)>(y))? (x) : (y))
#define MIN(x,y) (((x)<(y))? (x) : (y))
int GCD(int a, int b/* Write your code here */);

int main(){
   /* Write your code here */
   int a,b;
   scanf("%d%d",&a,&b);
   GCD(a,b);
}

int GCD(int a,int b/* Write your code here */){
    /* Write your code here */
    if(a!=b){
        GCD(MAX(a,b)-MIN(a,b),MIN(a,b));
    }else{
        printf("%d",a);
    }
}
