#include <stdio.h> 

int binary_search(/* Write your code here */int ,int ,int ,int arr[]);

int main(void){ 
	/* Write your code here */
	int n,m,i,j;
	scanf("%d",&n);
	int L[n];
	for(i=0;i<n;i++)
	{
		scanf("%d",&L[i]);
	}
	for(i=1;i<n;i++)
	{
		for(j=0;j<n-i;j++)
		{
			if(L[j]>L[j+1])
			{
				int f;
				f=L[j];
				L[j]=L[j+1];
				L[j+1]=f;
			}
		}
	}
	scanf("%d",&m);
	int left=0;
	int right=n-1;
	
	printf("%d",binary_search(left,right,m,L));
	return 0;
}

int binary_search(/* Write your code here */int left,int right,int m,int arr[]){ 
   /* Write your code here */
   if(left>right)
   {
   	    return -1;
   }
   else
   {
   	    int index=(left+right)/2;
   	    if(arr[index]==m)
   	    {
   	    	return index;
		}
		else if(arr[left]==m)
		{
			return left;
		}
		else if(arr[right]==m)
		{
			return right;
		}
		else if(arr[index]>m)
		{
			return binary_search(left,index,m,arr);
		}
		else
		{
			return binary_search(index,right,m,arr);
		}
   }
}
