#include <stdio.h>

void permute(/* Write your code here */int c[],int *free,char *result_head,char *result_tail,int n);
void initial_sort(int *w,int n);
void swap(int *i,int *j);

int main(){
    /* Write your code here */
    char letters[10],output[10];
    gets(letters);
    int len=0,code[10],available[10];
    for(int i=0;letters[i]!='\0';i++)
    {
        len++;
        code[i]=(int)letters[i];
        available[i]=1;
    }
    initial_sort(code,len);
    permute(code,&available[0],&output[0],&output[0],len);

    return 0;
}

void permute(/* Write your code here */int c[],int *free,char *result_head,char *result_tail,int n){
    /* Write your code here */
    for(int i=0;i<n;i++)
    {
        if(*(free+i))
        {
            *result_tail=(char)c[i];
            result_tail++;
            *(free+i)=0;
            permute(c,free,result_head,result_tail,n);
            *(free+i)=1;
            result_tail--;
        }
    }
    if(result_tail-result_head==n)
    {
        for(int j=0;j<n;j++)
            printf("%c",*(result_head+j));
        printf("\n");
    }
}

void initial_sort(int *w,int n)
{
    for(int i=n;i>1;i--)
    {
        for(int j=1;j<i;j++)
        {
            if(*(w+j-1)>*(w+j))
                swap(w+j-1,w+j);
        }
    }
}

void swap(int *i,int *j)
{
    int temp;
    temp=*i;
    *i=*j;
    *j=temp;
}
