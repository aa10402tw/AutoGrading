#include <stdio.h>
#include<stdbool.h>
#include<math.h>

void queens(int row,int n);
int can_placed(int row,int col);

int board[15],solution=0;

int main(){
    int n;
    scanf("%d",&n);
    queens(1,n);
    printf("%d",solution);
    return 0;
}

int can_placed(int row,int col){
    for(int i=1;i<=row-1;i++){
        if(board[i]==col)return 0;
        else {
            if((board[i]-col)==(i-row))return 0;
            if((board[i]-col)==-(i-row))return 0;
        }
    }
    return 1;
}

void queens(int row,int n){
    for(int col=1;col<=n;col++){
        if(can_placed(row,col)){
            board[row]=col;
            if(row==n)solution++;
            else queens(row+1,n);
        }
    }
}
