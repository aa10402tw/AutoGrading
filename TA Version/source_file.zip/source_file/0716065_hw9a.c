#include <stdio.h>

int SUM(int n);

int main(){
	int num;
	scanf("%d", &num);
	printf("%d", SUM(num));
	return 0;
}

int SUM(int n){
    if (n==1)
        return 1;
    return SUM(n-1)+n;
}
