#include <stdio.h>
#include<string.h>
void permute(char *str, int len/* Write your code here */);

int main(){
    /* Write your code here */
    char str[100];
    gets(str);

    int len=strlen(str);
    int n=1;

    permute(str,len);

}

void permute(char *str, int len /* Write your code here */){
    /* Write your code here */
    if(len==2){
        int flag=0;
        for(int i=strlen(str)-len;i<strlen(str)-1;i++){
            for(int j=strlen(str)-1;j>i;j--){
                if(str[j]<str[j-1]){
                    char tmp=str[j];
                    str[j]=str[j-1];
                    str[j-1]=tmp;
                    flag++;
                }
            }
        }
        printf("%s\n",str);
        char tmp=str[strlen(str)-len];
        str[strlen(str)-len]=str[strlen(str)-1];
        str[strlen(str)-1]=tmp;
        flag++;
        printf("%s\n",str);
        if(flag==1){

            tmp=str[strlen(str)-len];
            str[strlen(str)-len]=str[strlen(str)-1];
            str[strlen(str)-1]=tmp;
        }

    }
    if(len>2){
        for(int i=strlen(str)-len;i<strlen(str)-1;i++){
            for(int j=strlen(str)-1;j>i;j--){
                if(str[j]<str[j-1]){
                    char tmp=str[j];
                    str[j]=str[j-1];
                    str[j-1]=tmp;
                }
            }
        }
        for(int i=strlen(str)-len;i<strlen(str);i++){

            char tmp=str[strlen(str)-len];
            str[strlen(str)-len]=str[i];
            str[i]=tmp;

            permute(str,len-1);
            tmp=str[strlen(str)-len];
            str[strlen(str)-len]=str[i];
            str[i]=tmp;
        }
        for(int i=strlen(str)-len;i<strlen(str)-1;i++){
            for(int j=strlen(str)-1;j>i;j--){
                if(str[j]<str[j-1]){
                    char tmp=str[j];
                    str[j]=str[j-1];
                    str[j-1]=tmp;
                }
            }
        }

    }

}
