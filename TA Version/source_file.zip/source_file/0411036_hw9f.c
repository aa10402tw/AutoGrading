#include <stdio.h>
#define INDEX(a, b, n) a*n+b

void show(int n, int *p){
    for (int i=0; i<n; i++){
        for (int j = 0; j<n; j++){
            printf("%d ", p[INDEX(i, j, n)]);
        }
        printf("\n");
    }
}

int abs(int n){
    return (n >=0) ? n : -n;
}

int queens(int n, int dp, int *p);

int main(){
    int n;
    scanf("%d", &n);
    int data[n*n];
    for (int i=0; i<n*n; i++) data[i] = 0;
    printf("%d\n", queens(n, n-1, data));
}

int queens(int n, int dp, int *p){
    //printf("dp = %d\n", dp);
    //show(n, p);
    int sum = 0;
    if (dp == 0){
        for (int i=0; i<n; i++){
            if(p[INDEX(i, dp, n)] == 0){
                sum++;
            }
        }
        return sum;
    }

    for (int i=0; i<n; i++){
        if (p[INDEX(i, dp, n)] == 0){
            int q[n*n];
            for (int j = 0; j<n*n; j++) q[j] = p[j];
            //show(n, q);
            for (int j = 0; j<n; j++){
                for (int k = 0; k<n; k++){
                    if (j == i || k == dp || (abs(j-i) == abs(k-dp))){
                        //printf("%d %d %d %d", i, dp)
                        q[INDEX(j, k, n)] = 1;
                    }
                }
            }
            //show(n, q);
            sum += queens(n, dp-1, q);
        }
    }
    return sum;
}
