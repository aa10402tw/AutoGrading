#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int compare(const void*a,const void*b){
        return *(int*)a-*(int*)b;
}

int binary_search(int L,int R,int a[],int ans);

int main(void){
    int i,n,a[100],ans;
    while(scanf("%d",&n)!=EOF){
        for(i=0;i<n;i++){
            scanf("%d",&a[i]);
        }
        qsort((void*)a , n , sizeof(a[0]) , compare);
        scanf("%d",&ans);
        printf("%d\n",binary_search(0,n-1,a,ans));
    }
}
int binary_search(int L,int R,int a[],int ans){
    int mid=floor((L+R)/2);
    if(L>R) return -1;
    if(a[mid]==ans)
        return mid;
    else if(a[mid]>ans)
        return binary_search(L,mid-1,a,ans);
    else
        return binary_search(mid+1,R,a,ans);
}
