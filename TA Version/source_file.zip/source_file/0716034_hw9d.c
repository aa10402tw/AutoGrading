#include <stdio.h>

void hanoi(/* Write your code here */int a,int c);

int main() {
    /* Write your code here */
    int ay;
    scanf("%d",&ay);
    hanoi(ay,1);
    int b;
    return 0;
}

void hanoi(/* Write your code here */int a,int c){
    /* Write your code here */
    if(a>1){
        a--;
        c=c*2+1;
        hanoi(a,c);
        if(a==1){
        printf("%d\n",c);
        }
    }
}

//1,3,7,15,31,63
