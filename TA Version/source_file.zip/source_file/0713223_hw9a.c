#include <stdio.h>

int SUM(int n/* Write your code here */);

int main(){
	/* Write your code here */
	int n;

	scanf("%d", &n);

	printf("%d", SUM(n));

	return 0;
}

int SUM(int n/* Write your code here */){
	/* Write your code here */
	if(n == 1)
        return 1;

	return n + SUM(n - 1);
}
