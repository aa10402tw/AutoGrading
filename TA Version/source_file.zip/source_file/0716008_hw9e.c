#include <stdio.h>
#include <string.h>
char a[326880][11];
int counter=0;

void swap(char *x, char *y)
{
    char temp;
    temp = *x;
    *x = *y;
    *y = temp;
}
void stringcompare(int len)
{
    char b[len];
    for (int i=0;i<counter;i++)
    {
        for (int j=0;j<counter-1;j++)
        {
            if(strcmp(a[j],a[j+1])>0)
            {
                strcpy(b,a[j]);
                strcpy(a[j],a[j+1]);
                strcpy(a[j+1],b);
            }
        }
    }
}
/* Function to print permutations of string
 This function takes three parameters:
 1. String
 2. Starting index of the string
 3. Ending index of the string.*/


void permute(char *c, int l, int r)
{
    int i;
    if (l == r)
    {
        strcpy(a[counter],c);
        //printf("%s\n",a[counter]);
        counter++;
        /*for (int j=0;j<r;j++)
        {
        }*/
        
    }
    else
    {
        for (i = l; i <= r; i++)
        {
            swap((c+l), (c+i));
            permute(c, l+1, r);
            swap((c+l), (c+i));
        }
    }
}

// Driver program to test above functions
int main()
{
    char c[11];//,a[][];
    gets(c);
    int length = strlen(c);
    //printf("%d",length);
    permute(c, 0, length-1);
    /*for (int i=0;i<counter;i++)
    {
        printf("%s\n",a[i]);
    }
    printf("\n\n");*/
    
    /*for (int i=0;i<counter;i++)
    {
        for (int j=i+1;j<counter;j++)
        {
            if(strcmp(a[i],a[j])==1)
            {
                swap(c+i,c+j);
            }
        }
    }*/
    stringcompare(length);
    for (int i=0;i<counter;i++)
    {
        printf("%s\n",a[i]);
        
    }
    
    return 0;
}


