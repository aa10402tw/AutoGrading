#include <stdio.h>

int SUM(int n,int sum);

int main(){
	/* Write your code here */
    int n,sum=0;
    scanf("%d",&n);
    printf("%d",SUM(n,sum));
}

int SUM(int n,int sum){
	/* Write your code here */
	if(n>0){
	    sum=sum + n + SUM(n-1,sum);
	}
	return sum;
}
