#include <stdio.h>
int sum = 0;
int SUM(int a){
    if(a<= 0)
        return 0;
    else
        return a+SUM(a-1);
}
int main(void){
	int a;
    scanf("%i",&a);
    printf("%i\n",SUM(a));
}

