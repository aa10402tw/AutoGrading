#include <stdio.h>

int binary_search(int *arr,int s,int e,int t);

void bub(int *arr,int n)
{
    if(n!=1)
    {
    int i;
    for(i=0;i<n-1;i++)
    {
        if(arr[i]>arr[i+1])
        {
            int temp = arr[i];
            arr[i]=arr[i+1];
            arr[i+1]=temp;
        }
    }
    bub(&arr[0],n-1);

    }

}

int main(void){
	/* Write your code here */
	int i,n,t;

	int arr[100]={0};

	scanf("%d",&n);

	for(i=0;i<n;i++)
    {
        scanf("%d",&arr[i]);
        //printf("scan i = %d\n",arr[i]);
    }




    bub(&arr[0],n);
    /*for(i=0;i<n;i++)
    {

        printf("arr[%d]=%d\n",i,arr[i]);
    }*/

    scanf("%d",&t);
    int k=binary_search(&arr[0],0,n-1,t);

    printf("%d",k);

    return 0;

}

int binary_search(int *arr,int s,int e,int t){

    int p=(s+e)/2;
    //printf("p=%d s=%d e=%d\n",p,s,e);
    if(t==arr[p])
    {
        return p;
    }
    else if(s==e)
    {
        return -1;
    }
    else if(t>arr[p])
    {
        if(e-s==1)
        binary_search(&arr[0],e,e,t);
        else
        binary_search(&arr[0],p+1,e,t);
    }
    else if(t<arr[p])
    {
        if(e-s==1)
        binary_search(&arr[0],s,s,t);
        else
        binary_search(&arr[0],s,p-1,t);
    }


}
