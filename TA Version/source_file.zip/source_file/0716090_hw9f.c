#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int ans = 0;
int map[16][16];
void queens(int,int,int/* Write your code here */);

int main(){
    /* Write your code here */
    int n;
    memset(map, 0, sizeof(map));
    scanf("%d", &n);
    queens(n,0,0);
    printf("%d\n", ans);
    return 0;
}

void queens(int n,int r,int i/* Write your code here */){
    /* Write your code here */
   if (r == n) {
        ans++;
        return;
    }
    for (i = 0; i < n; i++) {
        if (!map[r][i]) {
            map[r][i] += 1;
    for (int k = i + 1; k < n; k++) {
        map[r][k] += 1;
    }
    for (int k = i - 1; k >= 0; k--) {
        map[r][k] += 1;
    }
    for (int k = r + 1; k < n; k++) {
        map[k][i] += 1;
    }
    for (int k = r - 1; k >= 0; k--) {
        map[k][i] += 1;
    }
    for (int k = r + 1, j = i + 1; k < n && j < n; k++, j++) {
        map[k][j] += 1;
    }
    for (int k = r - 1, j = i + 1; k >= 0 && j < n; k--, j++) {
        map[k][j] += 1;
    }
    for (int k = r + 1, j = i - 1; k < n && j >= 0; k++, j--) {
        map[k][j] += 1;
    }
    for (int k = r - 1, j = i - 1; k >= 0 && j >= 0; k--, j--) {
        map[k][j] += 1;
    }
            queens(n, r + 1,i);
            map[r][i] += -1;
    for (int k = i + 1; k < n; k++) {
        map[r][k] += -1;
    }
    for (int k = i - 1; k >= 0; k--) {
        map[r][k] += -1;
    }
    for (int k = r + 1; k < n; k++) {
        map[k][i] += -1;
    }
    for (int k = r - 1; k >= 0; k--) {
        map[k][i] += -1;
    }
    for (int k = r + 1, j = i + 1; k < n && j < n; k++, j++) {
        map[k][j] += -1;
    }
    for (int k = r - 1, j = i + 1; k >= 0 && j < n; k--, j++) {
        map[k][j] += -1;
    }
    for (int k = r + 1, j = i - 1; k < n && j >= 0; k++, j--) {
        map[k][j] += -1;
    }
    for (int k = r - 1, j = i - 1; k >= 0 && j >= 0; k--, j--) {
        map[k][j] += -1;
    }
        }
    }
}
