#include <stdio.h>
#include<math.h>
int m=0;
void queens(int i, int p[], int n);

int main(){
	int n;
	scanf("%d", &n);
	int p[n];
	queens(0, p, n);
	printf("%d", m);
	return 0;
}

void queens(int i, int p[], int n){
	int j, k, c;
	if(i==n){
		m++;
		return;
	}
	for(k=0;k<n;k++){
		c=0;
		for(j=0;j<i && !c;j++){
			if(p[j]==k || abs(k-p[j])==(i-j)){
				c=1;
			}
		}
		if(!c){
			p[i]=k;
			queens(i+1, p, n);
		}
	}
}
