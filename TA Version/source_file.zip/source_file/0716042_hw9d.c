#include <stdio.h>
int sum=1;
void hanoi(int a);

int main() {
    int n;
    scanf("%d",&n);
    hanoi(n);
    printf("%d",sum);
    return 0;
}

void hanoi(int a){
    if(a==1)
    {
        return;
    }

    sum=2*sum+1;

    hanoi(a-1);

}
