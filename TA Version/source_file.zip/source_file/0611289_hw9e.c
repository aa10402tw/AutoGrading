#include <stdio.h>

#include <string.h>

void permute(char [], int , int );
void swap(char [], int , int );
void aprintf(int, char []);
int main(){
    /* Write your code here */
    char str[10];
    int length=0;
    scanf("%s", &str);
   // printf("%s", str);
    while (str[++length]!='\0');
  //  printf("%d",length);
    permute(str, 0, length-1);
    printf("\n");
    return 0;
}

void permute(char str[], int a, int b){
    /* Write your code here */
    int i = 0;
    for(i = a; i<b; i++){
        swap(str, a, i);
   //     printf("%s\n",str);
        permute(str, a+1, b);
        swap(str, a, i);
    }
    if(a == b){
        printf("%s\n",str);
        return;
    }
}

void swap(char str2[], int a, int b){
    char temp = str2[a];
    str2[a] = str2[b];
    str2[b] = temp;
}


