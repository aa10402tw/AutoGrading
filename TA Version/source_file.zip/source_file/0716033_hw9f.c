#include<stdio.h>
#include<stdlib.h>

void queens(/* Write your code here */int a);
int n, num;
char** checkerboard;
int* column;
int* right;
int* left;

int main(){
    /* Write your code here */
    int i, j;
    scanf("%d", &n);
    column = malloc(sizeof(int) * n);
    right = malloc(sizeof(int) * (2 * n - 1));
    left = malloc(sizeof(int) * (2 * n - 1));
    checkerboard = malloc(sizeof(char*) * n);
    num = 0;
    for (i = 0; i < n; i++)
    {
        column[i] = 1;

        checkerboard[i] = malloc(sizeof(char) * n);
        for (j = 0; j < n; j++)
        {
            checkerboard[i][j] = 'X';
        }
    }
    for (i = 0; i < 2 * n - 1; i++)
    {
        right[i] = left[i] = 1;
    }
    queens(0);
    printf("%d", num);
    for (i = 0; i < n; i++)
    {
        free(checkerboard[i]);
    }

    free(checkerboard);
    free(column);
    free(right);
    free(left);

    return 0;
}

void queens(/* Write your code here */int x){
    /* Write your code here */
    if (x < n)
    {
        int i;
        for (i = 0; i < n; i++)
        {
            int j = i - x + n - 1;
            int k = i + x;

            if (column[i] && right[j] && left[k])
            {
                column[i] = right[j] = left[k] = 0;
                checkerboard[x][i] = '1';
                queens(x + 1);
                column[i] = right[j] = left[k] = 1;
                checkerboard[x][i] = 'x';
            }
        }
    }
    else
    {
        num++;
    }
}
