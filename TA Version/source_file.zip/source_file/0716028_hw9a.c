#include <stdio.h>

int SUM(/* Write your code here */int i);

int main(){
	/* Write your code here */
	int n;
	scanf("%d",&n);
	printf("%d",SUM(n));

	return 0;
}

int SUM(/* Write your code here */int i){
	/* Write your code here */
	if(i==1)
        return 1;
    else
        return i+SUM(i-1);
}
