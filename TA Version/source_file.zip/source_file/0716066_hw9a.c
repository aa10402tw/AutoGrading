#include <stdio.h>

int SUM(int);

int main(){
	/* Write your code here */
	int in;
	scanf("%d",&in);
	printf("%d",SUM(in));
}

int SUM(int n){
	/* Write your code here */
	static int sum=0;
	if (n==0)
		return sum;
	else
	{
		sum += n;
		return SUM(n-1);
	}
}