#include <stdio.h>

void hanoi(int);
int times=0;
int main(void) {
    int num;
    scanf("%d",&num);
    hanoi(num);
    printf("%d",times);

}

void hanoi(int num){
    if(num==1)
        times +=1;
    else{
        hanoi(num-1);
        times ++;
        hanoi(num-1);
    }
}
