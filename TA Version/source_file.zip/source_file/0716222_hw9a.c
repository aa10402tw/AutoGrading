#include <stdio.h>

int SUM(int n);

int main(){
	int n;
	scanf("%d",&n);
	printf("%d\n",SUM(n));
	return 0;
}

int SUM(int n){
	if(n==1)
		return 1;
	return SUM(n-1)+n;
}