#include <stdio.h>
#include <string.h>
#include <stdlib.h>
void permute(/* Write your code here */char *tar,char *buf,char *used,int l,int n);
int cmp(const void *a,const void *b){return *(char *)a-*(char *)b;}
int main(){ 
    /* Write your code here */
	char foo[128],bar[128],u[128]={0};
	scanf("%s",foo);
	qsort(foo,strlen(foo),sizeof(char),cmp);
	bar[strlen(foo)]='\0';
	permute(foo,bar,u,strlen(foo),0);
	return 0;
}

void permute(/* Write your code here */char *tar,char *buf,char *used,int l,int n){  
    /* Write your code here */
	for(int a=0;a<l;a++){
		if(!used[a]){
			used[a]=1;
			buf[n]=tar[a];
			if(n==l-1)puts(buf);
			else permute(tar,buf,used,l,n+1);
			used[a]=0;
		}
	}
} 
