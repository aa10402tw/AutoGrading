#include<stdio.h>
#include<string.h>
int used[11] = { 0 };
char finish[11];
int j = 0;
void swap(char *a, char *b);
void permute(char *inp, int len);
int main()
{
    char inp[11];
    scanf("%s", inp);
    int len = strlen(inp);
    for(int i=0; i<len; i++)
        for(int k=i+1; k<len; k++)
            if(inp[i]>inp[k])
                swap(&inp[i],&inp[k]);
    permute(inp, len);
    return 0;
}
void swap(char *a, char *b)
{
    char c= *a;
    *a = *b;
    *b = c;
}
void permute(char *inp, int len)
{
    for (int i = 0; i < len; i++)
    {
        for (; used[i] == 1; i++);
        if (i != len)
        {
            used[i] = 1;
            finish[j++] = inp[i];
            if (j == len)
                printf("%s\n",finish);
            permute(inp, len);
            j--;
            used[i] = 0;
        }
    }
}
