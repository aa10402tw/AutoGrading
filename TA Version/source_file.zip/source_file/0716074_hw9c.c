#include <stdio.h>

int binary_search(int *arr, int begin, int finish, int data_to_find);

int main(void)
{
   int n;
   int data_find;
   int arr[100];
   scanf("%d",&n);
   for(int i=0;i<n;i++){
scanf("%d",&arr[i]);
   }
   scanf("%d",&data_find);
   bubble_sort(arr,n);

   printf("%d",binary_search(arr,0,n-1,data_find));
}

int binary_search(int *arr, int begin, int finish, int data_to_find)
{
   int count = finish - begin + 1;
   int middle = (begin + finish) / 2;
   if (count >= 1)
   {
      if (arr[middle] > data_to_find)
      {
         return binary_search(arr, 0, middle - 1, data_to_find);
      }
      else if (arr[middle] < data_to_find)
      {
         return binary_search(arr, middle + 1, finish, data_to_find);
      }
      else
      {
         return middle;
      }
   }
   else
   {
      return -1;
   }
}
void bubble_sort(int* arr,int n){
for(int i=0;i<n-1;i++){
   for(int j=0;j<n-1-i;j++){
  
      if(arr[j]>arr[j+1]){
         int temp=arr[j];
         arr[j]=arr[j+1];
         arr[j+1]=temp;
      }
   }
}


}