#include <stdio.h>

int SUM(int );

int main(){
	int n;
	scanf("%d",&n);
	printf( "%d",SUM(n) );
	return 0;
}

int SUM(int n){
    return n==0?0:(SUM(n-1)+n);
}
