#include <stdio.h>
#include <stdlib.h>

void queens(int* col, int* slopeP, int* slopeN, int i,int L);

int n=0;
int main(){
    int col[20]={0};
    int slopeP[40]={0};
    int slopeN[40]={0};
    int len;
    scanf("%d",&len);
    queens(col, slopeP, slopeN, 0, len);
    printf("%d",n);
    return 0;
}

void queens(int* col, int* slopeP, int* slopeN, int i, int len) {
    if(i==len)
        n++;
    else{
    	int j;
        for(j=0; j<len; j++){
            if(col[j]==0 && slopeP[i+j]==0 && slopeN[i-j+len]==0) {
                col[j] = slopeP[i+j] = slopeN[i-j+len]=1;
                queens(col, slopeP, slopeN, i+1, len);
                col[j] = slopeP[i+j] = slopeN[i-j+len]=0;
            }
        }
    }
}
