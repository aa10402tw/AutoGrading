#include <stdio.h>
#include <math.h>

void hanoi(char A,char B,char C,int a);
int count=0;
int main()
{
    int n;
    scanf("%d",&n);
    hanoi('a','b','c',n);
    printf("%d",count);
    return 0;
}

void hanoi(char A,char B,char C,int n)
{
    if (n==1){count++;return;}
    //printf("%d",n);
    hanoi(A,C,B,n-1);
    count++;
    hanoi(A,B,C,n-1);
    
}

/*#include <stdio.h>
 #include <string.h>
 
 
 void swap(char *x, char *y)
 {
 char temp;
 temp = *x;
 *x = *y;
 *y = temp;
 }
 
 /* Function to print permutations of string
 This function takes three parameters:
 1. String
 2. Starting index of the string
 3. Ending index of the string.
 void permute(char *c, int l, int r)
 {
 int i;
 if (l == r)
 {
 
 }
 printf("%s\n", c);
 
 else
 {
 for (i = l; i <= r; i++)
 {
 swap((c+l), (c+i));
 permute(c, l+1, r);
 swap((c+l), (c+i));
 }
 }
 }
 
 /* Driver program to test above functions
 int main()
 {
 char c[11];
 gets(c);
 int length = strlen(c);
 permute(c, 0, length-1);
 return 0;
 }*/



/*#include <stdio.h>
#include <math.h>

void hanoi(int a);

int main()
{
    int n;
    scanf("%d",&n);
    hanoi(n);
    return 0;
}

void hanoi(int a)
{
    printf("%g",pow(2,a)-1);
}
*/
