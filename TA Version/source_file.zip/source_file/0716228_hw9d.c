#include <stdio.h>

void hanoi(/* Write your code here */);

int main() {
    int n,t=1;
    scanf("%d",&n);
    hanoi(n,&t);
    printf("%d",t);
}

void hanoi(int a,int *c){
    int j;
    if(a!=1)
       {
            j=*c;
           j=2*j+1;
           hanoi(a-1,&j);
           *c=j;
       }
}
