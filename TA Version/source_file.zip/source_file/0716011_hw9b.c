#include <stdio.h>

int GCD(int n,int m/* Write your code here */);

int main(){
    int n,m;
    scanf("%d%d",&n,&m);
    printf("%d",GCD(n,m));
   /* Write your code here */
}

int GCD(int n,int m/* Write your code here */){

    if(n==1||m==1)return 1;
    else if(n==0)return m;
    else if(m==0)return n;
    else if(n>m)return GCD(n-m,m);
    else return GCD(n,m-n);/* Write your code here */
}
