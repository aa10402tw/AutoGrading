#include <stdio.h>

int SUM(long long int a);

int main(){
	long long int n;
	scanf("%lld",&n);
	SUM(n);
	if(SUM(n)==0){
        printf("overflow");
	}
	else{
        printf("%d",(int)SUM(n));
	}
}

int SUM(long long int a){
	int i;
	long long int sum=0;
	for(i=1;i<=a;i++){
        sum+=i;
	}
	if(sum<2147483647){
        return sum;
    }
    else{
        return 0;
    }

}
