#include <stdio.h>
#include <string.h>
int binary_search(int *, int , int , int );
void sort(int *,int);
void swap(int *,int *);

int i,j,n;
int main(void){
	int find;
	int numstr[100];
	scanf("%d",&n);
	for(i=0;i<n;i++)
		scanf("%d",&numstr[i]);
	sort(numstr,n);
	scanf("%d",&find);
	printf("%d",binary_search(numstr,find,0,n-1));
	return 0;
}

void swap(int *a,int *b){
	int tmp=*a;
	*a=*b;
	*b=tmp;
	return;
}

void sort(int *num,int n){
	for(i=0;i<n;i++){
		for(j=i+1;j<n;j++){
			if(num[i]>num[j]){
				swap(&num[i],&num[j]);
			}
		}
	}
}

int binary_search(int *num, int find, int low, int high){
	
    if(low<=high){
        int mid=(low+high)/2;

		if(num[mid]<find)
            return binary_search(num,find,mid+1,high);

	    if(num[mid]>find)
            return binary_search(num,find,low,mid-1);

        if(num[mid]==find)
        	return mid;
    }
	else return -1;
}
