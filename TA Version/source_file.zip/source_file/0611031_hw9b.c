#include <stdio.h>

int GCD(int n1,int n2);

int main(){
    int a,b;
    scanf("%d %d",&a,&b);
    printf("%d",GCD(a,b));
    return 0;
}

int GCD(int n1,int n2){
    int temp;
    while(n1<n2){
        temp=n1;
        n1=n2;
        n2=temp;
    }
    if(n1==n2 || n1%n2==0){
        return n2;
    }
    else{
        return GCD(n2,(n1%n2));
    }
}
