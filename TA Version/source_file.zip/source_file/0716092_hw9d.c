#include <stdio.h>

void hanoi(/*int *record,*/int n,char S,char T, char E/* Write your code here */);
int record=0;
int main() {
    /* Write your code here */
    int a/*,b*/;
    scanf("%d",&a);
    //int *p;
    //p=&b;
    hanoi(/*p,*/a,'S','T','E');
    printf("%d",record);
}

void hanoi(/*int *record,*/ int n,char S,char T, char E/* Write your code here */){
    /* Write your code here */
    if(n==0) return;
    hanoi(/*record,*/n-1,'S','E','T');
    record++;
    //printf("Move disk %d from %c to %c\n",n,S,E);
    //int pointer=*record;
    //(*record)=(*record)+1;
    hanoi(/*record,*/n-1,'T','S','E');
}
