#include <stdio.h>

int GCD(/* Write your code here */);

int main(){
    int x,y;
    scanf("%d %d",&x,&y);
    printf("%d",GCD(x,y));

}

int GCD(int a,int b){
    if(a%b==0)
        return b;
    else
        return GCD(b,a%b);
}
