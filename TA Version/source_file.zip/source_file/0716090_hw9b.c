#include <stdio.h>

int GCD(int,int/* Write your code here */);

int main(){
   /* Write your code here */
   int N1,N2;
    scanf("%d %d",&N1,&N2);
    printf("%d",GCD(N1,N2));
}

int GCD(int N1,int N2/* Write your code here */){
    /* Write your code here */
    N1=N1%N2;

    if(N1==0){
        return N2;
    }
    N2=N2%N1;
    if(N2==0){
        return N1;
    }
    else
    return GCD(N1,N2);
}
