#include <stdio.h>
#include <string.h>

void permute(char *a,int l,int r);
void swap(char *,char *);
void lexico(char *);
char result[500][9]={0};
int m=0,i=0,len;

int main(){
    char in[9];

    gets(in);
    len = strlen(in);
    permute(in,0,len-1);
    for(int i=0;i<m;i++)
        lexico(result[0]);
    for(int i=0;result[i][0];i++)
        printf("%s\n",result[i]);
}
//////可以permute出來再排///////

void permute(char *a,int l,int r){
    if(l != r)
    {
        for(int i=l;i<=r;i++)
        {
            swap(a+i,a+l);
            permute(a,l+1,r);
            swap(a+i,a+l);  //要換回來 不然下一圈會132不是312
        }
    }
    else
    {
        strcpy(result[m++],a);
        return;
    }
}

void lexico(char *a)
{
    if(*(a+9))
    {
        if(strcmp(a,a+9) > 0)
            for(int i=0;i<len;i++)
                swap(a+i,(a+9)+i);
        lexico(a+9);
    }
    return;

}

void swap(char *a,char *b)
{
    char temp = *a;
    *a = *b;
    *b = temp;
    return;
}
