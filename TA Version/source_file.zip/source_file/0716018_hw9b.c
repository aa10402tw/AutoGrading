#include <stdio.h>

int GCD(int,int);

int main(){
   int a,b;
   scanf("%d %d",&a,&b);
   printf("%d",GCD(a,b));
   return 0;
}

int GCD(int cos,int sin){
    if(sin==0)
        return cos;
    else
        return GCD(sin,cos%sin);
}
