#include <stdio.h>
#include <string.h>

void sort(char *a,char *b){
    if((int)*a>(int)*b){
        char temp = *a;
             *a   = *b;
             *b   = temp;
    }
    return;
}

void swap(char *a,char *b){
    char temp = *a;
        *a    = *b;
        *b    = temp;
    return;
}

void permute(/* Write your code here */char *str,char *pri,int lay,int exi[]);

int main(){
    /* Write your code here */
    char str[100],pri[100]={};
    int exi[100]={0};    //0 for not use, 1 for already use.
    scanf("%s",str);
    for(int i=strlen(str)-1;i>0;i--){
        for(int j=0;j<i;j++){
            sort(&str[j],&str[j+1]);
        }
    }
    permute(str,pri,1,exi);
    return 0;
}

void permute(/* Write your code here */char *str,char *pri,int lay,int *exi){
    /* Write your code here */
    for(int i=0;i<strlen(str);i++){
        if(lay==strlen(str)+1){
            printf("%s\n",pri);
            return;
        }
        if(*(exi+i)==1) continue;
        else{
            pri[lay-1]=*(str+i);
            *(exi+i)=1;
            permute(str,pri,lay+1,exi);
            *(exi+i)=0;
        }
    }
    return;
}
