#include <stdio.h>

void hanoi(int n, int *sum/* Write your code here */);

int main() {
    /* Write your code here */
    int n, sum=0, *p;

    scanf("%d", &n);

    p = &sum;
    hanoi(n, p);

    printf("%d", sum);

    return 0;
}

void hanoi(int n, int *sum/* Write your code here */){
    /* Write your code here */
    if(n == 1){
        *sum += 1;
        return;
    }

    hanoi(n - 1, sum);
    hanoi(1, sum);
    hanoi(n - 1, sum);
}
