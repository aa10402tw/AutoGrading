#include <stdio.h>
#include <stdlib.h>

int cmp(const void *a, const void *b)
{
    return *(int *)a - *(int *)b;
}

int binary_search(int*, int, int, int);

int main(void)
{
    int n;
    int a[150];

    scanf("%d", &n);

    for (int i = 0; i < n; i++)
    {
        scanf("%d", &a[i]);
    }

    int tar;
    scanf("%d", &tar);

    qsort(a, n, sizeof(int), cmp);

    printf("%d", binary_search(a, tar, 0, n - 1));

    return 0;
}

int binary_search(int* a, int tar, int left, int right)
{
    /*printf("%d %d--%d %d\n",left,right,a[(left + right) / 2],tar);*/
    if(left >= right)
    {
        if (a[(left + right) / 2] == tar)
            return (left + right) / 2;
        else
            return -1;
    }
    else if (a[(left + right) / 2] == tar)
        return (left + right) / 2;
    else if (a[(left + right) / 2] < tar)
        return binary_search(a, tar, (left + right) / 2 + 1, right);
    else if (a[(left + right) / 2] > tar)
        return binary_search(a, tar, left, (left + right) / 2 - 1);
}