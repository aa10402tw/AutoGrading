#include <stdio.h>

void hanoi(int n, int from, int spare, int destination, int *count);

int main() {
    /* Write your code here */
    int n;
    scanf("%d",&n);
    int count=0;
    hanoi(n,1,2,3,&count);
    printf("%d\n", count);
} 

void hanoi(int n, int from ,int spare, int destination, int *count){
    /* Write your code here */
    

    if(n==1){
        *count +=1;
        //printf("%d %d %d\n", n, from, destination);

        return;
    }
    //n-1 from start to spare
    
    hanoi(n - 1, from, destination, spare, count);

    //move 1 to destination
    //recursive until last and return then print and count
    //printf("%d %d %d\n", n, from, destination);

    *count +=1;
    //n-1 from spare to destination
    hanoi(n - 1, spare, from, destination, count);
    


}