#include <stdio.h>

int GCD(int a,int b,int i);

int main(){
   int num1,num2;
   scanf("%d%d",&num1,&num2);
   int i;
   i=((num1>num2)?num2:num1);
   printf("%d",GCD(num1,num2,i));
}

int GCD(int a,int b,int i){
    if(a%i==0&&b%i==0){
        return i;
    }else{
        return GCD(a,b,i-1);
    }


}
