#include <stdio.h>

int GCD(int i,int j);

int main(){
   int n1,n2;

   scanf("%d %d",&n1,&n2);

   int i=GCD(n1,n2);

   printf("%d",i);

   return 0;
}

int GCD(int i,int j){
    if(i==j)
        return i;
    else if(i<j)
    {
        if(j%i==0)
            return i;
        else
        {
            return GCD(i,j-(j/i)*i);
        }
    }
    else if(i>j)
    {
        if(i%j==0)
            return j;
        else
        {
            return GCD(j,i-(i/j)*j);
        }
    }


}
