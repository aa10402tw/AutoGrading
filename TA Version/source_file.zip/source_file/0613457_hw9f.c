#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int pos[20];
void queens(int row,int n,int *k);
int main()
{
    int n,k=0;
    scanf("%d",&n);
    queens(1,n,&k);
    printf("%d\n",k);
    return 0;
}

int check(int row,int col)
{
    int i;
    for(i=1;i<=row-1;++i)
    {
        if(pos[i]==col)
            return 0;
        else{
            if(abs(pos[i]-col)==abs(i-row))
                return 0;
        }
    }
    return 1;
}

void queens(int row,int n,int *k)
{
    for(int col=1; col<=n; col++)
    {
        if(check(row,col))
        {
            pos[row]=col;
            if(row==n)
                (*k)++;
            else
                queens(row+1,n,k);
        }
    }
}
