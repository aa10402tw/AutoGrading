#include <stdio.h>

int s=0;
int SUM(/* Write your code here */);

int main(){
    int x,y,plus;
    scanf("%d",&x);
    y=x;
    plus=SUM(y);
    printf("%d",plus);
    return 0;

	/* Write your code here */
}

int SUM( int a/* Write your code here */){
    int i;
    if(a<=0)
    {
        return s;
    }
    else
    {
        s+=a;
        a--;
        return SUM(a);
    }

	/* Write your code here */
}
