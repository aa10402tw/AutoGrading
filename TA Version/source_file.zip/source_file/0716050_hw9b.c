#include <stdio.h>

int GCD(int a, int b);

int main(){
    /* Write your code here */
    int a, b;
    scanf("%d %d", &a, &b);
    printf("%d", GCD(a, b));
}

int GCD(int a, int b){
    /* Write your code here */
    if (a < b) {
        int temp = a;
        a = b;
        b = temp;
    }
    if (b == 0)
        return a;
    else
        return GCD(b, a%b);
}
