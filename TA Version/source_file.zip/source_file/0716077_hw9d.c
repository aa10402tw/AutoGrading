#include <stdio.h>
int p=0;
void hanoi(int n);

int main() {
  int n;
  scanf("%d",&n);
  hanoi(n);
  printf("%d",p);
  return 0;
}

void hanoi(n){
  int a=1;
   for(int i=1;i<n;i++)
   {
    a*=2;
   }
   p+=a;
   if(n>1)
   {
       n-=1;
    hanoi(n);
   }
  return ;
}
