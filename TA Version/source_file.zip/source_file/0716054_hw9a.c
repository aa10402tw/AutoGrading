#include <stdio.h>

int SUM(int a);

int main(){
	int n;
	scanf("%d",&n);

	printf("%d",SUM(n));

	return 0;
}

int SUM(int a){
	if (a==1){
        return 1;
	}else{
	    return SUM(a-1)+a;
	}
}
