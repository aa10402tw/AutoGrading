#include <stdio.h>

int hanoi(int n);

int main() {
    int n;
    scanf("%d", &n);
    printf("%d\n", hanoi(n));
}

int hanoi(int n){
    return (n == 1) ? 1 : 2*hanoi(n-1)+1;
}
