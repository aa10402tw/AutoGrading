#include <stdio.h>

int binary_search(int num_point,int num_len,int mmm[],int num_search);

int main(void){
	/* Write your code here */
	int num_len;
	int mmm[120]={0};
	int num_search;
	int num_point=0;

	scanf("%d",&num_len);

	for(int i=0;i<num_len;i++)
    {
        scanf("%d",&mmm[i]);
    }

    scanf("%d",&num_search);


    int i,j,swap,position;
    for(i=0;i<num_len-1;i++)
    {
        for(j=i+1;j<num_len;j++)
        {
            position=i;
            if(mmm[i]>mmm[j])
                position=j;

            if(position==j)
            {
                swap=mmm[i];
                mmm[i]=mmm[j];
                mmm[j]=swap;
            }
        }
    }

    printf("%d",binary_search(num_point,num_len,mmm,num_search));

    return 0;
}


int binary_search(int num_point,int num_len,int mmm[],int num_search){
   /* Write your code here */

   if(num_point<num_len)
   {
       if(mmm[num_point]==num_search)
        return num_point;
       else
       {
           if(mmm[num_point]>num_search)
           {
                int temp = (int)(num_point/2);
                return binary_search(temp,num_len,mmm,num_search);
           }
           if(mmm[num_point]<num_search)
           {
               int temp = (int)((num_point+num_len)/2);
               return binary_search(temp,num_len,mmm,num_search);
           }
       }

   }
   else
    return -1;


}
