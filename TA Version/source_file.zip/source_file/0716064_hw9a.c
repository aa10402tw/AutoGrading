#include <stdio.h>

int SUM(/* Write your code here */int n);

int main(){
	/* Write your code here */
	int i,j;
	scanf("%d",&i);
	printf("%d",SUM(i));
}

int SUM(/* Write your code here */int n){

	/* Write your code here */
	if(n==0) return 0;
	else return n+SUM(n-1);

}
