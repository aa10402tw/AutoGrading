#include <stdio.h>

int GCD(int b1, int b2);

int main(){
    int a1, a2;
    scanf("%d%d",&a1,&a2);
    printf("%d",GCD(a1,a2));
    return 0;
}

int GCD(int b1, int b2){
    if(b2==0)
        return b1;
    else
        return GCD(b2, b1%b2);
}
