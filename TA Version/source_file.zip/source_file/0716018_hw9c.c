#include <stdio.h>

int binary_search(int *,int,int,int);
void swap(int*,int*);

int main(void){
	int len;
	int arr[101];
	scanf("%d",&len);
	for(int i=0;i<len;i++)
        scanf("%d",&arr[i]);
    int goal;
    scanf("%d",&goal);
    for(int i=0;i<len;i++)
        for(int j=i+1;j<len;j++)
            if(arr[i]>arr[j])
                swap(&arr[i],&arr[j]);
    int cos=binary_search(arr,0,len-1,goal);
    printf("%d",cos);
    return 0;
}
void swap(int*a,int*b){
    int c=*a;
    *a=*b;
    *b=c;
    return;
}
int binary_search(int*arr,int left,int right,int goal){
    int mid=(left+right)/2;
    int middle=arr[mid];
    if(middle==goal)
        return mid;
    if(middle>goal)
        return binary_search(arr,left,mid-1,goal);
    if(middle<goal)
        return binary_search(arr,mid+1,right,goal);
    if(left>right)
        return -1;
}
