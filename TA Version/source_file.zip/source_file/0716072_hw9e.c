#include <stdio.h>
#include <string.h>

char input[1000]={},length;


void sort(){
    for(int i=1;i<length;i++){
        int j=i;
        while(j){
            if(input[j]<input[j-1]){
                char tem=input[j-1];
                input[j-1]=input[j];
                input[j]=tem;
                j--;
            }
            else break;
        }
    }
}

void change(int first,int last){
    char tem=input[last];
    for(int i=last-1;i>=first;i--){
        input[i+1]=input[i];
    }
    input[first]=tem;
}

void change_back(int first,int last){
    char tem=input[first];
    for(int i=first;i<last;i++){
        input[i]=input[i+1];
    }
    input[last]=tem;
}

void permute();

int main(){ 
    scanf("%s",input);
    length=strlen(input);
    sort();
    permute(0,length);
}

void permute(int first){
    if(first==length){
        printf("%s\n",input);
    }
    else{
        for(int i=first;i<length;i++){
            change(first,i);
            permute(first+1);
            change_back(first,i);
        }
    }
} 

//cd "/Users/jia/Desktop/hwjson/" && gcc 0716072_hw9e.c -o 0716072_hw9e && "/Users/jia/Desktop/hwjson/"0716072_hw9e