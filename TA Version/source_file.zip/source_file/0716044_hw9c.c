#include <stdio.h>

int binary_search(int *ar,int n,int ns);

int main(void)
{
    int i,n,ns;
    int ar[100];

    scanf("%d",&n);
    for(i=0; i<n; i++)
    {
        scanf("%d",&ar[i]);
    }
    scanf("%d",&ns);
    printf("%d",binary_search(ar,n,ns));
    return 0;
}

int binary_search(int *ar,int n,int ns)
{
    int i,j,idx,temp;

    for(i=0;i<n;i++){
        idx=i;
        for(j=idx+1;j<n;j++){
            if(ar[idx]>=ar[j]){
                idx=j;
            }
        }
        if(idx!=i){
            temp=ar[idx];
            ar[idx]=ar[i];
            ar[i]=temp;
        }
    }



    int M,R,L;
    R=n-1;
    L=0;
    while(R>=L)
    {

        M=(R-L)/2+L;
        if(ns==ar[M])
        {
            return M;
        }
        else if(ns>ar[M]){
            L=M+1;
        }
        else{
            R=M-1;
        }


    }
    return -1;


}
