#include <stdio.h>

int binary_search(int *,int,int,int);

int main(void){
    int n,key;
    scanf("%d",&n);
    int a[n];
    for(int i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    for(int i=0;i<n;i++){
        for(int j=i+1;j<n;j++){
            if(a[i]>a[j]){
                int tmp=a[i];
                a[i]=a[j];
                a[j]=tmp;
            }
        }
    }
    scanf("%d",&key);
    printf("%d",binary_search(a,0,n,key));
    return 0;
}

int binary_search(int *c,int low,int up,int k){
    int mid=(up+low)/2;
    while(low<=up){
        if(c[mid]==k){
            return mid;
        }else if(c[mid]>k){
            return binary_search(c,low,mid-1,k);
        }else if(c[mid]<k){
            return binary_search(c,mid+1,up,k);
        }
    }
    return -1;
}
