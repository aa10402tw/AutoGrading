#include <stdio.h>

int GCD(/* Write your code here */int x,int y);

int main(){
   /* Write your code here */
   int x,y;
   scanf("%d %d",&x,&y);
   printf("%d",GCD(x,y));
   return 0;
}

int GCD(/* Write your code here */int x,int y){
    /* Write your code here */
    if(x==0 || y==0) return (x==0 ? y:x);
    else if(x>y) return GCD(x-y,y);
    else if(x<y) return GCD(x,y-x);

}
