#include <stdio.h>

void hanoi(int n,char a,char b,char c);
int ans=0;

int main() {
    int n;
    char a,b,c;
    scanf("%d",&n);
    hanoi(n,a,b,c);
    printf("%d",ans);
}

void hanoi(int n,char a,char b,char c){
    if(n==1) {
        ans += 1;
        return;
    }
    hanoi(n-1,a,c,b);
    hanoi(1,a,b,c);
    hanoi(n-1,b,a,c);
}
