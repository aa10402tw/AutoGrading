#include <stdio.h>

int GCD(int a,int b);

int main(){
   /* Write your code here */
   int a,b;
   scanf("%d %d",&a,&b);
   printf("%d",GCD(a,b));

   return 0;
}

int GCD(int a,int b){
    /* Write your code here */
    if(b==0)
        return a;

    return GCD(b,a%b);
}
