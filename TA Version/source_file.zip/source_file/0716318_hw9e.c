#include <stdio.h>
#include <string.h>
void permute(char str[],int count[],char result[],int level,int N/* Write your code here */);

int main(){
    /* Write your code here */
char str[30],result[30];
int N,count[30];
scanf("%s",&str);
N=strlen(str);
for(int i=0;i<N;i++)
    {
        for(int j=0;j<N-1;j++)
        {
            if(str[j]>str[j+1])
            {
                char tem=str[j];
                str[j]=str[j+1];
                str[j+1]=tem;
            }

        }
    }
for(int i=0;i<N;i++)
    count[i]=1;
permute(str,count,result,0,N);
return 0;
}

void permute(char str[],int count[],char result[],int level,int N/* Write your code here */){
if(level==N)
    {result[N]='\0';
    printf("%s\n",result);
    return;}
for(int i=0;i<N;i++)
{

    if(count[i]==0)
        continue;
    result[level]=str[i];
    count[i]--;
    permute(str,count,result,level+1,N);
    count[i]++;
}

}

