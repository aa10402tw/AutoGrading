#include <stdio.h> 

int split(int a[], int low, int high);

void quicksort(int a[], int low, int high);

int binary_search(int* sequence, int left, int right, int search);

int main(void){ 
	int length, insert_sequence[100];
	scanf("%d", &length);
	for(int i = 0; i < length; i++){
		scanf("%d", &insert_sequence[i]);
	}
	int searching_num;
	scanf("%d", &searching_num);
	quicksort(insert_sequence, 0, length-1);
	printf("%d",binary_search(insert_sequence, 0, length, searching_num));
	return 0;
}

int split(int a[], int low, int high){
	int key = a[low];
	while(1){
		while(low < high && key <= a[high]) high--;
		if(low >= high) break;
		a[low++] = a[high];
		while(low < high && key >= a[low]) low++;
		if(low >= high) break;
		a[high--] = a[low];
	}
	a[high] = key;
	return high;
}

void quicksort(int a[], int low, int high){
	int mid;
	if(low >= high) return;
	mid = split(a, low, high);
	quicksort(a, low, mid - 1);
	quicksort(a, mid+1, high);
}

int binary_search(int* sequence, int left, int right, int search){
	int middle;
	if(left > right) return -1;
	middle = (right - left) / 2 + left;
	if(search == sequence[middle]) return middle;
	else if(sequence[middle] > search) binary_search(left, middle - 1);
	else binary_search(middle + 1, right);
}