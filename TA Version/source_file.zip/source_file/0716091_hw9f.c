#include <stdio.h>

void queens(int*z,int n,int x,int y,int*a);

int main(){
    int n,z=0;
    scanf("%d",&n);
    int a[n*n];
    for(int i=0;i<n*n;i++)
        a[i]=0;
    queens(&z,n,0,0,a);
    printf("%d",z);
    return 0;
}

void queens(int*z,int n,int x,int y,int*a){
    for(y=0;y<n;y++)
        if(a[x*n+y]==0)
        {
            if(x==n-1)
            {
                *z+=1;
                return;
            }
            a[x*n+y]=-1;
            for(int i=x+1;i<n;i++)
                if(a[i*n+y]==0)
                    a[i*n+y]=x+1;
            for(int i=y+1;i<n;i++)
                if(a[x*n+i]==0)
                    a[x*n+i]=x+1;
            for(int i=x+1,j=y+1;i<n&&j<n;i++,j++)
                if(a[i*n+j]==0)
                    a[i*n+j]=x+1;
            for(int i=x+1,j=y-1;i<n&&j>=0;i++,j--)
                if(a[i*n+j]==0)
                    a[i*n+j]=x+1;
            queens(z,n,x+1,0,a);
            for(int i=0;i<n*n;i++)
                if(a[i]==x+1)
                    a[i]=0;
        }
        for(int i=x*n;i<n*n;i++)
        {
            if(a[i]>x+1||a[i]==-1)
                a[i]=0;
        }
        return;
}
