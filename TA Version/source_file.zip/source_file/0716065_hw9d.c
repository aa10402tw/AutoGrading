#include <stdio.h>

void hanoi(int);

int time = 0;

int main() {
    int num;
    scanf("%d", &num);
    hanoi(num);
    printf("%d", time);
}

void hanoi(int i){
    if(i==1)
       ++time;
    else{
        hanoi(i-1);
        ++time;
        hanoi(i-1);
    }

}
