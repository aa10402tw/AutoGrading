

#include <stdio.h>

int SUM(int a);

int main()
{
    int n;
    scanf("%d",&n);
    if(n<=0){return 0;}
    printf("%d",SUM(n));
    return 0;
}

int SUM(int a)
{
    if (a==1){return 1;}
    
    return a+SUM(a-1);
}
