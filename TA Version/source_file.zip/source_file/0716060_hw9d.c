#include <stdio.h>

void hanoi(int n,int *p);

int main() {
    /* Write your code here */
    int n;
    scanf("%d",&n);

    int count=0;

    hanoi(n,&count);

    printf("%d",count);

    return 0;
}

void hanoi(int n,int *p){
    /* Write your code here */
    if(n==1)
    {
        *p = *p+1;
        return;
    }


    hanoi(n-1,p);
    *p = *p+1;
    hanoi(n-1,p);
}
