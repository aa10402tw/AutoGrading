#include <stdio.h>
#include <string.h>

char s[10];

void swap ( int a, int b );
void sort ( int n );
void permute ( int l, int r );

int main () {
  fgets(s, 10, stdin);
  strtok(s, "\n");
  int n = strlen(s);
  sort(n);
  permute(0, n-1);
  return 0;
}

void swap ( int a, int b ) {
  char temp = s[a];
  s[a] = s[b];
  s[b] = temp;
  return;
}

void sort ( int n ) {
  for ( int i = 0; i < n - 1; ++i ) {
    for ( int j = 0; j < n - i - 1; ++j ) {
      if ( s[j] > s[j+1])
        swap (j, j + 1);
    }
  }
  return;
}
void permute ( int l, int r ) {
  if ( l == r ) {
    puts(s);
  }
  else {
    for ( int i = l; i <= r; ++i ) {
      swap ( l, i );
      permute ( l + 1, r );
      swap ( l, i );
    }
  }
  return;
}

