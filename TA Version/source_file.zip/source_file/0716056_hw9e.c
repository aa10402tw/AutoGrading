//
//  main.c
//  0716056_hw9e
//
//  Created by 王孜甄 on 2018/11/22.
//  Copyright © 2018 eliawang_. All rights reserved.
//

#include <stdio.h>
#include <string.h>

char answer[362880][100];
int num=0;
void permute(/* Write your code here */char list[],int i,int n);

int main(){
    /* Write your code here */
    int n,i,j;
    char array[100],temp[9];
    
    gets(array);
    n=strlen(array);
    permute(array,0,n);
    
    for(i=0;i<num-1;i++){
        for(j=0;j<num-i-1;j++){
            if(strcmp(answer[j],answer[j+1])>0){
                strcpy(temp,answer[j]);
                strcpy(answer[j],answer[j+1]);
                strcpy(answer[j+1],temp);
            }
        }
    }
    
    for(i=0;i<num;i++){
        printf("%s\n",answer[i]);
    }
    
}

void swap(char *a,char *b){
    char temp;
    temp=*a;
    *a=*b;
    *b=temp;
}

void permute(/* Write your code here */char list[],int i,int n){
    /* Write your code here */
    int j;
    if(i==n-1){
        strcpy(answer[num],list);
        num++;
    }
    
    else{
        for(j=i;j<n;j++){
            swap(&list[i],&list[j]);
            permute(list,i+1,n);
            swap(&list[i],&list[j]);
        }
    }
}
