#include <stdio.h>
static int count=0;
void place_queen(int i, int queen_pos[],int N) //我現在要放第i直排
{
  int j, k, conflict;

  if (i == N)
  {
    count++;

  }

  else
  {
    for (k = 0; k < N; k++)
    { //第i直排開始試每一個位置
      conflict = 0;
      for (j = 0; j < i && !conflict; j++){
        if (queen_pos[j] == k || abs(k - queen_pos[j]) == (i - j))  //是否衝突:同一橫列、斜線
          conflict = 1; }//是
      if (!conflict)//如果不衝突
      {
        queen_pos[i] = k; //放進去
        place_queen(i + 1, queen_pos,N); //進行下一直行
      }

    }
  }
}
int main()
{
  int queen_pos[100];
  int N;
  scanf("%d",&N);
  place_queen(0,queen_pos,N);
     printf("%d",count);
  return 0;
}
