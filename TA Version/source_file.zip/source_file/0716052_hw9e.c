//0716052_hw9e
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void swap(char *a, char *b);
void permute(char *cSequence, char cAns[][10], int nIdx, int nLength, int *nNumOfAns);

char cAns[362880][10];
int main() {
	char cSequence[10], cTemp[10];
	int nLength, i, j, nChange, nIdx, nNumOfAns;

	//Ū�r��
	scanf("%s", cSequence);
	nLength = strlen(cSequence);

	nIdx = 0;
	nNumOfAns = 0;

	permute(cSequence, cAns, nIdx, nLength, &nNumOfAns);

	for (i = 0; i < nNumOfAns - 1; i++) {
		for (j = 0; j < nNumOfAns - 1 - i; j++) {
			nChange = 0;
			if (strcmp(cAns[j], cAns[j + 1]) > 0) {
				strcpy(cTemp, cAns[j]);
				strcpy(cAns[j], cAns[j + 1]);
				strcpy(cAns[j + 1], cTemp);
			}
		}
	}

	for (i = 0; i < nNumOfAns; i++) {
		printf("%s\n", cAns[i]);
	}

	//system("pause");

	return 0;
}

void swap(char *a, char *b) {
	char temp;
	temp = *a;
	*a = *b;
	*b = temp;
}

void permute(char *cSequence, char cAns[][10], int nIdx, int nLength, int *nNumOfAns) {
	int i;
	if (nIdx == nLength - 1) {
		strcpy(cAns[*nNumOfAns], cSequence);
		(*nNumOfAns)++;
	}
	else {
		for (i = nIdx; i < nLength; i++) {
			swap(&cSequence[nIdx], &cSequence[i]);
			permute(cSequence, cAns, nIdx+1, nLength, nNumOfAns);

			swap(&cSequence[nIdx], &cSequence[i]);
		}
	}

}
