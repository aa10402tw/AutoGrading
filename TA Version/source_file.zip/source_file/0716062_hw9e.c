#include <stdio.h>
#include <string.h>

void permute(char a[],int i,int l);
void sort(char n[]);
void change1(char *s,char *e);
void change2(char *s,char *e);

int main()
{
   char input[100]={};
   scanf("%s",input);
   sort(input);
   //printf("\%d\n",strlen(input));
   int end=strlen(input)-1;
   /*for(int i=0;i<len;i++)
      printf("%c",input[i]);*/
   permute(input,0,end);
   return 0;
}

void sort(char n[])
{
   int l=strlen(n);
   for(int i=0;i<l;i++)
   {
      for(int j=0;j<l-1;j++)
      {
         if(n[j]>n[j+1]>0)
         {
            char tempt=n[j];
            n[j]=n[j+1];
            n[j+1]=tempt;
         }
      }
   }
}

void change1(char *s,char *e)
{
   char tempt=*e;
   for(int i=e-s-1;i>=0;i--)
      *(s+1+i)=*(s+i);
   *s=tempt;
}

void change2(char *s,char *e)
{
   char tempt=*s;
   for(int i=0;i<e-s;i++)
      *(s+i)=*(s+i+1);
   *e=tempt;
}

void permute(char a[],int i,int l)
{
   int j;
   if(i==l)
   {
      for(j=0;j<=l;j++)
         printf("%c",a[j]);
      printf("\n");
   }
   else
   {
      for(j=i;j<=l;j++)
      {
         change1(&a[i],&a[j]);
         permute(a,i+1,l);
         change2(&a[i],&a[j]);
      }
   }
}

