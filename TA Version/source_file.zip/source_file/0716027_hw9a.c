#include <stdio.h>

int SUM(/* Write your code here */int a);

int main(){
	/* Write your code here */
	int a;
	scanf("%d",&a);
	printf("%d",SUM(a));
}

int SUM(/* Write your code here */int a){
	/* Write your code here */
	int b,i;
	if(a==1)
    {
        b=1;
        return(b);
    }
    if(a>1)
    {
        b=a+SUM(a-1);
        return(b);
    }


}
