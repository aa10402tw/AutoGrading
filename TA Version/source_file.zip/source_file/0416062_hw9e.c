#include <stdio.h>
#include <string.h>

void permute(char *c,int s,int e);

void swap(char *a,char *b)
{
    char temp = *a;
    *a = *b;
    *b = temp;
}

void bub(char *c,int n)
{
    int i;

    if(n>0)
    {
        for(i=0;i<n-1;i++)
        {
            if(c[i]>c[i+1])
            {
                swap(&c[i],&c[i+1]);
            }
        }
        bub(&c[0],n-1);
    }
}

int main(){
    char c[10]={'\0'};

    scanf("%s",c);

    /*char a='a';
    char b='b';
    printf("a=%c b=%c\n",a,b);
    swap(&a,&b);
    printf("a=%c b=%c",a,b);*/

    bub(&c[0],strlen(c));
    //printf("len = %d\n",strlen(c));
    int i;
    /*for(i=0;i<strlen(c);i++)
    {
        printf("%c ",c[i]);
    }*/


    permute(&c[0],0,strlen(c)-1);


}

void permute(char *c,int s,int e){
    /* Write your code here */

    int i,j;
    if(s==e){


        for(j=0;j<=e;j++)
        {
            printf("%c",c[j]);
        }
         printf("\n");
    }
    else{

        for(j=s;j<=e;j++)
        {
            //printf("uswap c[%d] c[%d] \n",s,j);
            swap(&c[s],&c[j]);
            if(j-s>1)
            {
                if(j-s>2)printf("@@\n");
                if(c[j-(j-s-2)]<c[j-(j-s-1)])
                    swap(&c[j-(j-s-2)],&c[j-(j-s-1)]);
            }


            /*printf("c[ ]= ",s,j);
            for(i=0;i<strlen(c);i++)
            {
                printf("%c ",c[i]);
            }
            printf("\n");

            printf("perm(c,%d,%d)\n",s+1,e);*/
            permute(&c[0],s+1,e);

            if(j-s>2)printf("dswap c[%d] c[%d] \n",s,j);

            swap(&c[s],&c[j]);
            if(j-s>1)
            {
                if(j-s>2)printf("!!\n");
                if(c[s+(j-s)-2]>c[s+(j-s)-1])
                    swap(&c[s+(j-s-2)],&c[s+(j-s-1)]);
            }

            /*printf("c[ ]= ",s,j);
            for(i=0;i<strlen(c);i++)
            {
                printf("%c ",c[i]);
            }
            printf("\n");*/
        }

    }
}
