#include <stdio.h>

int GCD(int a,int b);

int main()
{
   int input1,input2;
   scanf("%d",&input1);
   scanf("%d",&input2);
   printf("%d",GCD(input1,input2));
   return 0;
}

int GCD(int a,int b)
{
   /*long long int big=(a>b?a:b);
   long long int small=(a*b)/big;
   if(big%small==0)
      return (int)small;
   else
      return GCD((big%small),small);*/
   if(a%b==0)
      return b;
   else
      return GCD(b,a%b);
}
