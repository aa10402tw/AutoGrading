#include <stdio.h>

void hanoi(int,char,char,char);

int time=0;
int main()
{
    int qq;
    scanf("%d",&qq);
    hanoi(qq,'a','b','c');
    printf("%d",time);
    return 0;
}

void hanoi(int a,char A,char B,char C){
    if(a==1)
        time++;
    else
    {
        hanoi(a-1,A,B,C);
        time++;
        hanoi(a-1,B,A,C);
    }

}
