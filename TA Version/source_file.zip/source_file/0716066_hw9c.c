#include <stdio.h> 

int binary_search(int *,int,int,int);
void selection_sort(int *,int);
void swap(int *,int *);

int main(void){ 
	int len,target;

   scanf("%d",&len);
   
   int in[len],sort[len];
   for(int i=0;i<len;i++)
      scanf("%d",&in[i]);
   for(int i=0;i<len;i++)
      sort[i] = in[i];
   selection_sort(sort,len);

   scanf("%d",&target);
   int back = binary_search(sort,target,0,len-1);
   if (back != -1)
   {
      for(int i=0;i<len;i++)
         if(target == sort[i])
         {
            printf("%d",i);    /////印出排序後的index///////
            break;
         }
   }
   else
      printf("-1");

}

int binary_search(int *a,int target,int l,int r){ 
   int m = (r-l)/2+l;

   if(l>r)
      return -1;
   if(*(a+m) == target)
      return 1;
   else if (*(a+m) > target)
      return binary_search(a,target,l,m);
   else if (*(a+m) < target && (r-l)/2 == 0)
      return binary_search(a,target,m+1,r);
   else if (*(a+m) < target && (r-l)/2 != 0)
      return binary_search(a,target,m,r);

}

void swap(int *a,int *b)
{
   int temp = *a;
   *a = *b;
   *b = temp;
   return;
}

void selection_sort(int *a,int len)
{
   for(int i=0;i<len;i++)
   {
      int min = i;
      for(int j=i+1;j<len;j++)
         if(*(a+j) < *(a+min))
            min = j;
      if(min != i)
         swap(a+min,a+i);
   }
   return;
}