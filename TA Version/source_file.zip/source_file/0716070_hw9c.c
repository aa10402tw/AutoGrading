#include <stdio.h>

int binary_search(int qq,int *a,int right,int left);

int main()
{
    int a[100],ww,len,i,j,left=0,right,qq;
    scanf("%d",&len);
    for(i=0; i<len; i++)
    {
        scanf("%d",&a[i]);
    }
    for(i=0; i<len; i++)
    {
        for(j=1; j<len-i; j++)
        {
            if(a[j-1]>a[j])
            {
                ww=a[j-1];
                a[j-1]=a[j];
                a[j]=ww;
            }
        }
    }
    right=len-1;
    scanf("%d",&qq);
    printf("%d",binary_search(qq,a,right,left));
    return 0;
}

int binary_search(int qq,int *a,int right,int left)
{
    int middle=(right+left)/2;
    if(left<=right)
    {
        if(qq==a[middle])
            return middle;
        else if(qq<a[middle])
        {
            right=middle-1;
            return binary_search(qq,a,right,left);
        }
        else
        {
            left=middle+1;
            return binary_search(qq,a,right,left);
        }
    }
    return -1;
}
