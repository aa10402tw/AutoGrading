#include <stdio.h>

void hanoi(/* Write your code here */int plate,int *val);

int power(int a,int b){
    if(b>=1) return a*power(a,b-1);
    if(b==0) return 1;
}

int main() {
    /* Write your code here */
    int k,num=0;
    scanf("%d",&k);
    hanoi(k,&num);
    printf("%d",num);
    return 0;
}

void hanoi(/* Write your code here */int plate,int *val){
    /* Write your code here */
    if(plate>=1){
        *val+=power(2,plate-1);
        return hanoi(plate-1,val);
    }
}
