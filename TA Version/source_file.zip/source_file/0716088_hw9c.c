#include <stdio.h>
#define space 300

int binary_search(int L,int R,int num);

int main(void){
	int n,num1[space],input;
	scanf("%d",&n);
	for(int i=0;i<n;i++){
        scanf("%d",&num1[i]);
    }
	scanf("%d",&input);
	for(int i=0;i<n-1;i++){
        for(int j=0;j<n-1;j++){
            if(num1[j]>num1[j+1]){
                int tem=num1[j];
                num1[j]=num1[j+1];
                num1[j+1]=tem;
            }
        }
	}
	int ans=binary_search(num1[0],num1[n-1],input);
	for(int i=0;i<n;i++){
        if(num1[i]==ans){
            printf("%d",i);
        }
	}
	return 0;
}

int binary_search(int L,int R,int num){
    int middle=(L+R)/2;
    if(L>R){
        return -1;
    }
    if(num>middle){
            return binary_search(L+1,R,num);
    }
    else if(num<middle){
        return binary_search(L,R-1,num);
    }
    else{
        return middle;
    }
}
