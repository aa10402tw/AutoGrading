#include <stdio.h>

int output=0;

void hanoi();

int main() {
    int input;
    scanf("%d",&input);
    hanoi(input);
    printf("%d",output);
} 

void hanoi(int n){
    if(n){
        output=2*output+1;
        hanoi(n-1);
    }
}