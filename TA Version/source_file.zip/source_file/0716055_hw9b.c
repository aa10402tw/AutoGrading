#include <stdio.h>

int GCD(int a,int b);

int main(){
    int a,b;
    scanf("%d%d",&a,&b);
    printf("%d\n",GCD(a, b));
}

int GCD(int a,int b){
    /* Write your code here */
    if (a==0) {
        return b;}
    if (a>=b) {
        return GCD(a%b,b);
    }else{
        return GCD(b,a);
    }
}
