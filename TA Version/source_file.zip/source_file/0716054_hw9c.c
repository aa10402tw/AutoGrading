#include <stdio.h>

int binary_search(int* arr,int a,int start,int end);

int main(void){
	int n,ans;
	scanf("%d",&n);
	ans = n/2;
	int arr[n];
	for(int i = 0;i<n;i++){
        scanf("%d",&arr[i]);
	}

	int tmp;
	for(int i = 0;i<n;i++){
        for(int j = i;j<n;j++){
            if(arr[i]>arr[j]){
                tmp = arr[i];
                arr[i] = arr[j];
                arr[j] = tmp;
            }
        }
	}

	int re;
	scanf("%d",&re);

	printf("%d",binary_search(arr,re,0,n));

	return 0;
}

int binary_search(int* arr,int a,int start,int end){
   int mid = (start+end)/2;

   if(arr[mid] == a){
        return mid;
   }else{
       if(arr[mid] > a)return binary_search(arr,a,start,mid);
        else if(arr[mid] < a) return binary_search(arr,a,mid,end);
   }
   if(mid == 0)return -1;
}
