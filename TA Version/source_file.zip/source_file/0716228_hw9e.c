#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void permute(char*, int, void (*)(char*));
void rotate(char*, int, int);
void c(char* from, char* to);
void p(char* num);
int n;

int compare(const void *a, const void *b)
{
      int c = *(char *)a;
      int d = *(char *)b;
      if(c < d) {return -1;}
      else if (c == d) {return 0;}
      else return 1;
}


int main(){
    char num[9] ;
    scanf("%s",&num);
    n=strlen(num);
    qsort(num,n,sizeof(num[0]),compare);



    permute(num, 0, p);
    return 0;
}

void permute(char* num, int i, void (*take)(char*)){
    if(i < n) {
        int j;
        for(j = i; j < n; j++) {
            char to[n];
            c(num, to);
            rotate(to, i, j);
            permute(to, i + 1, take);
        }
    } else { take(num); }
}

void rotate(char* num, int i, int j) {
    char t = num[j];
    int k;
    for(k = j; k > i; k--) {
        num[k] = num[k - 1];
    }
    num[i] = t;
}

void c(char* from, char* to) {
    int i;
    for(i = 0; i < n; i++) {
        to[i] = from[i];
    }
}


void p(char* num) {
    int i;
    for(i = 0; i < n; i++)
        printf("%c", num[i]);
    printf("\n");
}
