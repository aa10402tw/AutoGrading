#include <stdio.h>
#include <string.h>

void permute(char array[],int target ,int end);



int main(void) {
	char input[130];
	scanf("%s", input);


	permute(input, 0, strlen(input) - 1);
}


void permute(char array[], int target, int end) {
	if(target == end) {
		for(int i = 0 ; i <= end ; i++) {
			printf("%c", array[i]);
		}
		printf("\n");
	}
	else {
		for(int i = target; i <= end; i++) {
			int tem=array[target];
			array[target]=array[i];
			array[i]=tem;
			permute(array, target + 1, end);
			tem=array[target];
			array[target]=array[i];
			array[i]=tem;
		}
	}
}
