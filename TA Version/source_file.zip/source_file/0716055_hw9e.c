#include <stdio.h>
#include <string.h>
void permute(char input[], int count[], char output[], int t);
void strswap(char *a,char *b,int len){
    for (int i=0; i<len; i++) {
        char temp=*(a+i);
        *(a+i)=*(b+i);
        *(b+i)=temp;
    }
    
}
int scompare(char *a,char *b){
    for (int i=0; i<strlen(a); i++) {
        if (*(a+i)>*(b+i)) {
            return 1;
        }
        else if (*(a+i)<*(b+i)){
            return 0;
        }else{
            continue;
        }
    }
    return 0;
}
int step(int x){
    if (x==1) {
        return 1;
    }else{
        return x*step(x-1);
    }
}
static char nosort[362880][10];
int k=0;
int main(){
    char arr[10];
    scanf("%s",arr);
    int c[9];
    char o[9];
    for (int i=0; i<10; i++) {
        c[i]=1;
    }
    permute(arr, c, o, 0);
    
    char sort[362880][10];
    int lent=(int)strlen(arr);
    int time=step(lent);
    for (int i=0; i<time; i++) {
        strcpy(sort[i], nosort[i]);
    }
    
    for (int i=0; i<time-1; i++) {
        for (int j=i+1; j<time; j++) {
            if (scompare(sort[i],sort[j])) {
                strswap(sort[i], sort[j],lent);
            }
        }
    }
    for (int i=0; i<time; i++) {
        printf("%s\n",sort[i]);
    }
    return 0;
}

void permute(char input[], int count[], char output[], int t){
    if (t==strlen(input)) {
        for (int i=0; i<strlen(input); i++) {
            nosort[k][i]=output[i];
        }
        k++;
        return;
    }
    for (int i=0; i<strlen(input); i++) {
        if (count[i]==0){
            continue;
        }
        output[t]=input[i];
        count[i]--;
        permute(input, count, output, t+1);
        count[i]++;
    }
}
