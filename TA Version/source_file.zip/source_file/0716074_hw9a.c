#include <stdio.h>

int SUM(int n);

int main(){
	int n;
	scanf("%d",&n);
	printf("%d",SUM(n));
}

int SUM(int n){
if(n==1){return 1;}
if(n>1){return n+SUM(n-1);}

}