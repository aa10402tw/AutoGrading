#include <stdio.h>

int SUM(int);

int main(){
	int a;
	scanf("%d",&a);
	printf("%d",SUM(a));
	return 0  ;
	}

int SUM(int b){
	if(b>0)
	return(b+SUM(b-1));
	else
    return 0;
}
