#include <stdio.h>

#define MAXSIZE 16
#define TRUE 1
#define FALSE 0
#define FREE 0
#define USE 1

int position[MAXSIZE];
int usedata[MAXSIZE];
int size;
int count=0;

int conflict(int i, int n);
void queens(int n);

int main()
{
    int i;
    scanf("%d", &size);
    for(i=0; i<size; i++)
    {
        usedata[i]=FREE;
    }
    queens(0);
    printf("%d", count);

    return 0;
}

int conflict(int i, int n)
{
    int j;
    for(j=0; j<n; j++)
    {
        if(((position[j]-j)==(i-n)) || ((position[j]+j)==(i+n)))
        {
            return FALSE;
        }
    }

    return TRUE;
}

void queens(int n)
{
    int i;
    if(n==size)
    {
        count++;
    }
    else
    {
        for(i=0; i<size; i++)
        {
            if(usedata[i]==FREE && conflict(i,n))
            {
                position[n]=i;
                usedata[i]=USE;
                queens(n+1);
                usedata[i]=FREE;
            }
        }
    }
}
