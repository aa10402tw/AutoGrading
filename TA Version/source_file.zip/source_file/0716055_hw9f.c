#include <stdio.h>
#include <stdlib.h>

void queens(int t,int m,int n,int s[m][n],int *p);

int main(){
    int n;
    int p=0;
    scanf("%d",&n);
    int arr[14][14];
    for (int *i=arr[0]; i<arr[0]+196; i++) {
        *i=1;
    }
    queens(0, n, n, arr, &p);
    printf("%d\n",p);
    return 0;
}

void queens(int r,int m,int n,int s[m][n],int *p){
    
    for (int i=0; i<m; i++) {
        if (s[r][i]<=0) {
            continue;
        }
        if (r==n-1) {
            *p=*p+1;
            return;
        }
        for (int j=0; j<m; j++) {
            s[j][i]--;
        }
        for (int j=0; j<m-r; j++) {
            if (i+j==m){
                break;
            }
            s[r+j][i+j]--;
        }
        for (int j=0; j<m-r; j++) {
            if (i-j<0) {
                break;
            }
            s[r+j][i-j]--;
        }
        
        queens(r+1, m, n, s, p);
        
        for (int j=0; j<m; j++) {
            s[j][i]++;
        }
        for (int j=0; j<m-r; j++) {
            if (i+j==m)
                break;
            
            s[r+j][i+j]++;
        }
        for (int j=0; j<m-r; j++) {
            if (i-j<0) {
                break;
            }
            s[r+j][i-j]++;
        }
    }
}
