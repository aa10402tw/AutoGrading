#include <stdio.h>
int n,tt=0;
void queens(int now,int num[14][14]);
int yy(int row,int col,int v[14][14])
{
    for(int g=0;g<14;g++)
        if(v[row][g]!=0)
            return 1;
    for(int g=-13;g<14;g++)
    {
        if(row+g>=0&&row+g<14&&col-g<14&&col-g>=0)
        {
            if(v[row+g][col-g]!=0)
                return 1;
        }
    }

    for(int g=-13;g<14;g++)
    {
        if(row+g>=0&&row+g<14&&col+g<14&&col+g>=0)
        {
            if(v[row+g][col+g]!=0)
                return 1;
        }
    }
    return 0;
}

int main(){
    int b[14][14]={0};
    scanf("%d",&n);
    queens(0,b);
    printf("%d",tt);
}

void queens(int now,int num[14][14]){
    if(now<n-1)
    {
        for(int i=0;i<n;i++)
            if(yy(i,now,num)==0)
            {
                num[i][now]=1;
                queens(now+1,num);
                //for(int p1=0;p1<n;p1++)
                   // {for(int p2=0;p2<n;p2++)
                      //  printf("%d ",num[p1][p2]);
                   // printf("\n");}
               // printf("\n");
                num[i][now]=0;
            }
    }
    if(now==n-1)
    {
        for(int i=0;i<n;i++)
        {
            if(yy(i,now,num)==0)
                tt+=1;
        }
    }
}
