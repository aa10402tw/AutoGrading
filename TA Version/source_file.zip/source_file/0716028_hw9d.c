#include <stdio.h>

void hanoi(/* Write your code here */int *times,int n);

int main() {
    /* Write your code here */
    int n,times=0;
    scanf("%d",&n);
    hanoi(&times,n);
    printf("%d",times);

    return 0;
}

void hanoi(/* Write your code here */int *times,int n){
    /* Write your code here */
    if(n==1) (*times)++;
    else
    {
        hanoi(times,n-1);
        (*times)++;
        hanoi(times,n-1);
    }
}
