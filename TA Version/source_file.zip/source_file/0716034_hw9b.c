#include <stdio.h>

int GCD(/* Write your code here */int a,int b);

    int j,i=0;
int main(){
    int c,d;
   /* Write your code here */
   scanf("%d %d",&c,&d);
   printf("%d",GCD(c,d));
   return 0;
}

int GCD(/* Write your code here */int a,int b){
    /* Write your code here */
    i++;
    if((a%i)==0){
        if((b%i)==0){
            j=i;
        }
    }
    if(a>=i){
        if(b>=i){
            j=GCD(a,b);
        }
    }
    return j;
}
