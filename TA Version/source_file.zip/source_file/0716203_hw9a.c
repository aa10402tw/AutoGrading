#include <stdio.h>

int SUM(/* Write your code here */int n);

int main(){
	/* Write your code here */
	int n;
	scanf("%d",&n);
	int sum=SUM(n);
	printf("%d",sum);

	return 0;
}

int SUM(int n){
	/* Write your code here */
	int result=0;
	if(n==1)
        return 1;
	return (n+SUM(n-1));
}
