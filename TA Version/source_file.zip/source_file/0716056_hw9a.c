//
//  main.c
//  0716056_hw9a
//
//  Created by 王孜甄 on 2018/11/19.
//  Copyright © 2018 eliawang_. All rights reserved.
//

#include <stdio.h>

int SUM(/* Write your code here */int n);

int main(){
    /* Write your code here */
    int n;
    scanf("%d",&n);
    printf("%d",SUM(n));
    return 0;
}

int SUM(/* Write your code here */int n){
    /* Write your code here */
   if (n==1)
       return 1;
   else return n+SUM(n-1);
    
}
