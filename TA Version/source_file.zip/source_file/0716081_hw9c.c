#include <stdio.h>

void swap(int *a, int *b)
{
    int t = *a;
    *a = *b;
    *b = t;
}

void sort(int *a, int len)
{

    for(int i=len-1 ; i>0 ; i--)
    {
        for(int j=0 ; j<i ; j++)
        {
            if(a[j] > a[j+1])
            {
                swap(&a[j], &a[j+1]);
            }
        }
    }
}

int binary_search(int a[], int min, int max, int n);

int main(void)
{
    int n,a[100], target;

    scanf("%d", &n);
    for(int i=0; i<n; i++)
    {
        scanf("%d", &a[i]);
    }
    scanf("%d", &target);

    sort(a, n);
    printf("%d", binary_search(a, 0, n-1, target));

    return 0;
}

int binary_search(int a[], int min, int max, int n)
{
    if(min == max && a[(min+max)/2] != n)
        return -1;
    else if(a[(min+max)/2] == n)
        return (min+max)/2;
    else if(a[(min+max)/2] < n)
        return binary_search(a, (min+max)/2+1, max, n);
    else if(a[(min+max)/2] > n)
        return binary_search(a, min, (min+max)/2-1, n);

}
