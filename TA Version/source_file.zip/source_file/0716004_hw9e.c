//
//  main.c
//  0716004_hw9e.c
//
//  Created by 成文瑄 on 2018/11/20.
//  Copyright © 2018年 成文瑄. All rights reserved.
//

#include<stdio.h>
#include<string.h>

int used[11] = { 0 };   //used紀錄字串中的自有沒有被使用過 若沒有：0 若有：1
char goal[11];  //儲存要印出來的東西
int num = 0;  //j是紀錄已經取了幾個數字

void permute(char ch[], int len);

int main() {
    int i,j;
    char tmp;
    char a[11];
    scanf("%s", a);
    int len = strlen(a);
    for( i=0; i<len; i++){
        for( j=0; j<(len-i-1); j++){
            if(a[j]>a[j+1]){
                tmp=a[j];
                a[j]=a[j+1];
                a[j+1]=tmp;
            }
            
        }
    }
    permute(a, len);
    return 0;
}
void permute( char str[], int len) {
    int i;
    for ( i=0; i<len; i++) {
        while( used[i]==1)
            i++;
        if (i!=len) {
            used[i] = 1;
            goal[num] = str[i];
            num++;
            if ( num==len)
                printf("%s\n",goal);
            permute(str, len);
            num--;
            used[i] = 0;
            
        }
       
            
    }
}
