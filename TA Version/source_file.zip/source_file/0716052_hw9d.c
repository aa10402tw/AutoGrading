//0716052_hw9d
#include <stdio.h>
#include <stdlib.h>

void hanoi(int *nN, int *nTime);

int main() {
	int nN, nTime;
	scanf("%d", &nN);
	nTime = 0;
	hanoi(&nN, &nTime);
	printf("%d\n", nTime);

	//system("pause");
	return 0;
}

void hanoi(int *nN, int *nTime) {
	int temp1, temp2;
	temp1 = *nN - 1;
	temp2 = 1;

	if (*nN == 1)
		(*nTime)++;
	else {
		hanoi(&temp1, nTime);
		hanoi(&temp2, nTime);
		hanoi(&temp1, nTime);
	}
}