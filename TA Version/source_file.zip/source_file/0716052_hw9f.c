//0716052_hw9f
#include <stdio.h>
#include <stdlib.h>

void queens(int x, int nN, char cRow[15], char cDiagonal[28], char cBackDiagonal[28], int *nAns);

int main() {
	int nN, nAns, i;
	char cRow[15], cDiagonal[28], cBackDiagonal[28];
	scanf("%d", &nN);

	//��l�O���ѽL���}�C�B���׼�
	for (i = 0; i < nN; i++){
		cRow[i] = 0;
	}
	for (i = 0; i < 2 * nN - 1; i++) {
		cDiagonal[i] = 0;
		cBackDiagonal[i] = 0;
	}
	nAns = 0;

	queens(0, nN, cRow, cDiagonal, cBackDiagonal, &nAns);
	printf("%d\n", nAns);
	
	//system("pause");
	return 0;
}

void queens(int x, int nN, char cRow[15], char cDiagonal[28], char cBackDiagonal[28], int *nAns) {
	int i, nDiagnal, nBackDiagnal;
	if (x < nN) {
		for (i = 0; i < nN; i++) {
			nDiagnal = nN - 1 - x + i;
			nBackDiagnal = x + i;

			if (cRow[i] == 0 && cDiagonal[nDiagnal] == 0 && cBackDiagonal[nBackDiagnal] == 0) {
				cRow[i] = 1;
				cDiagonal[nDiagnal] = 1;
				cBackDiagonal[nBackDiagnal] = 1;

				queens(x + 1, nN, cRow, cDiagonal, cBackDiagonal, nAns);

				cRow[i] = 0;
				cDiagonal[nDiagnal] = 0;
				cBackDiagonal[nBackDiagnal] = 0;
			}
			
		}
		
	}
	else {
		(*nAns)++;
	}
	
}