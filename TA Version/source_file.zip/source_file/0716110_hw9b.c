#include <stdio.h>

int GCD(int a,int b,int k);


int main(){
   /* Write your code here */
   int a,b;
   scanf("%d %d",&a,&b);
   if(b>a){
    int temp = b;
    b = a;
    a = temp;
   }
    int result=1;
   printf("%d",GCD(a,b,result));
    return 0;
}

int GCD(int a,int b,int result){
    /* Write your code here */

    int resulta=1 ,resultb=1;

    for(int i = 2;i<=b;i++){

        if(a%i == 0 && b%i == 0){
            resulta = a/i;
            resultb = b/i;
            result *= i;
           return GCD(resulta,resultb,result);
        }
    }

    return result;



}
