#include <stdio.h>
#include<string.h>
void permute(int n,char c[]);
int main(){
    char s[16];
    scanf("%s",&s);
    for(int i=0;i<strlen(s)-1;i++){
        for(int j=0;j<strlen(s)-1;j++){
            if(s[j+1]<s[j]){
                int temp=s[j+1];
                s[j+1]=s[j];
                s[j]=temp;
            }
        }
    }
    permute(0,s);
return 0;
}

void permute(int n,char c[]){
    int i,temp,j;
    if(n==strlen(c)-1)
    {
        printf("%s\n",c);
    }
    else
    {
        for(i=n;i<strlen(c);i++){
        for(j=i;j>n;j--)
        {
            temp=c[j];
            c[j]=c[j-1];
            c[j-1]=temp;
        }
        permute(n+1,c);
        for(j=n;j<i;j++){
            temp=c[j];
            c[j]=c[j+1];
            c[j+1]=temp;
        }
}}}
