#include <stdio.h>

int GCD(int a , int b);

int main(){
   int a , b;
   while( scanf ( "%d %d", &a , &b ) == 2 ){
    printf( "%d\n" , GCD( a , b ) );
   }
}

int GCD(int a , int b){
    if(a%b == 0) return b;
    else return GCD( b , a%b );
}
