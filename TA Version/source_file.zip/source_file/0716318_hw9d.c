#include <stdio.h>
void hanoi(int N,char A,char B,char C/* Write your code here */);
int time=0,N;
int main() {
    /* Write your code here */

    scanf("%d",&N);
    hanoi(N,'A','B','C');
    printf("%d",time);
    return 0;
}

void hanoi(int N,char A,char B,char C/* Write your code here */){
    /* Write your code here */
    if (N==1)
        time++;
    else
    {
        hanoi(N-1,A,C,B);
        time++;
        hanoi(N-1,B,A,C);
    }
}
