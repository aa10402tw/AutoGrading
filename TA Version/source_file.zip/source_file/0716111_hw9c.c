#include <stdio.h>

int binary_search(int n1,int n2,int a[],int b);

int main(void)
{
    int n;
    scanf("%d",&n);
    int a[n];
    for(int i=0; i<n; i++)
    {
        scanf("%d",&a[i]);
    }
    for(int i=0; i<n; i++)
    {
        for(int j=n-1; j>i; j--)
        {
            if(a[j]<a[j-1])
            {
                int tmp=a[j];
                a[j]=a[j-1];
                a[j-1]=tmp;
            }
        }
        //printf("%d",a[i]);
    }
    int b;
    scanf("%d",&b);
    int e = binary_search(0,n-1,a,b);
    printf("%d",e);
}

int binary_search(int n1,int n2,int a[],int b)
{

    if (a[(n1+n2)/2]==b)
    {
        return (n1+n2)/2;
    }
    if (a[(n1+n2)/2]>b)
    {

        int d[(n1+n2)/2-n1];
        for(int i=n1; i<(n1+n2)/2; i++)
        {
            d[i-n1]=a[i];
        }
        return binary_search(n1,(n1+n2)/2-1,d,b);
    }
    if (a[(n1+n2)/2]<b)
    {

            if (a[n2]==b){
                return n2;
            }

        int d[n2-(n1+n2)/2];
        for(int i=(n1+n2)/2+1; i<=n2; i++)
        {
            d[i-(n1+n2)/2-1]=a[i];
        }
        return binary_search((n1+n2)/2+1,n2,d,b);

    }
}
