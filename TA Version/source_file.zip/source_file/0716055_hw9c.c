#include <stdio.h>

int binary_search(int a,int arr[],int f,int l);
void qsort(void *base, size_t nitems, size_t size, int (*compar)(const void *, const void*));
int cmp(const void *a, const void *b);
int main(void){
    int n,a;
    scanf("%d",&n);
    int arr[n];
    for (int i=0; i<n; i++) {
        scanf("%d",&arr[i]);
    }
    qsort(arr, n, sizeof(int), (cmp));
    scanf("%d",&a);
    printf("%d\n",binary_search(a, arr, 0, n-1));
    
}

int binary_search(int a,int arr[],int f,int l){
    int m=(l+f)/2+0.5;
    if (l-f!=1) {
        if(a>arr[m]){
            return binary_search(a, arr, m, l);
        }else if (a<arr[m]){
            return binary_search(a, arr, f, m);
        }else {
            return m;
        }
    }else{
        if (a==arr[l]) {
            return l;
        }else if(a==arr[f]){
            return f;
        }else{
            return -1;
        }
    }
}
int cmp(const void *a, const void *b){
    return *(int*)a-*(int*)b;
}
