#include <stdio.h>

int GCD(int,int);

int main(){
   int x,y;

   scanf("%d %d",&x,&y);

   printf("%d",GCD(x,y));

   return 0;
}

int GCD(int x,int y){
    
    if(y==0)
        return x;
    else
        return GCD(y,x%y);
        
}