#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void perm(int*, int, int, void (*take)(int*,int N));
void rotate(int*, int, int);
void copy(int*, int*, int);
void print(int*,int N);

int main(void) {
    char a[100];
    scanf("%s",a);
    int len=strlen(a);
    int num[len];
    int i;
	for(i=0;i<len;i++){
    	num[i]=((int)a[i]);
	}
	int idx,j,temp;
	for(i=0;i<len;i++){
        idx=i;
		for(j=idx+1;j<len;j++){
			if(num[idx]>num[j]){
                idx=j;
			}
		}
		if(idx!=i){
            temp=num[i];
            num[i]=num[idx];
            num[idx]=temp;
		}
	}
    perm(num, 0, len, print);
    return 0;
}

void perm(int* num, int i, int N, void (*take)(int*,int N)) { //take���Vprint
    if(i < N) {
        int j;
        for(j = i; j < N; j++) {
            int to[N];
            copy(num, to, N);
            rotate(to, i, j);
            perm(to, i + 1, N, take);
        }
    }
    else {
		take(num,N);
	}
}
//��̫�@��(j)���e��(i)�h��
void rotate(int* num, int i, int j) {
    int tmp = num[j];
    int k;
    for(k = j; k > i; k--) {
        num[k] = num[k - 1];
    }
    num[i] = tmp;
}

void copy(int* from, int* to, int N) {
    int i;
    for(i = 0; i < N; i++) {
        to[i] = from[i];
    }
}

void print(int* num,int N) {
    int i;
	for(i = 0; i < N; i++) {
        printf("%c",(char)(num[i]));
    }
    printf("\n");
}
