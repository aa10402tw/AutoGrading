#include <stdio.h>

int binary_search(int l, int r, int a[], int want);

int main(void)
{
   /* Write your code here */
   int n;
   scanf("%d", &n);
   int a[n];
   for (int i = 0; i < n; i++)
   {

      scanf("%d", &a[i]);
      int k = i - 1;
      int p = a[i];
      while (k >= 0 && a[k] > p)
      {
         int j = k;
         //if(a[j]<p){
         a[++j] = a[k];
         //}

         k--;
      }
      a[++k] = p;
   }

   // for (int i = 0; i < n; i++){
   //    printf("%d ",a[i]);
   // }
   int want;
   scanf("%d", &want);
   //int ans;
   binary_search(0, n - 1, a, want);
   //printf("%d", ans);
   return 0;
}

int binary_search(int l, int r, int a[], int want)
{
   /* Write your code here */
   int m = (l + r) / 2;
   //printf("m = %d\n", m);

   if (l>r)
   {
      printf("-1");

      return -1;
   }
   if (want > a[m])
   {
      binary_search(m + 1, r, a, want);
   }
   else if (want < a[m])
   {
      binary_search(l, m - 1, a, want);
   }
   else
   {
      printf("%d", m);

      return m;
   }
   return 0;
   // else
   // {
   //    printf("-1");

   //    return -1;
   // }
   //return -1;
}