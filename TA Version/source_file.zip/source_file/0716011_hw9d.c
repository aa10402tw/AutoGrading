#include <stdio.h>
int output=0;
void hanoi(int n);

int main() {
    int n;
    scanf("%d",&n);
    hanoi(n);
    printf("%d",output);/* Write your code here */
    return 0;
}

void hanoi(int n){
    if(n==1)output+= 1;
    else  hanoi(n-1),hanoi(n-1),output++;
    /* Write your code here */
}
