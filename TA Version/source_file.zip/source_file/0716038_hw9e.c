#include <stdio.h>
#include<string.h>

char f[720][6]={'0'};
int ss=0;
void permute(/* Write your code here */);

void swap(char *a, char *b)
{
    char c;
    c=*a;
    *a=*b;
    *b=c;
}

int main()
{
    char *t;
    int l,m,n,min;
    char element[11];
    int len;
    gets(element);
    len=strlen(element);
    permute(0,len,element);

    for(l=0,n=0; l<ss; l++)
    {
        min=l;
        for(m=l+1; m<ss; m++)
        {
            if((f[min][n]>f[m][n])||(((int)f[min][n]==(int)f[m][n])&&((int)f[min][n+1]>(int)f[m][n+1])))
            {
                min=m;
            }
        }
        strcpy(t,f[l]);
        strcpy(f[l],f[min]);
        strcpy(f[min],t);
    }
    for(l=0; l<ss; l++)
    {
        min=l;
        for(m=l+1; m<ss; m++)
        {
            if(strncmp(f[min],f[m],len)>0)
            {
                min=m;
            }
        }
        strcpy(t,f[l]);
        strcpy(f[l],f[min]);
        strcpy(f[min],t);
    }




    for(m=0; m<ss; m++)
    {
        for(n=0; n<len; n++)
        {
            printf("%c",f[m][n]);
        }
        printf("\n");
    }
    return 0;
    /* Write your code here */
}

void permute(int a,int b,char element[]/* Write your code here */)
{
    int i;
    int k;
    if(b==1)
    {
        printf("%c\n",element[a]);
    }
    else if(b==2)
    {

        for(i=0; i<a; i++)
        {
            f[ss][i]=element[i];

        }
        f[ss][a]=element[a];
        f[ss][a+1]=element[a+1];

        ss++;
        for(i=0; i<a; i++)
        {
            f[ss][i]=element[i];

        }
        f[ss][a]=element[a+1];
        f[ss][a+1]=element[a];

        ss++;
    }
    else
    {
        for(k=0; k<b; k++)
        {
            swap(&element[a],&element[a+k]);
            permute(a+1,b-1,element);
            swap(&element[a],&element[a+k]);
        }
    }
    /* Write your code here */
}
