#include <stdio.h>
#include<string.h>
void permute(char a[],int b,int c/* Write your code here */);
void carry(char a[], int b, int c);
void qsort(char a[]);
int main(){

    char a[100]={};

    scanf("%s",&a);
     qsort(a);

    permute(a,0,strlen(a)-1);

    /* Write your code here */
}
int n=0;
void permute(char a[],int b,int c/* Write your code here */){
    if(b==c)
    {
        printf("%s\n",a);
    }
    for(int i=b;i<strlen(a);i++)
    {
        carry(a,b,i);
        permute(a,b+1,c);
        carry(a,i,b);

    }
        /* Write your code here */
}
void carry(char a[],int b,int c)
{
    char temp;
    if(c>b)
    {
        for(int i=c;i>b;i--)
        {
            temp=a[i-1];
            a[i-1]=a[i];
            a[i]=temp;
        }
    }
    else
    {
        for(int i=c;i<b;i++)
        {
            temp=a[i+1];
            a[i+1]=a[i];
            a[i]=temp;
        }
    }
}
void swap(char* a,char* b)
{
    char temp;
    temp = *a;
    *a=*b;
    *b=temp;
}
void qsort(char a[])
{
    for(int i=0;i<strlen(a)-1;i++)
    {
        for(int j=i;j<strlen(a)-1;j++)
        {
            if(a[j]>a[j+1])swap(&a[j],&a[j+1]);
        }
    }
}
