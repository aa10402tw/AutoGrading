#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int cmp(const void*a,const void*b){
    return strcmp((char*)a,(char*)b);
}
void swap(char *a,char *b){
        char temp=*a;
        *a=*b;
        *b=temp;
}
void rotation(char *s,int left,int right){
    int i;
    char temp=*(s+right);
    for(i=right;i>=left;i--){
        *(s+i)=*(s+i-1);
    }
    *(s+left)=temp;
}
void reverse_rotate(char *s,int left,int right){
    int i;
    char temp=*(s+left);
    for(i=left;i<=right;i++){
        *(s+i)=*(s+i+1);
    }
    *(s+right)=temp;
}
void permute(char *s,int left,int right);

int main(){
    char s[10]={"\0"};
    scanf("%s",s);
    qsort(s,strlen(s),sizeof(s[0]),cmp);
    permute(s,0,strlen(s));

    return 0;
}

void permute(char *s,int left,int right){
    int i;
    if(left==right)
        printf("%s\n",s);
    else{
        for(i=left;i<right;i++){
            rotation(s,left,i);
            permute(s,left+1,right);
            reverse_rotate(s,left,i);
        }
    }
}
