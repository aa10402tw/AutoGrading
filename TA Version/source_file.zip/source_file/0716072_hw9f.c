#include <stdio.h>
#include <stdbool.h>

int input,output=0;
int chess_board[1000]={};


void queens();

bool check(int n){
    int re=1;
    for(int i=0;i<n-1;i++){
        if(chess_board[n-1]==chess_board[i]){
            re--;
            break;
        }
        else if(chess_board[n-1]-n+1==chess_board[i]-i){
            re--;
            break;
        }
        else if(chess_board[n-1]+n-1==chess_board[i]+i){
            re--;
            break;
        }
    }
    return re;
}


int main(){ 
    scanf("%d",&input);
    queens(0);
    printf("%d\n",output);

}

void queens(int n){
    if(check(n)){
        if(!n){
            for(int i=0;i<input/2;i++){
                chess_board[n]=i;
                queens(n+1);
            }
            output*=2;
            if(input%2){
                chess_board[n]=input/2;
                queens(n+1);
            }
        }
        else if(n<input){
            for(int i=0;i<input;i++){
                chess_board[n]=i;
                queens(n+1);
            }
        }
        else{
            output++;
        }
    }
}


//cd "/Users/jia/Desktop/hwjson/" && gcc 0716072_hw9f.c -o 0716072_hw9f && "/Users/jia/Desktop/hwjson/"0716072_hw9f
