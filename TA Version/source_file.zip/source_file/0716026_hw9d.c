#include <stdio.h>
int ans=0;
void hanoi(/* Write your code here */int );

int main() {
    /* Write your code here */
    int n;
    scanf("%d",&n);
    hanoi(n);
    printf("%d",ans);
} 

void hanoi(/* Write your code here */int n){
    /* Write your code here */
    if(n==1)
    {
    	ans+=1;
	}
	else
	{
		hanoi(n-1);
		ans+=1;
		hanoi(n-1);
	}
}
