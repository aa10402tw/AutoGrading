#include <stdio.h>
void hanoi(int ,int* );

int main() {
    int n,t=1;
    scanf("%d",&n);
    hanoi(n,&t);

    return 0;

}

void hanoi(int n,int *t){
    if(n==0){
        printf("%d",*t-1);
        return;
    }

    *t*=2;
    hanoi(n-1,t);
}

