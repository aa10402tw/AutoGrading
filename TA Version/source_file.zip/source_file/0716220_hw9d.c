#include <stdio.h>
#include<stdlib.h>
int answer=0;//���q��0
void hanoi(/* Write your code here */int b);

int main() {
    /* Write your code here */
    int  a;
    scanf("%d",&a);
    hanoi(a);
    printf("%d",answer);

return 0;
}

void hanoi(int b/* Write your code here */){//void �禡���^�ǭ�
    /* Write your code here */
    if(b==1)
    {answer+=1;}
	else
	{
		hanoi(b-1);
		answer+=1;
		hanoi(b-1);
	}
return ;
}
