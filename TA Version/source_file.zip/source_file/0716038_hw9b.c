#include <stdio.h>

int GCD(/* Write your code here */);

int main()
{
    int x,a,b;
    scanf("%d %d",&a,&b);
    x=GCD(a,b);
    printf("%d",x);
    return 0;
    /* Write your code here */
}

int GCD(int m,int n/* Write your code here */)
{
    if(n == 0)
    {
        return m;
    }
    else
    {
        return GCD(n, m % n);
    }

    /* Write your code here */
}
