#include <stdio.h> 

int binary_search(int x, int y, int* a, int search);

int main(void){
	/* Write your code here */
    int n, num, temp;
    scanf("%d",&n);
    
    int b[n];
    for (int i=0; i<n; i++) {
        scanf("%d", &b[i]);
  //      printf("%d\n",b[i]);
    }
    for(int i=0; i<n; i++){
        for(int j=i+1; j<n; j++){
            if(b[i]>b[j]){
                temp = b[i];
                b[i] = b[j];
                b[j] = temp;
            }
        }
    }


    scanf("%d", &num);
    
    printf("%d\n", binary_search(0, n-1, b, num));
}

int binary_search(int x, int y ,int* a, int search){
   /* Write your code here */
    int m;
    m = (x+y)/2;
    if(x<=y){
        if(search == a[m])
            return m;
        else if(search > a[m]){
            return binary_search(m+1, y, a, search);
        }
        else if(search < a[m]){
            return binary_search(x, m-1, a, search);
        }
    }
    return -1;
}
