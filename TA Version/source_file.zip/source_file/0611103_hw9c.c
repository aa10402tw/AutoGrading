#include<stdio.h>
int binary_search(int s, int num[], int start, int end);
int main(void){
	int n;
	scanf("%d", &n);
	int num[n];
	int i;
	for(i=0;i<n;i++){
		scanf("%d", &num[i]);
	}
	int j, t;
	for(i=0;i<n-1;i++){
		for(j=i+1;j<n;j++){
			if(num[i]>num[j]){
				t=num[i];
				num[i]=num[j];
				num[j]=t;
			}
		}
	}
	int s;
	scanf("%d", &s);
	printf("%d", binary_search(s, num, 0, n-1));
	return 0;
}

int binary_search(int s, int num[], int start, int end){
	if(start>=end && num[start]!=s){
		return -1;
	}
	int mid=start+(end-start)/2;
	if(num[mid]>s){
		return binary_search(s, num, start, mid-1);
	}
	else if(num[mid]<s){
		return binary_search(s, num, mid+1, end);
	}
	else{
		return mid;
	}
}
