#include <stdio.h>
#include <string.h>

void permute(/* Write your code here */);

int main(){
    
    char s[10]={},r[10]={};
    int c[10]={0};
    scanf("%s",s);
    int l=strlen(s);
    for (int i=l-1; i>0; i--) {
        for (int j=0; j<i; j++) {
            if (s[j]>s[j+1]) {
                char tmp=s[j+1];
                s[j+1]=s[j];
                s[j]=tmp;
            }
        }
    }
    for (int i=0; i<l; i++) {
        c[i]=1;
    }
    permute(s, c, r, 0, l);
    return 0;
    
}

void permute(char *s,int *c,char *r,int l,int k){
    if (l==strlen(r)&& strlen(r)==k) {
        printf("%s\n",r);
    }
    for (int i=0; i<strlen(s); i++) {
        if (c[i]==0) {
            continue;
        }
        r[l]=s[i];
        c[i]--;
        permute(s, c, r, l+1, k);
        c[i]++;
    }
}

