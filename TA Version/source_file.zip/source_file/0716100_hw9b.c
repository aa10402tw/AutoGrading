#include <stdio.h>

int GCD(int x, int y/* Write your code here */);

int main(){
   /* Write your code here */
   int x;
   int y;
   scanf("%d %d", &x, &y);
   printf("%d", GCD(x, y));
   return 0;
}

int GCD(int x, int y/* Write your code here */){
    /* Write your code here */
    if(x % y == 0)
        return y;
    else
        return GCD(y, x % y);
}
