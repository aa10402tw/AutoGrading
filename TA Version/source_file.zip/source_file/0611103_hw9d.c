#include <stdio.h>
int m=0;
void hanoi(int n, char beg, char aux, char end);

int main() {
	int n;
	scanf("%d", &n);
	hanoi(n, 'a', 'b', 'c');
	printf("%d", m);
	return 0;
} 

void hanoi(int n, char beg, char aux, char end){
	if(n==1) m++;
	else{
		hanoi(n-1, beg, end, aux);
		m++;
		hanoi(n-1, aux, beg, end);
	}
}
