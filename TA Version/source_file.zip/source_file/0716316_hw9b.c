#include <stdio.h>

int GCD(int,int);

int main(){
   /* Write your code here */
   int a,b;
   scanf("%d %d",&a,&b);
   printf("%d",GCD(a,b));
   return 0;
}

int GCD(int a,int b){
    /* Write your code here */
    if(a!=0&&b!=0){
    	if(a>=b){
    		a=a%b;
    		GCD(a,b);
    		//return ;
		}
		else if(b>a){
			b=b%a;
			GCD(a,b);
			//return ;
		}
	}
	else{
		if(a>=b){
		return a;
	}
	else{
		return b;
	}
	}
	
}
