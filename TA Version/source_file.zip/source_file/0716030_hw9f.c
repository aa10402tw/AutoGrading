#include<stdio.h>
#include<string.h>
#define debug 0
int answer=0;


void queens(char qu[14][15],int max,int i);

void seal(char a[14][15],int max,int i,int j)
{

#if debug
    printf("\n\n封印函式進入\n");
    printf("i=%d\n",i);
    printf("j=%d\n",j);
    for(int z=0; z<max; z++)
    {
        for(int x=0; x<max; x++)
        {
            printf("%c ",a[z][x]);
        }
        printf("\n");
    }
#endif // debug

#if debug
    printf("In seal\n");
    printf("max=%d",max);
#endif // debug
    int l,r;
    l=j;
    r=j;

    for(int p=i+1; p<max; p++)
    {
        r++;
        l--;
        //printf("處理前%c",a[p][j]);

        a[p][j]='1';
        //printf("處理後%c",a[p][j]);

        if(r<max)
            a[p][r]='1';
        if(l>=0)
            a[p][l]='1';

    }





#if debug

    printf("封印函式處理後\n");
    for(int z=0; z<max; z++)
    {
        for(int x=0; x<max; x++)
        {
            printf("%c ",a[z][x]);
        }
        printf("\n");
    }
#endif // debug


    //printf("封印函式結束\n\n\n\n");
}

int main()
{
    char qu[14][15];
    memset(qu,'0',sizeof(qu));

    int i_input;

    scanf("%d",&i_input);
    queens(qu,i_input,0);
    printf("%d",answer);
}

void queens(char qu[14][15],int max,int i)
{
    char tem[14][15];

    /*printf("以下為tem");
    for(int z=0;z<max;z++){
    for(int x=0;x<max;x++){
        printf("%c ",tem[z][x]);
    }
    printf("\n");
    }
    */


    /*#if debug
    for(int z=0;z<max;z++){
        for(int x=0;x<max;x++){
            printf("%c ",qu[z][x]);
        }
        printf("\n");
    }
    #endif // debug
    */


    for(int g=0; g<max; g++)
    {

        /*#if debug
        printf("Hello1\n");
        #endif // debug
        */
        //printf("[%d][%d]=%c\n",i,g,qu[i][g]);
        if(qu[i][g]=='0')
        {
            //printf("[%d][%d]=%c 有執行",i,g,qu[i][g]);
            if(i==max-1)
            {
                answer++;
                return;

                /* #if debug
                 printf("Hello3\n");
                 #endif // debug
                 */
            }

            /*#if debug
            printf("Hello4\n");
            printf("[%d] [%d]=%c",i,g,qu[i][g]);
            #endif // debug
            */
            memcpy(tem,qu,sizeof(tem));

            /*printf("\n\n以下為tem\n");
            printf("i=%d j=%d\n",i,g);
            for(int z=0; z<max; z++)
            {
                for(int x=0; x<max; x++)
                {
                    printf("%c ",tem[z][x]);
                }


                printf("\n");
            }
            printf("\n\n\n");
            */

            seal(qu,max,i,g);
            queens(qu,max,i+1);
            //memset(qu,0,sizeof(qu));
            //memcpy(qu,tem,sizeof(qu));
            for(int y=0;y<max;y++){
                for(int u=0;u<max;u++){
                    qu[y][u]=tem[y][u];
                }
            }


            /*printf("\n\n以下為回來[%d][%d]之後的tem\n",i,g);
            printf("i=%d j=%d\n",i,g);
            for(int q=0; q<max; q++)
            {
                for(int w=0; w<max; w++)
                {
                    printf("%c ",tem[q][w]);
                }

                printf("\n");

            }
            for(int q=0; q<max; q++)
            {
                for(int w=0; w<max; w++)
                {
                    printf("%c ",qu[q][w]);
                }

                printf("\n");

            }*/
        }






    }
}
