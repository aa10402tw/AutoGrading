#include <stdio.h>

int SUM(int n);

int main()
{
	/* Write your code here */
	int n;
	int pricesSize;

	//scanf("%d", &pricesSize);
	scanf("%d", &n);
	//printf("%d", n);

	int s;
	//s = SUM(n);
	printf("%d", SUM(n));
	return 0;
}

int SUM(int n)
{
	/* Write your code here */
	int s = 0;
	if(n==1){
		return 1;
	}
	//int a;
	//printf("%d", n);
	//a = n + SUM(n - 1);
	//s += a;

	s += (n+SUM(n-1));
	return s;
}