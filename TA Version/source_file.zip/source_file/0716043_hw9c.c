#include <stdio.h>

int binary_search(int[], int, int, int);

int main(void)
{
    int n, a[100], b, i, j, temp;
    scanf("%d", &n);
    for(i = 0; i < n; i++)
    {
        scanf("%d", &a[i]);
    }
    scanf("%d", &b);
    for(i = 0; i < n; i++)
    {
        for(j = i + 1; j < n; j++)
        {
            if(a[i] > a[j])
            {
                temp = a[i];
                a[i] = a[j];
                a[j] = temp;
            }
        }
    }
    printf("%d", binary_search(a, b, 1, n));
    return 0;
}

int binary_search(int *a, int b, int c, int d)
{
    int mid;
    if(d >= 1)
    {
        mid =(d - 1) / 2;
        if(a[mid] == b)
        {
            printf("Here\n");
            return mid;
        }
        else if(a[mid] > b)
        {
            printf("Here2\n");
            return binary_search(a, b, 1, mid - 1);
        }
        else if(a[mid] < b)
        {
            printf("Here3\n");
            return binary_search(a, b, mid + 1, d);
        }
    }
    return -1;
}
