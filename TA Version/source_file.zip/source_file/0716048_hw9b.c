#include <stdio.h>

int GCD(int n1,int n2/* Write your code here */);

int main(){
    int num1,num2;
    scanf("%d %d",&num1,&num2);
    printf("%d",GCD(num1,num2));
    return 0;
   /* Write your code here */
}

int GCD(int n1,int n2/* Write your code here */){
    if(n1%n2==0){
        return n2;
    }
    else{
        return GCD(n2,n1%n2);
    }
    /* Write your code here */
}
