#include <stdio.h>
#include <stdlib.h>

int ans=0;
void hanoi(int n);

int main()
{
   int num;
   scanf("%d",&num);
   hanoi(num);
   printf("%d",ans);
   return 0;
}

void hanoi(int n)
{
   if(n>1)
   {
      hanoi(n-1);
      hanoi(n-1);
      ans++;
   }
   else
   {
      ans++;
      return;
   }
}
