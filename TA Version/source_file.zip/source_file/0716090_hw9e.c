#include <stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>

void permute(char [],int/* Write your code here */);

int main(){
    /* Write your code here */
    int i,j,min;
    char str[100];
    scanf("%s",str);
    for(i=0;i<strlen(str);i++){
        min=str[i];
        for(j=i+1;j<strlen(str);j++){
            if(str[j]<min){
                min=str[j];
                str[j]=str[i];
                str[i]=min;
            }
        }
    }
    permute(str,strlen(str));
    return 0;
}

void permute(char str[100],int x/* Write your code here */){
    /* Write your code here */
    int i,j;
    char tmp;
    int k=strlen(str)-x;
    if(x==2){
        int flag=0;
        for(i=k;i<strlen(str)-1;i++){
            for(j=strlen(str)-1;j>i;j--){
                if(str[j]<str[j-1]){
                    tmp=str[j];
                    str[j]=str[j-1];
                    str[j-1]=tmp;
                    flag++;
                }
            }
        }
        printf("%s\n",str);
        tmp=str[k];
        str[k]=str[strlen(str)-1];
        str[strlen(str)-1]=tmp;
        flag++;
        printf("%s\n",str);
        if(flag==1){
            tmp=str[k];
            str[k]=str[strlen(str)-1];
            str[strlen(str)-1]=tmp;
        }
    }
    if(x>2){
        for(i=k;i<strlen(str)-1;i++){
            for(j=strlen(str)-1;j>i;j--){
                if(str[j]<str[j-1]){
                    tmp=str[j];
                    str[j]=str[j-1];
                    str[j-1]=tmp;
                }
            }
        }
        for(i=k;i<strlen(str);i++){
            tmp=str[k];
            str[k]=str[i];
            str[i]=tmp;
            permute(str,x-1);
            tmp=str[k];
            str[k]=str[i];
            str[i]=tmp;
        }
        for(i=k;i<strlen(str)-1;i++){
            for(j=strlen(str)-1;j>i;j--){
                if(str[j]<str[j-1]){
                    tmp=str[j];
                    str[j]=str[j-1];
                    str[j-1]=tmp;
                }
            }
        }

    }

}

