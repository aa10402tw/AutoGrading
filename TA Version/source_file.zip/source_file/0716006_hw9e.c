#include <stdio.h>
#include <string.h>
void permute(int,int,char[]);
char ans[][1000];
void swap(char *a,char *b){
    char c;
    c = *a;
    *a = *b;
    *b = c;
}
void sort(int a,int b,char per[]){
    int i,j;
    for(i=a;i<b;i++){
        for(j=0;j<b;j++){
            if(per[a]>per[a+1])
                swap(&per[a],&per[a+1]);
        }
    }

}
int main(){
   char input[100];
   gets(input);
   int len = strlen(input);
   int i,j,tmp;
   for(i=0;i<len-1;i++){
    for(j=0;j<len-1;j++){
        if(input[j]>input[j+1])
        {
          tmp = input[j];
          input[j] = input[j+1];
          input[j+1] = tmp;
        }
    }
   }
    permute(0,len-1,input);
   return 0;
}

void permute(int i,int n,char per[]){
    int k;
    if(i==n){
        for(k=0;k<=n;k++){
            printf("%c",per[k]);
        }
        printf("\n");
    }
    else{
        for(k=i;k<=n;k++){
            swap(&per[i],&per[k]);
            sort(i+1,n,per);
            permute(i+1,n,per);
            swap(&per[i],&per[k]);
        }
    }
}
            /*for(j=n-1;j>0;j--){
                if(per[j] < per[j-1])
                    swap(&per[j-1] , &per[j]);
            }*/
