//
//  main.c
//  0716004_hw9b.c
//
//  Created by 成文瑄 on 2018/11/20.
//  Copyright © 2018年 成文瑄. All rights reserved.
//

#include <stdio.h>
#define min( x, y) ((x)>(y)? (y): (x))
#define max( x, y) ((x)>(y)? (x): (y))

int GCD(int n1, int n2);

int main(){
    /* Write your code here */
    int n1, n2;
    scanf("%d%d", &n1, &n2);
    printf("%d", GCD( n1, n2));
    
}

int GCD( int n1, int n2){   //輾轉相除法
    /* Write your code here */
    if( n1%n2==0 || n2%n1==0)
        return min( n1, n2);
    else 
        return GCD((max( n1, n2)% min( n1, n2)), min( n1, n2));
}

