#include <stdio.h>

int binary_search(int l,int r,int n,int *a,int x/* Write your code here */);
int sort (int n,int *a);
int main(void){
    int n,i,x;
    scanf("%d",&n);
    int a[n];
    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    scanf("%d",&x);
    sort(n,a);
    printf("%d",binary_search(0,n-1,n,a,x));
    return 0;
	/* Write your code here */
}
int sort (int n,int*a){
int i,j,t;
for(i=0;i<n;i++){
    for(j=0;j<n-1;j++){
        if(a[j]>a[j+1]){
            t=a[j];
            a[j]=a[j+1];
            a[j+1]=t;
        }
    }
}

}
int binary_search(int l,int r,int n,int *a,int x/* Write your code here */){
    int m;
    if (l>r)    return -1;
        m=(l+r)/2;
    if(x==a[m])   return m  ;
    else if(x<a[m])    return binary_search(l,m-1,n,a,x);
    else if(x>a[m])    return binary_search(m+1,r,n,a,x);

   /* Write your code here */
}
