#include <stdio.h>

int binary_search(int list[], int a, int left, int right);
void sort(int list[], int n);

int main(void){
    /* Write your code here */
    int len, in[100], find;
    scanf("%d", &len);
    for (int i = 0; i < len; i++) {
        scanf("%d", &in[i]);
    }
    sort(in, len);
    scanf("%d", &find);
    printf("%d", binary_search(in, find, 0, len - 1));
    return 0;
}

int binary_search(int list[], int a, int left, int right){
    /* Write your code here */
    if (right >= left) {
        int mid = (right-left)/2+left;
        if (list[mid] == a)
            return mid;
        else if (list[mid] > a)
            return binary_search(list, a, left, mid - 1);
        else
            return binary_search(list, a, mid + 1, right);
    }
    else
        return -1;
}

void sort(int list[], int n)
{
    for (int i = 0 ; i < n - 1; i++)
    {
        for (int j = 0 ; j < n - i - 1; j++)
        {
            if (list[j] > list[j+1])
            {
                int temp  = list[j];
                list[j]   = list[j+1];
                list[j+1] = temp;
            }
        }
    }
}
