#include <stdio.h>

int s = 0;
void hanoi(int n, char A, char B, char C)
{
    if (n == 1)
    {
       s++;
    }
    else
    {
        hanoi(n - 1, A, C, B);
        s++;
        hanoi(n - 1, B, A, C);
    }
}

int main()
{
    int n;
    scanf("%d", &n);

    hanoi(n, 'A', 'B', 'C');

    printf("%d", s);

    return 0;
}
