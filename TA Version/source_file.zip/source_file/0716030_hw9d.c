#include <stdio.h>

void hanoi(int an,int n);

int main() {
int n;
int answer=1;
scanf("%d",&n);
hanoi(answer,n);
}

void hanoi(int an,int n){
   an*=2;
   if(n==1){printf("%d",an-1);
    return;
   }
   hanoi(an,n-1);

}
