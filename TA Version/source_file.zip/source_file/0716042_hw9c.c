#include <stdio.h>
int binary_search(int a[],int down,int up,int po,int len);

int main(void)
{
    int n,c[101],p,flag=0;
    scanf("%d",&n);
    for(int i=0; i<n; i++)
    {
        scanf("%d",&c[i]);
    }
    scanf("%d",&p);
    if(n==1) flag=2;
    for(int i=0; i<n-1; i++)
    {
        for(int j=0; j<n-1; j++)
        {
            if(c[j+1]<c[j])
            {
                int temp=c[j+1];
                c[j+1]=c[j];
                c[j]=temp;
                }if(p==c[j+1]||p==c[j]) flag=1;
        }
    }
    if(flag==0)printf("-1");
    else if(flag==2){
        if(p==c[0])printf("0");
        else printf("-1");
    }
    else printf("%d",binary_search(c,0,n-1,p,n));
    return 0;
}

int binary_search(int a[],int down,int up,int po,int len)
{
    int avg;
    if(len/2!=0)
    {
        avg=(up-down)/2+down;
    }
    else
        avg=(up-down)/2+down+1;
    if(po==a[avg])return avg;
    else if(po>a[avg])binary_search(a,avg+1,up,po,len);
    else if(po<a[avg])binary_search(a,down,avg-1,po,len);
    }

