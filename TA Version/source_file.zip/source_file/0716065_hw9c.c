#include <stdio.h>

int binary_search(int*, int, int);

int main(void){
	int num,_sort[101],i,j,temp,n;
	scanf("%d", &num);
	for(i=0;i<num;i++){
        scanf("%d",&_sort[i]);
	}
	for(i=1;i<num;i++){
        for(j=0;j<num-i;j++){
            if(_sort[j]>_sort[j+1]){
                temp = _sort[j];
                _sort[j]=_sort[j+1];
                _sort[j+1]=temp;
            }
        }
	}
	scanf("%d", &n);
    printf("%d", binary_search(_sort,n,num));
	return 0;
}

int binary_search(int* arr,int target,int num){
    int L = 0, R = num - 1;
    while(L<=R) {
        int mid = (L+R)/2;
        if(arr[mid] == target){
            return mid;
        }
        else if(arr[mid]>target) {
            R = mid - 1;
        }
       else {
            L = mid + 1;
       }
    }
    return -1;
}

