#include <stdio.h>

int GCD(int a,int b);

int main(){
    int k,w;
    while(scanf("%d%d",&k,&w)==2){
        printf("%d\n",GCD(k,w));
    }

    return 0;
}

int GCD(int a,int b){
    int temp;
    if(a<b){
        temp=b;
        b=a;
        a=temp;
    }
    if(b==0){
        return a;
    }
    return GCD(b,a%b);
}
