#include <stdio.h>
#include <stdlib.h>

int binary_search(int arr[], int target, int l, int r);
int compare(const void *a, const void *b);

int main(void){
	int n;
    scanf("%d", &n);
    int arr[n];
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }
    qsort(arr, n, sizeof(int), compare);
    int target;
    scanf("%d", &target);
    int ans = binary_search(arr, target, 0, n);
    printf("%d", ans);
}

int binary_search(int arr[], int target, int l, int r){
   if (l > r) {
       return -1;
   } else {
       int m = (l + r) / 2;
       if (arr[m] == target) {
           return m;
       } else if (arr[m] > target) {
           binary_search(arr, target, l, m - 1);
       } else {
           binary_search(arr, target, m + 1, r);
       }
   }
}

int compare(const void *x, const void *y)
{
    return ( *(int *)x - *(int *)y );
}
