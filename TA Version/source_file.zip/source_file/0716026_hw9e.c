 #include <stdio.h>
#include<string.h>
void swap(char *a,char *b);
void permute(/* Write your code here */char a[],int i,int n);
void swap1(char *x, char *y) 
{ 
    char A=*y;
    char *i;
    for(i=y;i>=x+1;i--){
        *i=*(i-1);
    }
    *x=A;
} 

void swap2(char *x, char *y) 
{ 
    char A=*x;
    char *i;
    for(i=x;i<y;i++){
        *(i)=*(i+1);
    }
    *y=A;
}
void swap(char *a,char *b)
{
	char temp;
	temp=*a;
	*a=*b;
	*b=temp;
}

int main(){ 
    /* Write your code here */
    int i,j;
    char M[9];
    gets(M);
    for(i=1;i<strlen(M);i++)
    {
    	for(j=0;j<strlen(M)-i;j++)
    	{
    		if(M[j]>M[j+1])
    		{
    			swap(M[j],M[j+1]);
			}
		}
	}
    permute(M,0,strlen(M));
    return 0;
}

void permute(/* Write your code here */char *a,int i,int n){  
    /* Write your code here */
    int j;
    if(i==(n-1))
	{
		printf("%s\n",a);
	} 
    else
    {
    	for(j=i;j<n;j++)
    	{
    		swap1((a+i),(a+j));
    		permute(a,i+1,n);
    		swap2((a+i),(a+j));
		}
	}
} 
