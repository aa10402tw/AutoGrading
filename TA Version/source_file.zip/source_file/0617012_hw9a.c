#include <stdio.h>

int SUM(int k);

int main(){
	int n,k;
	scanf("%d",&n);
	k=SUM(n);
	printf("%d",k);
}

int SUM(int k)
{
    if(k==1)
        return 1;
    return SUM(k-1)+k;
}
