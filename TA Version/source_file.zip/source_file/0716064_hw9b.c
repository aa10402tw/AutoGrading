#include <stdio.h>

int GCD(/* Write your code here */int a,int b);

int main(){
   /* Write your code here */
   int c,d;
   scanf("%d %d",&c,&d);
   printf("%d",GCD(c,d));
}

int GCD(/* Write your code here */int a,int b){
    /* Write your code here */
    if(a%b==0) return b;
    else return GCD(b,a%b);
}
