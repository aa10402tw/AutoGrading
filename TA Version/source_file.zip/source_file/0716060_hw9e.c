#include <stdio.h>
#include<string.h>
#include<stdlib.h>
#include<stdbool.h>

void permute(char str[],int len);

int  cmp(const void *a,const void *b);

void swap(char *a,char*b);

int findceil(char str[],char point,int after_point,int len);

int main(){
    /* Write your code here */
    char str[15];
    scanf("%s",str);

    int len=strlen(str);

    qsort(str,len,sizeof(char),cmp);

    permute(str,len);

    return 0;

}

void permute(char str[],int len){
    /* Write your code here */

    bool if_decending=false;

    while(if_decending==false)
    {
        printf("%s\n",str);

        int i;
        for(i=len-2;i>=0;i--)
        {
            if(str[i]<str[i+1])
                break;
        }

        if(i==-1)
            if_decending=true;

        int ceilindex=findceil(str,str[i],i+1,len);
        swap(&str[i],&str[ceilindex]);
        qsort(str+i+1,len-i-1,sizeof(char),cmp);
    }
}

int cmp(const void *a,const void *b)
{
    return (*(char*)a-*(char*)b);
}

void swap(char*a,char*b)
{
    char temp;
    temp=*a;
    *a=*b;
    *b=temp;
}

int findceil(char str[],char point,int after_point,int len)
{
    int l;

    int result=after_point;

    for(l=after_point+1;l<=len-1;l++)
    {
        if(str[l]>point && str[l]<str[after_point])
            result=l;
    }

    return result;
}
