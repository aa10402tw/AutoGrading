#include <stdio.h>
#include<stdlib.h>
void queens(int , int * ,int);
int p=0;//count times

int main(){

    int N;
    scanf("%d",&N);
    int pos[N+1];

    queens(0, pos,N);
    printf("%d",p);


return 0;
}

void queens(int i, int *pos,int N){
  int j, k, full;

  if(i==N){
    p+=1;
  return;
  }

  for (k=0;k<N;k++){
    full=0;
    for (j=0; j<i && !full ;j++)
      if ( pos[j]==k || abs(k-pos[j])==(i - j) ) full = 1;

    if (!full) {
      pos[i] = k;
      queens(i+1,pos,N);
    }
  }

}
