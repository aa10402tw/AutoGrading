#include <stdio.h>

int move=0;
void hanoi(int input,int *p,int beg,int end);

int main() {
    int input,result=2;
    scanf("%d",&input);
    hanoi(input,&result,1,3);
    printf("%d",result);
    return 0;
}

void hanoi(int input,int *p,int beg,int end){
    if(input>1){
        if(beg==1&&end==3){
            hanoi(input-1,p,1,2);
            move++;
            hanoi(input-1,p,2,3);
        }
        else if(beg==2&&end==3){
            hanoi(input-1,p,2,1);
            move++;
            hanoi(input-1,p,1,3);
        }
        else if(beg==1&&end==2){
            hanoi(input-1,p,1,3);
            move++;
            hanoi(input-1,p,3,2);
        }
        else if(beg==2&&end==1){
            hanoi(input-1,p,2,3);
            move++;
            hanoi(input-1,p,3,1);
        }
        else if(beg==3&&end==2){
            hanoi(input-1,p,3,1);
            move++;
            hanoi(input-1,p,1,2);
        }
        else if(beg==3&&end==1){
            hanoi(input-1,p,3,2);
            move++;
            hanoi(input-1,p,2,1);
        }
    }
    else move++;
    *p=move;
}
