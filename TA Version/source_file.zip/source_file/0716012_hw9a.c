#include <stdio.h>

int SUM(int n);

int main(){
	int n;
	while(scanf("%d",&n)!=EOF){
	printf("%d\n",SUM(n));
	}
}

int SUM(int n){
	if(n==1)
		return 1;
	else
		return SUM(n-1)+n;
}
