#include <stdio.h>

void queens(int len, int *locations, int col, int *sum);
int isValid(int x1, int y1, int x2, int y2);
int isAllValid(int *locations, int x, int y);

int isValid(int x1, int y1, int x2, int y2)
{
    if (y1 == y2)
    {
        return 0;
    }
    
    int dx = x2 - x1;
    int dy = y2 - y1;
    return dx != dy && dx != -dy;
}

int isAllValid(int *locations, int x, int y)
{
    int i;
    for (i = 0; i < x; i++)
    {
        if (!isValid(x, y, i, locations[i]))
        {
            return 0;
        }
    }
    return 1;
}

int main()
{
    int n;
    int sum;
    while (scanf("%d", &n) != EOF)
    {
        sum = 0;
        int array[n];
        queens(n, array, 0, &sum);
        printf("%d\n", sum);
    }
}

void queens(int len, int *locations, int x, int *sum)
{
    if (x == len)
    {
        (*sum)++;
        return;
    }

    int y;
    for (y = 0; y < len; y++)
    {
        if (isAllValid(locations, x, y))
        {
            locations[x] = y;
            queens(len, locations, x + 1, sum);
        }
    }
}