#include <stdio.h>

int SUM(int ALAN);

int main(){
	/* Write your code here */
	int fff;
	while(scanf("%d",&fff)!=EOF)
    {
        printf("%d\n",SUM(fff));
    }
}

int SUM(int ALAN){
	/* Write your code here */
	if(ALAN==1)
        return 1;
    else
        return SUM(ALAN-1)+ALAN;
}
