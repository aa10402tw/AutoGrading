#include <stdio.h>
void hanoi(int N,char A,char B,char C,int *counter);

int main()
{
    int i=0;
    int *counter=&i;
    int n;
    scanf("%d",&n);
    hanoi(n,'A','B','C',counter);
    printf("%d",*counter);
    return 0;
}

void hanoi(int N,char A,char B,char C,int *counter)
{
    if(N==1)
        *counter+=1;
    if(N!=1)
    {
        hanoi(N-1,A,C,B,counter);
        hanoi(1,A,B,C,counter);
        hanoi(N-1,B,A,C,counter);
    }
}

