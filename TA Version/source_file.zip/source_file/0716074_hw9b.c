#include <stdio.h>

int GCD(int a,int b);

int main(){
   int a,b;
  scanf("%d %d",&a,&b);
  if(a>b){
   int temp=a;
   a=b;
   b=temp;
}
  printf("%d",GCD(a,b));
  return 0;
}

int GCD(int a,int b){

if(b%a==0){
   return a;
}
else{
   return GCD(b%a,a);

}
}