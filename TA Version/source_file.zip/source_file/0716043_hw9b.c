#include <stdio.h>

int GCD(int n, int m);

int main()
{
    int n, m;
    scanf("%d %d", &n, &m);
    printf("%d", GCD(n, m));
    return 0;
}

int GCD(int n, int m)
{
    int temp;
    if(n < m)
    {
        temp = n;
        n = m;
        m = temp;
    }
    return m == 0 ? n : GCD(m, n % m);
}
