#include <stdio.h>

int SUM(int a/* Write your code here */);
int j,i=0;

int main(){
	/* Write your code here */
	scanf("%d",&j);
	printf("%d",SUM(0));
	return 0;
}

int SUM(int a/* Write your code here */){
	/* Write your code here */
	i++;
	a+=i;
	if(i<j){
        a=SUM(a);
	}
    return a;
}
