#include <stdio.h>

void queens(/* Write your code here */int size,int *first_row,int *pos,int *ans);

int main(){
    /* Write your code here */
    int n,solution=0;
    int queen_pos[14];
    scanf("%d",&n);
    queens(n,&queen_pos[0],&queen_pos[0],&solution);
    printf("%d",solution);

    return 0;
}

void queens(/* Write your code here */int size,int *first_row,int *pos,int *ans){
    /* Write your code here */
    for(int i=1;i<=size;i++)
    {
        int flag=1;
        for(int j=0;j<(pos-first_row);j++)
        {
            if(i==*(first_row+j) || i+(pos-first_row)==*(first_row+j)+j || i-(pos-first_row)==*(first_row+j)-j)
            {
                flag=0;
                break;
            }
        }
        if(flag)
        {
            *pos=i;
            pos++;
            queens(size,first_row,pos,ans);
            pos--;
        }
    }
    if((pos-first_row)==size)
        (*ans)++;
}
