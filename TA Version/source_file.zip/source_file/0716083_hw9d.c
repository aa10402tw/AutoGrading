#include <stdio.h>

void hanoi(int i, int *j);

int main()
{
    int n, m=0;
    scanf("%d", &n);
    hanoi(n, &m);
    printf("%d", m);

    return 0;
}

void hanoi(int i, int *j)
{
    if(i==1)
        *j+=1;

    else
    {
        hanoi(i-1, j);
        hanoi(1, j);
        hanoi(i-1, j);
    }
}
