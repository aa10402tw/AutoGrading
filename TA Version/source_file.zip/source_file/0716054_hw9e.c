#include <stdio.h>
#include<string.h>
#include<stdlib.h>

void permute(char a[]);
void swap(char *a,char *b);

int compare (const void *a, const void * b)
{
    return ( *(char *)a - *(char *)b );
}

int ceil(char str[], char smallest, int l, int h)
{
    int ceilindex = l;//initialization

    for (int i = l+1; i <= h; i++)
        if (str[i] > smallest && str[i] < str[ceilindex])
            ceilindex = i;

    return ceilindex;
}

int main()
{
    char str[10];
    int x = 1;

    scanf("%s",str);

    permute(str);

    return 0;
}

void permute(char str[])
{
    int size = strlen(str);

    qsort(str,size,sizeof(char),compare);

    int flag = 0;

    while (flag==0)
    {
        printf ("%s\n",str);

        int i;
        for ( i = size - 2; i >= 0; --i )//�k������W�[
            if (str[i] < str[i+1])
                break;


        if ( i == -1 )flag = 1;
        else
        {

            int ceilIndex = ceil(str,str[i],i + 1,size - 1);//ceilIndex is the small one the str[i]

            swap(&str[i],&str[ceilIndex]);

            qsort(str+i+1,size-i-1,sizeof(char),compare);
        }
    }
}

void swap(char *a,char *b)
{
    char tmp = *a;
    *a = *b;
    *b = tmp;
}
