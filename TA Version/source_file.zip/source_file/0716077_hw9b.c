#include <stdio.h>

int GCD(int a,int b);

int main(){
   int a,b;
   scanf("%d",&a);
   scanf("%d",&b);
   printf("%d",GCD(a,b));
   return 0;
}

int GCD(int a,int b){
    if(a==b)
    {
     return a;
    }
    if(a<b)
    {
     int temp=a;
     a=b;
     b=temp;
    }
    a-=b;
    if(a==0)
    {
     return b;
    }
    int gcd=GCD(a,b);
   return gcd;
}
