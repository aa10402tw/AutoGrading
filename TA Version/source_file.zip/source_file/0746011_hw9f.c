#include <stdio.h>
#include <stdlib.h>

void queens(int n, int* queen, int index, int* count);
int isValid(int n, int* queen, int index);

int main() {
    int N;
    
    scanf ("%d", &N);
    // if (N < 0 || N > 14) {
    //   perror("Invalid!! N should be a positive integer <= 14!\n");
    //   return 1;
    // }
    int ans = 0;
    int queen[N];
    queens(N, queen, 0, &ans);
    printf("%d\n", ans);
    return 0;
}

void queens(int n, int* queen, int index, int* count) {
  if (index == n) {
    (*count)++;
    return;
  }
  for (int pos = 0; pos < n; pos++) {
    queen[index] = pos;
    if (isValid(n, queen, index) == 1) {
      queens(n, queen, index+1, count);
    }
  }
}

int isValid(int n, int* queen, int index) {
  int pos = queen[index];
  for (int i = 0; i < index; i++) {
    if (queen[i] == pos ||
        abs(pos - queen[i]) == abs(index - i)) {
      // same row or on a diagonal line, can't place queen here
      return 0; // false
    }
  }
  return 1; // true
}
