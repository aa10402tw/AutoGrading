#include <stdio.h>

void  hanoi(int n/* Write your code here */);
int i=0;
int main() {
    int n;
    scanf("%d",&n);
    hanoi(n);
    printf("%d\n",i);
    return 0;
    /* Write your code here */
}

void hanoi(int n/* Write your code here */){
    if(n==0)return;
    hanoi(n-1);
    i++;
    hanoi(n-1);

    /* Write your code here */
}
