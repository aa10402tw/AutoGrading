#include <stdio.h>

int binary_search(int left,int right,int arr[],int goal/* Write your code here */);

int main(void)
{
    /* Write your code here */
    int n;
    int goal;
    scanf("%d",&n);
    int arr[110];
    for(int i=0; i<n; i++)
        scanf("%d",&arr[i]);
    scanf("%d",&goal);

     //   for(int i=0;i<n;i++)
     //   printf("%d ",arr[i]);
      //  printf("\n");
    //sort
    int temp;
    for(int i=0; i<n; i++)
    {
        for(int j=0; j<n-1; j++)
        {
            if( arr[j]>arr[j+1] )
            {
                temp=arr[j];
                arr[j]=arr[j+1];
                arr[j+1]=temp;
            }
        }
    }
    /////
    //for(int i=0;i<n;i++)
    //    printf("%d ",arr[i]);
    /////
    int pri;
    pri=binary_search(0,n-1,arr,goal);
    printf("%d",pri);
    return 0;
}
// 1~n notice!
int binary_search(int left,int right,int arr[],int goal/* Write your code here */)
{
    /* Write your code here */
    int med;
    if((right-left+1)%2==0)
        med=(left+right-1)/2;
    else
        med=(left+right)/2;
    if( (arr[med]==goal)  )
        return (med);
    if(  (arr[right]==goal) && (left==med)  )
        return right;
    else if( (left==med) && (arr[right]==goal) )
        return -1;
    else if( arr[med]>goal )
        return binary_search(left,med,arr,goal);
    else if(arr[med]<goal)
        return binary_search(med,right,arr,goal);

    }
