#include <stdio.h>
int used[1000][1000]={};
int ans=0;
void queens(int row,int ed);

int main(){
    int n;
    scanf("%d",&n);
    queens(0,n);
    printf("%d\n",ans);
}

void queens(int row,int ed){
    if(row==ed){
        ans++;
        return ;
    }
    for(int i=0;i<ed;i++){
        if(!used[row][i]){
            for(int j=1;j<ed-row;j++){
                used[j+row][i]++;
                if(i+j<ed)
                    used[j+row][i+j]++;
                if(i-j>=0)
                    used[j+row][i-j]++;
            }
            queens(row+1,ed);
            for(int j=1;j<ed-row;j++){
                used[j+row][i]--;
                if(i+j<ed)
                    used[j+row][i+j]--;
                if(i-j>=0)
                    used[j+row][i-j]--;
            }
        }
    }
}
