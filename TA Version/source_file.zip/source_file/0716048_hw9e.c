#include <stdio.h>
#include<string.h>

void permute(char s[],int i/* Write your code here */);

int main(){
    char s[10]={0},t;
    int num,i;
    scanf("%s",&s);
    num=strlen(s);
    for(i=0;i<num;i++){
        for(int j=i;j<num;j++){
            if(s[j]<s[i]){
                t=s[j];
                s[j]=s[i];
                s[i]=t;
            }
        }
    }
    permute(s,0);



    return 0;
    /* Write your code here */
}

void permute(char s[],int i/* Write your code here */){
    int j,k,num;
    char temp;

    num=strlen(s);

    if(i<num-1) {
        for(j=i;j<=num-1;j++) {
            temp=s[j];
            for(k=j;k>i;k--){
                s[k]=s[k-1];
            }
            s[i]=temp;

            permute(s,i+1);

            for(k=i;k<j;k++){
                s[k]=s[k+1];
                }
            s[j]=temp;
            }
            }



    else{
        for(int l=0;l<num;l++){
            printf("%c", s[l]);
            }
        printf("\n");
            /* Write your code here */
}
}
