#include <stdio.h>

void hanoi(int N,char A,char B,char C);
int count=0;
int main() {
    int n;
    scanf("%d",&n);
    hanoi(n,'A','B','C');
    printf("%d",count);

}

void hanoi(int N,char I,char A,char E){

    if(N==1){
        /*printf("%d: move %d disks from %c to %c\n",++count,N,I,E);*/
        count++;
    }
    else{
        hanoi(N-1,I,E,A);
        hanoi(1,I,A,E);
        hanoi(N-1,A,I,E);
    }
}
