#include <stdio.h>

int SUM(int input);

int main(){
	int input;
	scanf("%d",&input);
	if(input<0)
        return 0;
	printf("%d",SUM(input));
	return 0;
}

int SUM(int input){
	int result;
	if(input==0)
        return 0;
	else{
        result=input+SUM(input-1);
        return result;
	}
}
