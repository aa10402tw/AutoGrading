#include <stdio.h>
#include <math.h>
void hanoi(int n);
int sum = 0;
int main(void) {
    int a;
    scanf("%i",&a);
    hanoi(a);
    printf("%i\n",sum);
} 
void hanoi(int n){
    if (n == 1) 
        sum++;
    else {
         hanoi(n - 1);
        sum++;
         hanoi(n - 1);
    }
}
