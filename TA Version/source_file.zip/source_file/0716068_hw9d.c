#include <stdio.h>

int sum = 0;

void hanoi(int);

int main() {
    int n;

    scanf("%d",&n);

    hanoi(n);

    printf("%d",sum);

    return 0;
} 

void hanoi(int x){
    
    sum++;

    if(x!=1)
    {
        hanoi(x-1);
        hanoi(x-1);
    }

    return;
        
}