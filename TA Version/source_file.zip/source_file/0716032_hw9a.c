#include <stdio.h>

int SUM(int n);

int main(){
	int n,sum;
	while(scanf("%d",&n)==1){
        if(n>=1){
            sum=SUM(n);
            printf("%d\n",sum);
        }
    }
}

int SUM(int n){
    int sum;
    if(n==1)return 1;
    if(n!=1)sum=n+SUM(n-1);
    return sum;
}
