#include <stdio.h>

int GCD(int greater, int lower);

int main()
{
    int a, b;
    while (scanf("%d %d", &a, &b) != EOF)
    {
        printf("%d\n", a > b ? GCD(a, b) : GCD(b, a));
    }
}

int GCD(int greater, int lower)
{
    int r = greater % lower;
    return r ? GCD(lower, r) : lower;
}