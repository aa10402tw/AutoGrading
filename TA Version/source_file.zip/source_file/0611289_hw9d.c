#include <stdio.h>

void hanoi(int n);
int i=0;
int main() {
    /* Write your code here */
    int n;
    scanf("%d", &n);
    hanoi(n);
    printf("%d",i);
} 

void hanoi(int n){
    /* Write your code here */
    if(n >0){
        hanoi(n-1);
        i++;
        hanoi(n-1);
    }
}
