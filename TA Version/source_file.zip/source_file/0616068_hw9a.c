#include <stdio.h>

int SUM(int n);

int main(){
	int n;
    scanf("%d", &n);
    long long ans = SUM(n);
    printf("%lld", ans);
}

int SUM(int n){
	if (n == 1) {
        return 1;
    } else {
        return n + SUM(n - 1);
    }
}
