#include <stdio.h>

int ways=0;
void queens(int n, int queen[], int count);

int main(){
    int n;
    scanf("%d",&n);
    int queen[n];
    queens(n,queen,0);
    printf("%d",ways);
    return 0;
}

void queens(int n, int queen[], int count){
    if(count==n){
        ways++;
        return;
    }

    int i,j;
    for(i=0;i<n;i++){
        for(j=0;j<count;j++){
            if(i==queen[j] || queen[j]==i-count+j || queen[j]==i+count-j )
                break;
        }
        if(j==count){
            queen[count]=i;
            queens(n,queen,count+1);
        }
    }
}
