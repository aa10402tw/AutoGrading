//
//  main.c
//  0716056_hw9c
//
//  Created by 王孜甄 on 2018/11/19.
//  Copyright © 2018 eliawang_. All rights reserved.
//

#include <stdio.h>

int binary_search(/* Write your code here */int a[],int x,int left,int right);

int main(void){
    /* Write your code here */
    int n,x,i,j,array[100],temp;

    scanf("%d",&n);
    for(i=0;i<n;i++)
        scanf("%d",&array[i]);
    
    for(i=0;i<n-1;i++){
        for(j=0;j<n-i-1;j++){
            if(array[j]>array[j+1]){
                temp=array[j+1];
                array[j+1]=array[j];
                array[j]=temp;
            }
        }
    }
    
    scanf("%d",&x);
    printf("%d",binary_search(array,x,0,n));
    return 0;
}

int binary_search(/* Write your code here */int a[],int x,int left,int right){
    /* Write your code here */
    int middle;
   
    middle=(left+right)/2;
    if(left>right)
        return -1;
    else if(x>a[middle])
        return binary_search(a,x,middle+1,right);
    else if(x<a[middle])
        return binary_search(a,x,left,middle-1);
    else if(x==a[middle])
        return middle;
}
