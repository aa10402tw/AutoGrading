#include <stdio.h> 

int binary_search(int *,int,int,int,int);

int main(void){ 
	/* Write your code here */
	int num[100],size,obj,i,left=0,right,j,buf;
	scanf("%d",&size);
	right=size-1;
	for(i=0;i<size;i++){
		scanf("%d",&num[i]);
	}
	scanf("%d",&obj);
	for(i=0;i<size;i++){
		for(j=0;j<size-1;j++){
			if(num[j]>num[j+1]){
				buf=num[j];
				num[j]=num[j+1];
				num[j+1]=buf;
			}
		}
	}
	printf("%d",binary_search(num,size,obj,left,right));
	return 0;
}

int binary_search(int *num,int size,int obj,int left,int right){ 
   /* Write your code here */
   int index=(left+right)/2;
   if(num[index]!=obj){
   	    if(num[index]<obj){
   	    	left=index+1;
   	    	binary_search(num,size,obj,left,right);
   	    	//return ;
		}
		else{
			right=index-1;
			binary_search(num,size,obj,left,right);
   	    	//return ;
		}
   }
   else{
   	    return index;
   }
   
}
