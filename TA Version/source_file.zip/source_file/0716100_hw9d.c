#include <stdio.h>

int i = 0;

void hanoi(int n, char a, char b, char c/* Write your code here */);

void moving(int n, char x, char y)
{
    i++;
}

int main() {
    /* Write your code here */
    int n;
    scanf("%d", &n);
    hanoi(n, 'a', 'b', 'c');
    printf("%d", i);
    return 0;
}

void hanoi(int n, char a, char b, char c/* Write your code here */){
    /* Write your code here */
    if(n == 1)
        moving(1, a, c);
    else
    {
        hanoi(n - 1, a, c, b);
        moving(n, a, c);
        hanoi(n - 1, b, a, c);
    }
}
