#include <stdio.h>

int SUM(int n);

int main(){
	/* Write your code here */
	int n;

	scanf("%d",&n);

    int i=SUM(n);

    printf("%d",i);

    return 0;

}

int SUM(int n){
	if(n==0)
        return 0;
    else
        return n+SUM(n-1);
}
