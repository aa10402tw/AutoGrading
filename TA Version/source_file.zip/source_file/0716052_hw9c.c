//0716052_hw9c
#include <stdio.h>
#include <stdlib.h>

int binary_search(int *nNum, int nL, int nR, int nTarget);

int main(void) {
	int nN, nTarget, nNum[105], i, j, nCount, temp, nAns;
	scanf("%d", &nN);
	for (i = 0; i < nN; i++) {
		scanf("%d", &nNum[i]);
	}
	for (i = 0; i < nN - 1; i++) {
		nCount = 0;
		for (j = 0; j < nN - 1 - i; j++) {
			if (nNum[j] > nNum[j + 1]) {
				temp = nNum[j];
				nNum[j] = nNum[j + 1];
				nNum[j + 1] = temp;
				nCount++;
			}
		}
		if (nCount == 0)
			break;
	}
	scanf("%d", &nTarget);
	nAns = binary_search(nNum, 0, nN - 1, nTarget);
	printf("%d\n", nAns);

	//system("pause");
	return 0;
}

int binary_search(int *nNum, int nL, int nR, int nTarget) {
	int nM;
	nM = (nL + nR) / 2;
	if (nR < nL)
		return -1;
	else if (nNum[nM] == nTarget)
		return nM;
	else if (nNum[nM] > nTarget) {
		return binary_search(nNum, nL, nM - 1, nTarget);
	}
	else if (nNum[nM] < nTarget) {
		return binary_search(nNum, nM + 1, nR, nTarget);
	}

}