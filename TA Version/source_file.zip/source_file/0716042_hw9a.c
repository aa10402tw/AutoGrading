#include <stdio.h>
int SUM(int a);
int main(){
	int n,sum;
	scanf("%d",&n);
	sum=SUM(n);
	printf("%d",sum);
	return 0;
}

int SUM(int a){
	if(a==0) return a;
	else return a+SUM(a-1);
}
