#include <stdio.h>
//downwards:i, right:j
void queens(int i,int j);
int check(int i,int j);

int siz;
int solutions=0;
int board[20][20]={0};
int main(){
    scanf("%d",&siz);
    queens(0,0);
    printf("%d",solutions);
    return 0;
}

void queens(int i,int j){
    //printf("3\n");
    if(j>=siz)
    {
        //printf("2\n");
        return;
    }

    if( check(i,j)==1 )
    {
        //printf("5\n");
        board[i][j]=1;
        if(i==siz-1)//if it's already in the last row, record it
            solutions++;
        else
        {
            //printf("1\n");
            queens(i+1,0);//analyzsi the next row
        }
    }
    board[i][j]=0;
    queens(i,j+1);


}

int check(int i,int j)
{
//check whether there are queens in the same column
    for(int k=0;k<siz;k++)
    {
        if(board[i][k]==1)
            return 0;
    }
//check whether there are queens in the same row
    for(int k=0;k<siz;k++)
    {
        if(board[k][j]==1)
            return 0;
    }
//check whether there are queens in the same diagonal
    //left up to right down
    for(int k=-siz;k<=siz;k++)
    {
        if(i+k>=0&&i+k<siz&&j+k>=0&&j+k<siz)
        {
            if(board[i+k][j+k]==1)
                return 0;
        }

        if(i-k>=0&&i-k<siz&&j+k>=0&&j+k<siz)
        {
            if(board[i-k][j+k]==1)
                return 0;
        }
    }
    return 1;
}
