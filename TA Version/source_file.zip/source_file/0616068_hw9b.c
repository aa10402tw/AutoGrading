#include <stdio.h>

int GCD(int x, int y);

int main(){
   int x, y, temp;
   scanf("%d%d", &x, &y);
   if (y > x) {
       temp = x;
       x = y;
       y = temp;
   }
   int ans = GCD(x, y);
   printf("%d", ans);
}

int GCD(int x, int y){
    if (x % y == 0) {
        return y;
    } else {
        return GCD(y, x % y);
    }
}
