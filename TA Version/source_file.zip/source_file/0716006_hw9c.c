#include <stdio.h>
#include <string.h>
int binary_search(int *,int,int,int);

int main(void){
	int L,input[100]={0},search,len,k;
	scanf("%d",&L);
	for(k=0;k<L;k++){
        scanf("%d",&input[k]);
	}
	int i,j,tmp;
	for(i=0;i<L-1;i++){
        for(j=0;j<L-1;j++){
            if(input[j]>input[j+1]){
                tmp = input[j];
                input[j] = input[j+1];
                input[j+1] = tmp;
            }
        }
	}
	scanf("%d",&search);
	int left=1;
	int right=L;
	int index = binary_search(input,left,right,search);
	printf("%d",index);
    return 0;
}

int binary_search(int *M,int left,int right,int search){
    int *num;
    num = M;
    int mid = (left+right)/2;
    if(*(num+mid) == search){
        return mid;
    }
    else if( *(num+mid) < search){
        left = mid+1;
    }
    else if( *(num+mid) > search){
        right = mid-1;
    }
    else{
        return -1;
    }
    return binary_search(num,left,right,search);
}

