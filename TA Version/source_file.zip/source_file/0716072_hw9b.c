#include <stdio.h>

int GCD();

int main(){
   int input1,input2;
   scanf("%d%d",&input1,&input2);
   printf("%d\n",GCD(input1,input2));
}

int GCD(int n,int m){
    if(n==0)return m;
    else if(m==0)return n;
    else if(n>m)return GCD(n%m,m);
    else return GCD(n,m%n); 
}