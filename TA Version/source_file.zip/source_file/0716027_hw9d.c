#include <stdio.h>

void hanoi(/* Write your code here */int *a);

int main() {
    /* Write your code here */
    int a;
    scanf("%d",&a);
    hanoi(&a);
    printf("%d",a);
}

void hanoi(/* Write your code here */int *a){
    /* Write your code here */
    if(*a==1)
    {
        *a=1;
    }
    else
    {
        (*a)--;
        hanoi(a);
        *a=2*(*a)+1;
    }
}
