#include <stdio.h>

int SUM(int n, int sum);

int main(){

    int n;

	scanf("%d", &n);

	printf("%d", SUM(n, 0));

	return 0;
}

int SUM(int n, int sum){
	sum += n;
	if(n==1)
    {
        return sum;
    }
    else
    {
        return SUM(n-1, sum);
    }
}
