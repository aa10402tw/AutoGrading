#include <stdio.h>
int n;
int binary_search(int,int [],int,int/* Write your code here */);

int main(void){
	/* Write your code here */
	int i,j,min;
	int str[100],x;
	scanf("%d",&n);
	for(int i=0;i<n;i++){
        scanf("%d",&str[i]);
	}
	for(i=0;i<n;i++){
        min=str[i];
        for(j=i+1;j<n;j++){
            if(str[j]<str[i]){
                min=str[j];
                str[j]=str[i];
                str[i]=min;
            }
            else break;
       }
   }
	scanf("%d",&x);
	printf("%d",binary_search(x,str,0,n-1));
    return 0;
}

int binary_search(int x,int str[100],int L,int R/* Write your code here */){
   /* Write your code here */
   int i,j;
       if(L<R){
        i=(L+R)/2;
           if(x==str[i]){
            return i;
           }
           else if(x<str[i]){
            R=i-1;
            return binary_search(x,str,L,R);
           }
           else{
            L=i+1;
            return binary_search(x,str,L,R);
           }
       }
       else if(str[L]==x){
            return L;
       }
       else return -1;
}
