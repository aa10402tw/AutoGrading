#include <stdio.h>

int binary_search(int *a,int r,int l,int s);

int main(void){
	int n;
	scanf("%d",&n);
	int a[n];
	int temp;
	int i,j;
	int s;
	for(i=0;i<n;i++){
        scanf("%d",&a[i]);
	}
	for(i=0;i<n;i++){
        for(j=i+1;j<n;j++){
            if(a[j]<a[i]){
                temp = a[i];
                a[i] = a[j];
                a[j] = temp;
            }
        }
	}
	scanf("%d",&s);
	printf("%d",binary_search(a,n-1,0,s));
}

int binary_search(int *a,int r,int l,int s ){
    int mid;
    mid = (l+r)/2;
    if(r<l){
        return -1;
    }
    else if(a[mid]>s){
        r=mid-1;
        return binary_search(a,r,l,s);
    }
    else if(a[mid]<s){
        l=mid+1;
        return binary_search(a,r,l,s);
    }
    else{
        return mid;
    }

}
