#include <stdio.h>

int SUM(int N);

int main(){
	int insert;
	scanf("%d", &insert);
	printf("%d\n", SUM(insert));
	return 0;
}

int SUM(int N){
	if(N == 1) return 1;
	else return SUM(N-1) + N;
}