#include <stdio.h>
int count=0;

void hanoi(/* Write your code here */int n, char A, char B, char C);

int main()
{
    /* Write your code here */
    int a;
    char A,B,C;
    scanf("%d",&a);
    hanoi(a,'A','B','C');
    printf("%d",count);
}

void hanoi(/* Write your code here */int n, char A, char B, char C)
{

    /* Write your code here */
    if(n==1)
        count++;
    else
    {
        hanoi(n-1,A,C,B);
        count++;
        hanoi(n-1,B,A,C);
    }

}
