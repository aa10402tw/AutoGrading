#include <stdio.h>

int binary_search(/* Write your code here */int f,int a,int b,int s[a+1]);

int main(void){
	/* Write your code here */
	int a, i, j, s[10000], b, g;
	scanf("%d",&a);
	for(i=0;i<a;i++)
    {
        scanf("%d",&s[i]);
    }
    scanf("%d",&b);


    for(j=0;j<a;j++)
    {
        for(i=0;i<a-1;i++)
        {
            if(s[i]>s[i+1])
            {
                g=s[i];
                s[i]=s[i+1];
                s[i+1]=g;
            }
        }
    }


    i=binary_search(0,a-1,b,s);
    if(i==-1)
    {
        printf("-1");
        return 0;
    }
    printf("%d",i);
}


int binary_search(/* Write your code here */int f,int a,int b,int s[a+1]){
   /* Write your code here */
   int m=(f+a)/2;

   if(b>s[a]||b<s[0])
   {
       return -1;
   }


   if(b==s[m])
   {
       return (m);
   }
   else if(b>s[m])
   {
       binary_search(m+1,a,b,s);
   }
   else if(b<s[m])
   {
       binary_search(f,m-1,b,s);
   }

}
