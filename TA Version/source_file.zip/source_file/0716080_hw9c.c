#include <stdio.h>

int binary_search(int arr[], int head, int tail, int want);

int main(void){
	int n, arr[100], want, i, j, temp;

	scanf("%d", &n);
	for(i=0; i<n; i++)
	{
	    scanf("%d", arr+i);
	}
	scanf("%d", &want);

	for(i=0; i<n-1; i++)
    {
        for(j=0; j<n-1; j++)
        {
            if(arr[j]>arr[j+1])
            {
                temp = arr[j];
                arr[j] = arr[j+1];
                arr[j+1] = temp;
            }
        }
    }

    if(want > arr[n-1] || want < arr[0])
    {
        printf("-1");
        return 0;
    }

    printf("%d", binary_search(arr, 0, n-1, want));

    return 0;


}

int binary_search(int arr[], int head, int tail, int want){

   int middle = (head+tail)/2;

   if(arr[middle] == want)
   {
       return middle;
   }
   else if(arr[middle] > want)
   {
       return binary_search(arr, head, middle-1, want);
   }
   else if(arr[middle] < want)
   {
       return binary_search(arr, middle+1, tail, want);
   }
   else
   {
       return -1;
   }



}
