#include <stdio.h>

int binary_search(/* Write your code here */);

int main(void){
	int n,a[100],num;
	scanf("%d",&n);
	for(int i=0;i<n;i++)
        scanf("%d",&a[i]);
    scanf("%d",&num);
    printf("%d",binary_search(0,n-1,a,num));

    return 0;
}

int binary_search(int L, int R, int a[], int num){
   int M=(L+R)/2;
   for(int i=L;i<=M;i++){
       if(a[i]==num)
           return i;
   }
   if(L>R)
       return -1;
   return binary_search(M+1,R,a,num);
}
