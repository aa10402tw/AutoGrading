#include <stdio.h>
#include <string.h>
typedef struct{
    char s[200];
}b;
b s[200];
int k = 0;
void permute(char fuckinghard[], int i, int n);
int main(void) { 
    char a[200],temp[200];
    scanf("%s",a);
    int lo= strlen(a);
    for(int i = lo,j=lo-1;i>=1;j--,i--)
        a[i] = a[j];
    permute(a,1,lo);
    for(int i = 0;i<k-1;i++)
        for(int j = i+1;j<k;j++)
            if(strcmp(s[i].s,s[j].s)>0){
                strcpy(temp,s[i].s);
                strcpy(s[i].s,s[j].s);
                strcpy(s[j].s,temp);
            }
    for(int i = 0;i<k;i++)
        printf("%s\n",s[i].s);
}
void swap(char *a,char *b){
    char temp;
    temp = *a;
    *a = *b;
    *b = temp;
}
void print(char *fuckinghard,int n,int k){
    for (int j = 1,i = 0; j <= n; j++,i++)
        s[k].s[i] = fuckinghard[j];
}
void permute(char *fuckinghard, int i, int n){ 
    if(i == n)
        print(fuckinghard,n,k++);
    else{ 
        for(int j = i; j <= n; j++){
            swap(&fuckinghard[i], &fuckinghard[j]); 
            permute(fuckinghard, i+1, n); 
            swap(&fuckinghard[i], &fuckinghard[j]); 
        }
    }
}
