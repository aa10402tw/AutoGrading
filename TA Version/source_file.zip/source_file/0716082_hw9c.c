#include <stdio.h>

int binary_search(int str[], int start, int e, int tar);
void swap(int* a, int* b)
{
    int tmp;
    tmp=*a;
    *a=*b;
    *b=tmp;
}
void sort(int str[], int len)
{
    int i,j;
    for(i=len-1; i>=0; i--)
    {
        for(j=0; j<i; j++)
        {
            if(str[j]>str[j+1])
                swap(&str[j],&str[j+1]);
        }
    }
}


int main(void)
{
    int n,str[100],i,tar,s;
    scanf("%d",&n);
    for(i=0; i<n; i++)
    {
        scanf("%d",&str[i]);
    }
    scanf("%d",&tar);
    sort(str,n);
    printf("%d",binary_search(str, 0, n, tar));
    return 0;
}

int binary_search(int str[], int start, int e, int tar)
{
    int L=start,R=e-1;
    while(L<=R)
    {
        int M=(L+R)/2;
        if(str[M]==tar)
            return M;
        else if(str[M]>tar)
        {
            return binary_search(str, 0, M+1, tar);
        }
        else
        {
            return binary_search(str, M, e+1, tar);
        }
    }
    return -1;
}
