#include <stdio.h>
#include <string.h>

void permute(/* Write your code here */char a[],int l);

int main(){
    /* Write your code here */
    char a[10];
    scanf("%s", &a);
    int l=strlen(a);
    for(int i=(l-1); i>0; i--)
        for(int k=0; k<i; k++)
            if(a[k]>a[k+1])
            {
                char c=a[k];
                a[k]=a[k+1];
                a[k+1]=c;
            }
    printf("%s\n", a);
    permute(a, l);
}


void permute(/* Write your code here */char a[],int l){
    /* Write your code here */
    int flag=0;
    for(int i=0;i<(l-1);i++)
        if(a[i]<a[i+1])
        {
            flag=1;
            break;
        }
    if(flag==1)
    {
        int p=0;
        for(int i=0;i<l;i++)
            if(a[i]<a[i+1])
                p=i;
        int k=0;
        for(int i=p+1;i<=l-1;i++)
            if(a[i]>a[p])
                k=i;
        char b=a[p];
        a[p]=a[k];
        a[k]=b;
        for(int i=(l-p-1);i>0;i--)
            for(int j=p+1;j<(l-1);j++)
            if(a[j]>a[j+1])
            {
                b=a[j];
                a[j]=a[j+1];
                a[j+1]=b;
            }
        printf("%s\n", a);
        permute(a, l);
    }
}
