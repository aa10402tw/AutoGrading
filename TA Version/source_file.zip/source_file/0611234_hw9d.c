#include <stdio.h>

void hanoi(int disk_num, int* step);

int main() {
    int insert_disk_num, times[1] = {0};
    scanf("%d", &insert_disk_num);
    hanoi(insert_disk_num, times);
    printf("%d\n", times[0]);
} 

void hanoi(int disk_num,int* step){
    if(disk_num == 1){
    	// printf("1\n");
    	step[0]++;
    }else{
    	hanoi(disk_num - 1, step);
    	hanoi(1, step);
    	hanoi(disk_num - 1, step);
    }
}