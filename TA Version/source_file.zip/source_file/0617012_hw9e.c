#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int compare(const void *x,const void * y)
{
    return (*(char *)x-*(char *)y);
}

void swap(char* a,char* b)
{
    char tmp=*a;
    *a=*b;
    *b=tmp;
}

int f(char str[],char first,int l,int h)
{
    int a=l;
    for (int i=l+1;i<=h;i++)
    {
        if (str[i]>first&&str[i]<str[a])
            a=i;
    }
    return a;
}

int main()
{
    char c[9];
    scanf("%s",&c);
    permute(c);
    return 0;
}

void permute(char c[])
{
    int size=strlen(c);
    qsort(c,size,sizeof( c[0] ),compare);
    int x=0;
    while(!x)
    {
        printf ("%s\n",c);
        int i;
        for(i=size-2;i>=0;--i)
           if (c[i] < c[i+1])
              break;
        if(i==-1)
            x=1;
        else
        {
            int k=f(c,c[i],i+1,size-1);
            swap(&c[i],&c[k]);
            qsort(c+i+1,size-i-1,sizeof(c[0]),compare);
        }
    }
}

