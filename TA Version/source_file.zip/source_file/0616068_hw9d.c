#include <stdio.h>
int ans = 0;

void hanoi(int n);

int main() {
    int n;
    scanf("%d", &n);
    hanoi(n);
    printf("%d", ans);
}

void hanoi(int n){
    if (n == 1) {
        ans++;
    } else {
        hanoi(n - 1);
        hanoi(1);
        hanoi(n - 1);
    }
}
