#include <stdio.h>

int binary_search(int a[],int length,int x,int left,int right);

int main(void){
	/* Write your code here */
	int length,x;
	int a[1000];
	scanf("%d",&length);
	for(int i=0;i<length;i++)
        scanf("%d",&a[i]);
    scanf("%d",&x);
    for(int i=0;i<length-1;i++)
    {
        for(int j=0;j<length-1-i;j++)
        {
            if(a[j]>a[j+1])
            {
                int temp=a[j];
                a[j]=a[j+1];
                a[j+1]=temp;
            }
        }
    }
    int y=binary_search(a,length,x,0,length-1);
    printf("%d",y);

	return 0;
}

int binary_search(int a[],int length,int x,int left,int right){
   /* Write your code here */
   if(left<=right)
   {
   int middle=(right-left)/2+left;
    if(x>a[middle])
        return binary_search(a,length,x,middle+1,length-1);
    if(x<a[middle])
        return binary_search(a,length,x,0,middle-1);
    if(x==a[middle])
        return middle;
   }
   else
    return -1;
}
