#include <stdio.h>
#include <string.h>
void permute(char *str,int *count,char*result,int level/* Write your code here */);
void sort(char*a);

int main()
{
    char str[9]="",result[9]="";
    int count[9];
    int i=0,n=0,level=0;    /* Write your code here */
    gets(str);
    sort(str);
    for(i=0;i<9;i++){
        count[i]=1;
    }
    permute(str,count,result,level);
    return 0;
}
void sort(char*a)
{
    int i,n,j;
    char temp;
    n=strlen(a);
    for(i=0; i<n; i++)
    {
        for(j=0; j<n-1; j++)
        {
            if((int)a[j]>(int)a[j+1])
            {
                temp=a[j];
                a[j]=a[j+1];
                a[j+1]=temp;
            }
        }

    }

}
void permute(char *str,int *count,char*result,int level/* Write your code here */)
{
    /* Write your code here */
    if(level== strlen(str))
    {
        printf("%s\n",result);

    }
    for(int i=0;i<strlen(str);i++){
        if(count[i]==0){
            continue;
        }
        result[level]=str[i];
        count[i]=0;
        permute(str,count,result,level+1);
        count[i]=1;
    }
}
