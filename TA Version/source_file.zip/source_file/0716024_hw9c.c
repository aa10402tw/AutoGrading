#include <stdio.h>

int binary_search(int *p,int l,int h,int f/* Write your code here */);

int main(void){
	/* Write your code here */
	int i,j,n,a[100],f,temp;

	scanf("%d",&n);
	for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    scanf("%d",&f);

    for(i=0;i<n-1;i++)
    {
        for(j=0;j<n-i-1;j++)
        {
            if(a[j]>a[j+1])
            {
                temp=a[j+1];
                a[j+1]=a[j];
                a[j]=temp;
            }
        }
    }

    printf("%d",binary_search(a,0,n-1,f));

    return 0;
}

int binary_search(int s[100],int l,int h,int f/* Write your code here */){
   /* Write your code here */

   int mid;
   mid=(l+h)/2;
   //printf("%d, %d, %d\n", l , mid, h);

   if(l>h||mid<l||mid>h)
   {
       return -1;
   }
   else if(s[mid]==f)
   {
       //printf("%d\n",mid);
       return mid;
   }
   else if(s[mid]>f)
   {
       //printf("%d\n",mid);
       return binary_search(s,l,mid-1,f);
   }
   else if(s[mid]<f)
   {
       //printf("%d\n",mid);
       return binary_search(s,mid+1,h,f);
   }
}
