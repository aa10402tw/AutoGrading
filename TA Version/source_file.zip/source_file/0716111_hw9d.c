#include <stdio.h>
int count =0;
void hanoi(int n, char fr, char tr, char ar);

int main() {

    int n;

    scanf("%d", &n);



    hanoi(n, 'A', 'C', 'B'); // A, B, C are tower
    printf("%d",count);
    return 0;/* Write your code here */
}

void hanoi(int n, char fr, char tr, char ar/* Write your code here */){
    if (n == 1)
    {
        count+=1;
        return;
    }
    hanoi(n - 1, fr, ar, tr);
    count +=1;
    hanoi(n - 1, ar, tr, fr);

}
