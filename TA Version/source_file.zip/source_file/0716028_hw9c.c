#include <stdio.h>

int binary_search(/* Write your code here */int a[],int left,int right,int obj);
void sort(int a[],int n);
void swap(int *i,int *j);

int main(void){
	/* Write your code here */
	int num,a[100],objects;
	scanf("%d",&num);
	for(int i=0;i<num;i++)
    {
        scanf("%d",&a[i]);
    }
    sort(a,num);
    scanf("%d",&objects);
    printf("%d",binary_search(a,0,num-1,objects));

    return 0;
}

int binary_search(/* Write your code here */int a[],int left,int right,int obj){
    /* Write your code here */
    if(left==right)
    {
        if(a[left]==obj)
            return left;
        else
            return -1;
    }
    int middle;
    middle=(left+right)/2;
    if(a[middle]<obj)
        return binary_search(a,middle+1,right,obj);
    else
        return binary_search(a,left,middle,obj);
}

void sort(int a[],int n)
{
    for(int i=n;i>1;i--)
    {
        for(int j=1;j<i;j++)
        {
            if(a[j-1]>a[j])
                swap(&a[j-1],&a[j]);
        }
    }
}

void swap(int *i,int *j)
{
    int temp;
    temp=*i;
    *i=*j;
    *j=temp;
}
