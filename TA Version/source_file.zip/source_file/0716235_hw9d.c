#include <stdio.h>

int sum=1;
void hanoi(int lalala);

int main() {
    /* Write your code here */
    int pp;
    while(scanf("%d",&pp)!=EOF)
    {
        hanoi(pp);
        sum=1;
    }
}

void hanoi(int lalala){
    /* Write your code here */
    if(lalala==1)
        printf("%d\n",sum);
    else
    {
        sum=sum*2+1;
        hanoi(lalala-1);
    }

}
