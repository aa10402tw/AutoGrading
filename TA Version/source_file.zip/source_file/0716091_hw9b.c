#include <stdio.h>

int GCD(int a,int b);

int main(){
   int a,b;
   scanf("%d",&a);
   scanf("%d",&b);
   printf("%d",GCD(a,b));
   return 0;
}

int GCD(int a,int b){
    if(a%b==0)
        return b;
    else
        return GCD(b,a%b);
}
