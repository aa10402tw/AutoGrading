//0716052_hw9b
#include <stdio.h>
#include <stdlib.h>

int GCD(int nNum1, int nNum2);

int main() {
	int nNum1, nNum2, nAns, temp;
	scanf("%d %d", &nNum1, &nNum2);
	nAns = GCD(nNum1, nNum2);
	printf("%d\n", nAns);

	//system("pause");
	return 0;
}

int GCD(int nNum1, int nNum2) {
	int a, b;
	if (nNum2 == 0)
		return nNum1;
	else {
		return GCD(nNum2, nNum1 % nNum2);
	}
		
}