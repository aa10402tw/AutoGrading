#include <stdio.h>
#include <stdlib.h>
//#define N 8
int count=0;
void backTrack(int*, int*, int*, int*, int,int, void (*)(int*));
void queens(int*,int);




void queens(int* queen,int N) {
    int x, y;
    for(y = 0; y < N; y++) {
        for(x = 0; x < N; x++) {
            //printf(" %c", queens[y] == x ? 'Q' : '.');
        }
        //printf("\n");
    }
    count++;
    //printf("\n");
}
void backTrack(int* column, int* slash, int* backSlash,
               int* queen, int i, int N,void (*take)(int*)) {
    if(i >= N) {
        take(queen);
    }
    else {
        int j;
        for(j = 0; j < N; j++) {
            if(isVisitable(i, j, column, slash, backSlash,N)) {
                queen[i] = j;
                column[j] = slash[i + j] = backSlash[i - j + N] = 1;
                backTrack(column, slash, backSlash, queen, i + 1,N, take);
                column[j] = slash[i + j] = backSlash[i - j + N] = 0;
            }
        }
    }
}

int isVisitable(int i, int j, int* column, int* slash, int* backSlash,int N) {
    return !(column[j] || slash[i + j] || backSlash[i - j + N]);
}


int main(void)
{
    int N;
    scanf("%d",&N);
    
    int column[100] = {0};        // 同行是否有皇后
    int slash[2 * 100] = {0};     // 右上至左下是否有皇后
    int backSlash[2 * 100] = {0}; // 左上至右下是否有皇后
    int queen[100] = {0};
    
    
    
    backTrack(column, slash, backSlash, queen, 0,N, queens);
    printf("%d",count);
    
    return 0;
}







