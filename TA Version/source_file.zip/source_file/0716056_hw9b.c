//
//  main.c
//  0716056_hw9b
//
//  Created by 王孜甄 on 2018/11/19.
//  Copyright © 2018 eliawang_. All rights reserved.
//

#include <stdio.h>

int GCD(/* Write your code here */int a,int b);

int main(){
    /* Write your code here */
    int a,b;
    scanf("%d%d",&a,&b);
    printf("%d",GCD(a,b));
    return 0;
}

int GCD(/* Write your code here */int a,int b){
    /* Write your code here */
    if(a%b==0)
        return b;
    else return GCD(b,a%b);
}
