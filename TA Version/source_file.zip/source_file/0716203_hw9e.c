#include <stdio.h>
#include <stdbool.h>
#include<string.h>

void permute();
void swap(char *a,char *b);
bool use[11]={false};
char arr[11];

int main()
{
    char c[11];
    scanf("%s",c);
    int len=strlen(c);
    for(int i=0; i<len-1; i++)
        for(int j=0; j<len-1-i; j++)
            if(c[j]>c[j+1])
                swap(&c[j],&c[j+1]);
    permute(c, len);

    return 0;
}

void permute(char *a,int len)
{
    static int k=0;
     for (int i = 0; i < len; i++)
    {
        for (; use[i] == true; i++);
        if (i != len)
        {
            use[i] = true;
            arr[k++] = a[i];
            if (k == len)
                printf("%s\n",arr);
            permute(a, len);
            k--;
            use[i] = false;
        }
    }
}

void swap(char *a,char *b)
{
    char tmp=*a;
    *a=*b;
    *b=tmp;
}

