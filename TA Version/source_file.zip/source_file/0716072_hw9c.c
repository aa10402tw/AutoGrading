#include <stdio.h> 

int arr[1000]={};
int length;

void sort(){
    for(int i=1;i<length;i++){
        int j=i;
        while(j){
            if(arr[j]<arr[j-1]){
                int tem=arr[j];
                arr[j]=arr[j-1];
                arr[j-1]=tem;
            }
            j--;
        }
    }
}

int binary_search();

int main(void){ 
	scanf("%d",&length);
    for(int i=0;i<length;i++){
        scanf("%d",&arr[i]);
    }
    sort();
    int target;
    scanf("%d",&target);
    printf("%d\n",binary_search(target,0,length-1));

}

int binary_search(int n,int first,int final){ 
    if(first==final&&n!=arr[first]){
        return -1;
    }
   else if(n==arr[(first+final)/2]){
       return (first+final)/2;
   }
   else if(n<arr[(first+final)/2]){
       return binary_search(n,first,(first+final)/2-1);
   }
   else{
       return binary_search(n,(first+final)/2+1,final);
   }
}



//cd "/Users/jia/Desktop/hw9/sample code/" && gcc c_sample.c -o c_sample && "/Users/jia/Desktop/hw9/sample code/"c_sample