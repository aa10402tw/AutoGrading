#include <stdio.h>


int GCD(int A, int B);

int main(){
   int insert_A, insert_B;
   scanf("%d %d", &insert_A, &insert_B);
   printf("%d\n", GCD(insert_A, insert_B));
}

int GCD(int A, int B){
    if(A > B){
    	int tmp;
    	tmp = A;
    	A = B;
    	B = tmp;
    }
    if(B % A == 0) return A;
    else return GCD(B % A, A);
}