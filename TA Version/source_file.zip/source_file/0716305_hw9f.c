#include<stdio.h>

void queens(int,int);

int check(int,int);

int count=0;

int n;

int chess[15][15];

int main(){
    scanf("%d",&n);
    chess[n][n];
    queens(0,0);
    printf("%d",count);
    return 0;
}

void queens(int i,int j){
    if(j>=n){
        return;
    }
    if(check(i,j)==1){
        chess[i][j]=1;
        if(i==n-1){
            count++;
        }
        else{
            queens(i+1,0);
        }
    }
    chess[i][j]=0;
    queens(i,j+1);
}

int check(int i,int j){
    int k;
    for(k=0;k<n;k++){
        if(chess[i][k]==1 || chess[k][j]==1){
            return 0;
        }
    }
    for(k=-n;k<=n;k++){
        if(i+k>=0&&i+k<n&&j+k>=0&&j+k<n){
            if(chess[i+k][j+k]==1){
                return 0;
            }
        }
        if(i-k>=0&&i-k<n&&j+k>=0&&j+k<n){
            if(chess[i-k][j+k]==1){
                return 0;
            }
        }
    }
    return 1;
}
