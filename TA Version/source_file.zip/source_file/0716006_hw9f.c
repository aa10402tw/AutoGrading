#include <stdio.h>
#include <stdlib.h>
int queen[], sum=0; /* max为棋盘最大坐标 */
int check(int n) /* 检查当前列能否放置皇后 */
{
    int i;
    for(i = 0; i < n; i++) /* 检查横排和对角线上是否可以放置皇后 */
    {
        if(queen[i] == queen[n] || abs(queen[i] - queen[n]) == (n - i))
        {
            return 1;
        }
    }
    return 0;
}

void queens(int n,int max) /* 回溯尝试皇后位置,n为横坐标 */
{
    int i;
    for(i = 0; i < max; i++)
    {
        queen[n] = i; /* 将皇后摆到当前循环到的位置 */
        if(!check(n))
        {
            if(n == max - 1)
            {
                sum++; /* 如果全部摆好，则输出所有皇后的坐标 */
            }
            else
            {
                queens( (n + 1), max); /* 否则继续摆放下一个皇后 */
            }
        }
    }
}

int main()
{   int N;
    scanf("%d",&N);
    queens(0,N); /* 从横坐标为0开始依次尝试 */
    printf("%d", sum);
    return 0;
}
