#include <stdio.h>

int GCD(int a, int b);

int main()
{
    int a,b;
    scanf("%d%d",&a,&b);
    if(a>=b)
        printf("%d",GCD(a,b));
    if(a<b)
        printf("%d",GCD(b,a));
    return 0;
}

int GCD( int a, int b)//a>=b
{

    if(a%b==0)
        return b;
    if(a%b!=0)
        return GCD(a,a%b);
}

