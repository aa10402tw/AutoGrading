#include <stdio.h>
void merge_sort(int a[], int l, int r);
void merge(int a[], int l, int m, int r);
int binary_search(int a[], int l, int r, int target);

int main(void){
   int a[100],n,target;
   scanf("%d",&n);
   for(int i=0;i<n;i++)
      scanf("%d",&a[i]);
   merge_sort(a,0,n-1);
   scanf("%d",&target);
   printf("%d\n",binary_search(a,0,n-1,target));
   return 0;
}

void merge_sort(int a[], int l, int r){
    int m=l+(r-l)/2;
    if(l<r){
        merge_sort(a, l, m);
        merge_sort(a, m+1, r);
        merge(a, l, m, r);
    }
}

void merge(int a[], int l, int m, int r){
    int n1=m-l+1, n2=r-m, i=0, j=0;
    int L[n1], R[n2];
    for(int x=0;x<n1;x++)
        L[x]=a[l+x];
    for(int x=0;x<n2;x++)
        R[x]=a[m+1+x];

    for(int k=0;k<n1+n2;k++){
        if((L[i]<R[j] && i!=n1)|| j==n2)
            a[l+k]=L[i++];
        else
            a[l+k]=R[j++];
    }
}

int binary_search(int a[], int l, int r, int target){
   int index=l+(r-l+1)/2;
   if(a[index]==target)
      return index;
   if(l==r)
      return -1;
   if(a[index]>target)
      return binary_search(a,l,index-1,target);
   if(a[index]<target)
      return binary_search(a,index+1,r,target);
}
