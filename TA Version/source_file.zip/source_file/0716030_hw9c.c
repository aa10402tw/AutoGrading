#include <stdio.h>

int binary_search(int a[],int l,int r,int i_we_want);

int main(void){
	int n;
	int i_tem;
	int input[101];
	int i_we_want;

	scanf("%d",&n);

	for(int i=0;i<n;i++){
        scanf("%d",&input[i]);
	}
	scanf("%d",&i_we_want);

	for(int i=0;i<n;i++){                                               //先排序
        for(int k=i+1;k<n;k++){
            if(input[i]>input[k]){
                i_tem=input[i];
                input[i]=input[k];
                input[k]=i_tem;
            }
        }
	}
    if(i_we_want>input[n-1] || i_we_want<input[0])printf("-1");
    else printf("%d",binary_search(input,0,n-1,i_we_want));

	/*for(int i=0;i<n;i++)
	printf("%d ",input[i]);*/



}

int binary_search(int a[],int l,int r,int i_we_want){
   int index=(r+l)/2;
   int answer;
   //printf("%d\n",a[index]);
   //printf("l=%d r=%d index=%d" ,l,r,index);
   //printf("r-l=%d\n",r-l);
   if((r-l==1) ){
        if((i_we_want==a[l]))return l;
        else if(i_we_want==a[r])return r;


        else return -1;

   }


   if(a[index]==i_we_want)answer=index;
   else if(a[index]>i_we_want)answer=binary_search(a,l,index,i_we_want);
   else if(a[index]<i_we_want)answer=binary_search(a,index,r,i_we_want);

   return answer;
}
