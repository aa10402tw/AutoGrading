#include <stdio.h>

int SUM(int,int,int);

int main(){
	/* Write your code here */
	int N,i=0,total=0;
	scanf("%d",&N);
	printf("%d",SUM(N,i,total));
	return 0;
}

int SUM(int N,int i,int total){
	/* Write your code here */
	if(i<=N){
		total=total+i;
		i++;
		SUM(N,i,total);
		//return ;
	}
	else return total;
}
