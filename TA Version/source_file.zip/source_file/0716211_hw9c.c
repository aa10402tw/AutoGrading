#include <stdio.h>

int binary_search(int a[],int m, int n, int k/* Write your code here */);

int main(void){
	/* Write your code here */
	int n,k;
	scanf("%d",&n);
	int a[n];
	for(int i=0;i<n;i++){
        scanf("%d",&a[i]);
	}
	for(int i=0;i<n-1;i++){
        for(int j=n-1;j>i;j--){
            if(a[j]<a[j-1]){
                int tmp=a[j];
                a[j]=a[j-1];
                a[j-1]=tmp;
            }
        }
    }

	scanf("%d",&k);
	binary_search(a,0,n-1,k);

}

int binary_search(int a[], int m, int n, int k/* Write your code here */){
   /* Write your code here */
    if(m==(m+n)/2){
        if(k==a[m]){
            printf("%d",m);
            return 0;
        }
        else if(k==a[n]){
            printf("%d",n);
            return 0;
        }
        else{
            printf("-1");
            return 0;
        }
    }
    if(k==a[(m+n)/2]){
        printf("%d",(m+n)/2);
        return 0;
    }else if(k<a[(m+n)/2]){
        binary_search(a,m,(m+n)/2,k);
    }else if(k>a[(m+n)/2]){
        binary_search(a,(m+n)/2,n,k);
    }
}
