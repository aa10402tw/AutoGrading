#include <stdio.h>

int SUM(/* Write your code here */int);

int main(){
	/* Write your code here */
	int n;
	scanf("%d",&n);
	printf("%d\n",SUM(n));
	return 0;
}

int SUM(/* Write your code here */int foo){
	/* Write your code here */
	if(foo==1)return 1;
	return foo+SUM(foo-1);
}
