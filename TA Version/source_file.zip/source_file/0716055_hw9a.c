#include <stdio.h>

int SUM(int n);

int main(){
    /* Write your code here */
    int a;
    scanf("%d",&a);
    printf("%d\n",SUM(a));
}

int SUM(int n){
    /* Write your code here */
    if (n==1) {
        return 1;
    }else{
        return n+SUM(n-1);
    }
}
