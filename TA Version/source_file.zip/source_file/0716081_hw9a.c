#include <stdio.h>

int SUM(int n);

int main(){

	int n;

	scanf("%d", &n);
	printf("%d", SUM(n));

	return 0;
}

int SUM(int n){
	if(n==1)
        return 1;
    else
        return n+SUM(n-1);
}
