#include <stdio.h>

void queens(int i,int *a,int *b,int *c,int *k,int n);

int inc = 0;

int main(){
    int n;

    scanf("%d",n);
    int a[15],b[43],c[43],k[15][15];

    queens(1,&a[0],&b[n],&c[0],&k[0][0],n);

    printf("%d",inc);
    return 0;
}

void queens(int i,int *a,int *b,int *c,int *k[15][15],int n){
    int j = 0, t, u;

  while (++j <= n)
    if (a[j] + b[j - i] + c[j + i] == 0) {
      k[i][j] = 1;
      a[j] = 1;
      b[j - i] = 1;
      c[j + i] =1;

      if (i < n) queens(i+1,&a[0],&b[0],&c[0],&k[0][0],n);
      else {
        ++inc;
        if (1) {
            for (printf("(%d)\n", inc), u = n + 1; --u; printf("\n"))
            for (t = n + 1; --t; ) k[t][u] ? printf("Q ") : printf("+ ");
          printf("\n\n\n");
        }
      }
      a[j] = b[j - i] = c[j + i] = k[i][j] = 0;
    }
}
