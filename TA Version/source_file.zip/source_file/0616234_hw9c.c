#include <stdio.h> 

int binary_search(int [], int , int , int );
void bubble ( int a[] , int n ) {
	int i , j ;
	for ( i = 0 ; i < n-1 ; i ++ )
	{
		for ( j = i + 1 ; j < n ; j ++ )
		{
			int temp ;
			if ( a[i] > a[j] )
			{
				temp = a[i] ;
				a[i] = a[j] ;
				a[j] = temp ;
			}
		}
	}
}

int main(void){ 
	int a[100];
  int len, pos, search_item;
 
  scanf("%d", &len);
  int i ;
  

  for (i=0; i<len; i++)
    scanf("%d", &a[i]);
 

  scanf("%d", &search_item);
  bubble ( a , len ) ;
  
  pos = binary_search(a,0,len-1,search_item);
 
  if (pos < 0 )
    printf("-1");
 
  else
    printf("%d", pos); 
    
  return 0;
}

int binary_search(int a[], int low, int high, int x) {
   int mid = (low + high) / 2;
   if (low > high) return -1;
   if (a[mid] == x) return mid;
   
   if (a[mid] < x) 
     return binary_search(a, mid + 1, high, x);
   else 
     return binary_search(a, low, mid-1, x);
}
