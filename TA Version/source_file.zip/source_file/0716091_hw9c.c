#include <stdio.h>
#include<stdlib.h>

int f(const void*a,const void*b)
{
    return (*(int*)a-*(int*)b);
}

int binary_search(int l,int r,int n,int*a);

int main(void){
	int len,n;
	scanf("%d",&len);
	int a[len],l=0,r=len-1;
	for(int i=0;i<len;i++)
        scanf("%d",&a[i]);
    scanf("%d",&n);
	qsort(a,len,sizeof(int),f);
	printf("%d",binary_search(l,r,n,a));
	return 0;
}

int binary_search(int l,int r,int n,int*a){
    if(l>r)
        return -1;
    if(n>a[(l+r)/2])
        return binary_search((l+r)/2+1,r,n,a);
    else if(n<a[(l+r)/2])
        return binary_search(l,(l+r)/2-1,n,a);
    else if(n==a[(l+r)/2])
        return (l+r)/2;
}
