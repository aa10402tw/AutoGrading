#include <stdio.h>

int SUM(int n);

int main(){
	/* Write your code here */
    int n;
    scanf("%d",&n);
    printf("%d",SUM(n));
}

int SUM(int n)
{
    //printf("%d\n", n);
    if(n==1)
        return 1;
    else
        return n+SUM(n-1);
}


/*
int SUM(int n){
	/* Write your code here
    int sum;
    for(int i=1; i<=n; i++)
        sum +=i;
    return sum;
}
*/
