//
//  main.c
//  0716056_hw8d
//
//  Created by 王孜甄 on 2018/11/20.
//  Copyright © 2018 eliawang_. All rights reserved.
//

#include <stdio.h>

void hanoi(/* Write your code here */int n);
int count=0;
int main() {
    /* Write your code here */
    int n;
    scanf("%d",&n);
    hanoi(n);
    printf("%d",count);
}

void hanoi(/* Write your code here */int n){
    /* Write your code here */
    if(n==1)
        count++;
    else{
        hanoi(n-1);
        hanoi(1);
        hanoi(n-1);
    }
}
