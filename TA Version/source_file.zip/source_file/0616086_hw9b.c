#include <stdio.h>

int GCD(/* Write your code here */);

int main(){
  int a,b;
  scanf("%d%d",&a,&b);
  printf( "%d",GCD(a,b) );
  return 0;
}

int GCD(int a,int b){
    return ( b==0 ? a : GCD(b,a%b) );
}
