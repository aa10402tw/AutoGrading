#include <stdio.h>

int c=0;

void hanoi(int n/* Write your code here */);

int main() {
    /* Write your code here */
    int n;

    scanf("%d",&n);

    hanoi(n);

    printf("%d",c);

    return 0;
}

void hanoi(int n/* Write your code here */){
    /* Write your code here */
    if (n == 1)
    {
        c++;
    }
    else
    {
        hanoi(n-1);
        c++;
        hanoi(n-1);
    }
}
