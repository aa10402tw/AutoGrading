#include <stdio.h>

void hanoi(int n,char A,char B,char C);
int time=0;
int main() {
    int n;
    scanf("%d",&n);
    hanoi(n,'A','B','C');
    printf("%d\n",time);
    return 0;
}

void hanoi(int n,char A,char B,char C){
    if(n==1)
        time+=1;
    else{
        hanoi(n-1,A,C,B);
        hanoi(1,A,B,C);
        hanoi(n-1,B,A,C);
    }


}
