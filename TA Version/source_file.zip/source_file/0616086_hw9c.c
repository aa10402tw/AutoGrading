#include <stdio.h>
#include<stdlib.h>
#include<string.h>
int cp(const void *a,const void *b){
    return(*(int *)a-*(int *)b);
}
int binary_search(/* Write your code here */);

int main(void){
	int n,i;
	scanf("%d",&n);
	int s[n+1];

	for(i=0;i<n;i++)
        scanf("%d",&s[i]);
    qsort(s,n,sizeof(s[0]),cp);

    int x;
    scanf("%d",&x);
    printf("%d",binary_search(s,0,n-1,x));

return 0;
}

int binary_search(int *s, int l, int r,int x){
    int m=(r-l)/2+l;
    if(r==l){
        if(x==s[l]) return m;
        else return -1;
    }
    if(l+1<r){
        if(s[m]==x) return m;
        else if(s[m]<x) binary_search(s,m,r,x);
        else binary_search(s,l,m,x);
    }
    else if(r-l==1){
            if(x==s[r]) return m+1;
            else if(x==s[l]) return m;
            else return -1;
    }
}


