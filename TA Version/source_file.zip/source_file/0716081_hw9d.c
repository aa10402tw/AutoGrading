#include <stdio.h>

int time = 0;

void hanoi(int n);

int main()
{
    int n;

    scanf("%d", &n);
    hanoi(n);
    printf("%d", time);

    return 0;
}

void hanoi(int n)
{

    if(n == 1)
        time++;
    else
    {
        time++;
        hanoi(n-1);
        hanoi(n-1);
    }


}
