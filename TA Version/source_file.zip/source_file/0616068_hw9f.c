#include <stdio.h>
#include <string.h>
int ans = 0, col[15];

void queens(int cur, int n);

int main(){
    int n;
    scanf("%d", &n);
    queens(0, n);
    printf("%d", ans);
}

void queens(int cur, int n){
    if (cur == n) {
        ans++;
    } else {
        for (int i = 0; i < n; i++) {
            int flag = 1;
            col[cur] = i;
            for (int j = 0; j < cur; j++) {
                if (col[cur] == col[j] || cur - col[cur] == j - col[j] || cur + col[cur] == j + col[j]) {
                    flag = 0;
                    break;
                }
            }
            if (flag) {
                queens(cur + 1, n);
            }
        }
    }
}
