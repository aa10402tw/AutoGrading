#include <stdio.h>
#include <math.h>

int binary_search(int array[],int L,int R,int target);

int sort(int *array,int length){
    for(int i = 0;i < length ; i++){
        int min = i;
        for(int j = i+1;j<length ; j++){
            if(array[j]<array[min]){
                min = j;
            }
        }
        if(i != min){
            int temp = array[i];
            array[i] = array[min];
            array[min] = temp;
        }
    }
}

int main(void){
	/* Write your code here */
    int n;
    scanf("%d",&n);

    int arr1[n];
    for(int i = 0 ; i< n;i++){
        scanf("%d",&arr1[i]);
    }

    sort(arr1,n);

    int target,L,R;
    scanf("%d",&target);
    L = 0;
    R = n -1;

    printf("%d",binary_search(arr1,L,R,target));
    return 0;
}

int binary_search(int arr1[],int L,int R,int target){
   /* Write your code here */
   int M = (int)floor((L+R)/2);



   if (arr1[M] == target){
    return M;
   }
   else if(arr1[M]>target){
        R =  (int)floor(R/2);
    return binary_search(arr1,L,R,target);
   }
   else if (arr1[M]<target){
        L = M+1;
    return binary_search(arr1,L,R,target);
   }

   if(M == 0){
    return -1;
   }

}
