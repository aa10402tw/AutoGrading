#include <stdio.h>

int GCD(int A, int B);

int main()
{
    int x,y;
    scanf("%d %d",&x,&y);
    printf("%d",GCD(x,y));

}

int GCD(int A, int B)
{
    if (A > B)
    {
        return GCD(A-B,B);
    }
    else if (B>A)
    {
        return GCD(B-A,A);
    }
    if (A==B)
    {
        return A;
    }

}

