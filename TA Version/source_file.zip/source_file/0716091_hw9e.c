#include<stdio.h>
#include<stdlib.h>
#include<string.h>

void permute(char*a,int*b,char*c,int z,int n);

int f(const void*a,const void*b)
{
    return (*(char*)a-*(char*)b);
}

int main(){
    char s[100],a[100],c[100]={};
    int b[100]={0};
    scanf("%s",s);
    int n=strlen(s);
    a[0]=s[0];
    b[0]=1;
    qsort(s,n,sizeof(char),f);
    int k=1;
    for(int i=1;i<n;i++)
    {
        int count=0;
        for(int j=0;j<i;j++)
        {
            if(s[i]==a[j])
            {
                b[j]++;
                count++;
                break;
            }
        }
        if(count==0)
        {
            a[k]=s[i];
            b[k]++;
            k++;
        }
    }
    permute(a,b,c,0,n);
    return 0;
}

void permute(char*a,int*b,char*c,int z,int n){
    if(z==n)
    {
        printf("%s\n",c);
        return;
    }
    int i;
    for(i=0;i<strlen(a);i++)
    {
        if(b[i]==0)
            continue;
        c[z]=a[i];
        b[i]--;
        permute(a,b,c,z+1,n);
        b[i]++;
    }
}
