#include <stdio.h>

void queens(/* Write your code here */);

int main(){
    /* Write your code here */
    int q,mem[14],ans=0;
    scanf("%d",&q);
    for(int c1=0;c1<q;c1++) {
        mem[0]=c1;
        queens(q,1,mem,&ans);
    }
    printf("%d",ans);
    return 0;
}
//phase start from 1
void queens(/* Write your code here */int q,int phase,int *mem,int *ans){
    /* Write your code here */
    for(int look=0;look<q;look++){
        *(mem+phase)=look;
        for(int bef=phase-1;bef>=0;bef--){
            int check=*(mem+bef)-*(mem+phase);
            if(check!=phase-bef && check!=bef-phase && check!=0){
//                printf("%d, %d, %d, %d\n",check, phase-bef, phase,bef);
                if(bef==0)
                {
                    if(phase==q-1){
//                        for(int i=0;i<q;++i)
//                        printf("%d, ",mem[i]);
//                        printf("\n");
                        (*ans)++;
                    }
                    else queens(q,phase+1,mem,ans);
                }
            }
            else break;
        }
    }
}

