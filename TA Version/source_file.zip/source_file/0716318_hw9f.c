#include <stdio.h>
#define QUEENS       8
int A[QUEENS + 1], B[QUEENS * 3 + 1], C[QUEENS * 3 + 1], k[QUEENS + 1][QUEENS + 1];
int inc, *a = A, *b = B + QUEENS, *c = C;
void queens(/* Write your code here */);

int main(){
    /* Write your code here */
scanf("%d",&QUEENS);
queens(1);
  printf("%d", inc);
  getchar();
  return 0;
}

void queens(int i/* Write your code here */){
    /* Write your code here */
 int j = 0, t, u;

  while (++j <= QUEENS)
    if (a[j] + b[j - i] + c[j + i] == 0) {
      k[i][j] = a[j] = b[j - i] = c[j + i] = 1;
      if (i < QUEENS) queens(i + 1);
      else {
        ++inc;
      }
      a[j] = b[j - i] = c[j + i] = k[i][j] = 0;
    }
}

