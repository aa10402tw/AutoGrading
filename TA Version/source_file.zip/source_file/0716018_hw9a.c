#include <stdio.h>

int SUM(int);

int main(){
	int cos;
	scanf("%d",&cos);
	int sum=SUM(cos);
	printf("%d",sum);
	return 0;
}

int SUM(int n){
	if(n==1)
        return 1;
    else
        return (n+SUM(n-1));
}
