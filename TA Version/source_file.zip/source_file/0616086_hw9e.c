#include <stdio.h>
#include <stdlib.h>
#include<string.h>
void bubble(char *,int );
void swap(char *a,char *b);
void permute(char *,int );


int n;

int main(){
    char str[11];
    scanf("%s",str);
    n=strlen(str);
    bubble(str,n);
    permute(str,0);
}


void permute(char *str,int i){
    int j;

    if( i==n-1 ){
        printf("%s\n",str);;
    }
       else {
        permute(str,i+1);
        for(j=i+1;j<n;j++){
        swap(str+i,str+j);
        permute(str,i+1);
        }
        int t = str[i];
        memmove(str+i, str+i+1, n-1-i);
        str[n-1] = t;
      }
}


void swap(char *a,char *b){
    char tem;
    tem=*a;
    *a=*b;
    *b=tem;
}

void bubble(char *str,int n){
    int i,j;
    for(i=1;i<n;i++){
        for(j=0;j<n-i;j++){
            if(str[j]>str[j+1])
                swap(str+j,str+j+1);
        }
    }
}
