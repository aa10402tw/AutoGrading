//
//  main.c
//  0716056_hw9
//
//  Created by 王孜甄 on 2018/12/1.
//  Copyright © 2018 eliawang_. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>

int in_row[14]={0};
int diag[27]={0};
int back_diag[27]={0};
int count=0;

void queens(/* Write your code here */int n,int i);

int main(){
    /* Write your code here */
    int n;
    scanf("%d",&n);
    queens(n,0);
    
    printf("%d",count);
    return 0;
}

void queens(/* Write your code here */int n,int i){
    /* Write your code here */
    int row;
    for(row=0;row<n;row++){
        //-1因為如果是14的話會用到28
        if(in_row[row] == 0 && diag[n-(i-row)-1]==0 && back_diag[row+i]==0) {
            in_row[row]=1;
            diag[n-(i-row)-1]=1;
            back_diag[row+i]=1;
            if(i<n-1)
                queens(n,i+1);
            else {
                count++;
            }
            in_row[row]=0;
            diag[n-(i-row)-1]=0;
            back_diag[row+i]=0;
        }
    }
}
