#include <stdio.h>
int times=0;
void hanoi(int disk);

int main(){
    int disk;
    scanf("%d",&disk);
    hanoi(disk);
    printf("%d",times);
}
void hanoi(int disk){
    if(disk==1){
        times++;
    }
    else{
        hanoi(disk-1);
        times++;
        hanoi(disk-1);
    }
}
