#include <stdio.h>

int SUM(int);

int main(){
	int n;
	scanf("%d",&n);
	printf("%d",SUM(n));
	return 0;
}

int SUM(int a){
    if(a>0){
        return a+SUM(a-1);
    }
}
