#include <stdio.h>
#include <stdbool.h>
#include <string.h>
int k = 0;
void permute(char *array,int char_counter,int);

int main(){
    /* Write your code here */
    char array[100];
    scanf("%s",array); //get array

    int i;

    for( i = 0; array[i]!='\0';i++); //number of inputs

    bool char_seen[200] = {false};
    int char_counter[200] = {0};

    for(int j = 0;j<i;j++){ //show if char have been seen
        char_seen[array[j]] = true;
        char_counter[array[j]]++;
    }

    permute(array,i-1,0);
    return 0;
}

void permute(char *array,int length,int startindex){
    int i;
    if(startindex == length){
        printf("%s\n",array);

    }
    else{
        for( i = startindex;i<=length;i++){
            char temp = array[i];
            array[i] = array[startindex];
            array[startindex] = temp;
            permute(array,length,startindex+1);
             temp = array[i];
             array[i] = array[startindex];
             array[startindex] = temp;
        }
    }
}
