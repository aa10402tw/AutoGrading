#include <stdio.h>

void hanoi(int n, char a, char b, char c);
int sum=0;

int main() {
    int n;
    scanf("%d",&n);
    hanoi(n,'A','B','C');
    printf("%d",sum);
    return 0;
}

void hanoi(int n, char A, char B, char C){
    if(n==1)
        sum++;
    else{
        hanoi(n-1,A,C,B);
        hanoi(1,A,B,C);
        hanoi(n-1,B,A,C);
    }
}
