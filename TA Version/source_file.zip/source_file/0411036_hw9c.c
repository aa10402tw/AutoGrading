#include <stdio.h>

int binary_search(int *p, int s, int e, int target);

void sort(int *p, int n){
    for (int i=0;i<n;i++){
        for (int j = i; j<n;j++){
            if (p[i] > p[j]) {
                int t = p[i];
                p[i] = p[j];
                p[j] = t;
            }
        }
    }
}

int main(void){
	int n;
	scanf("%d", &n);
	int data[n];
	for(int i=0;i<n;i++) scanf("%d", &data[i]);
	int target;
	scanf("%d", &target);
	sort(data, n);
	printf("%d\n", binary_search(data, 0, n-1, target));
}

int binary_search(int *p, int s, int e, int target){
   int m = (s+e)/2;
   if (s >= e) {
     if (p[m] == target) return m;
     else return -1;
   }
   if (p[m] == target) return m;
   int t1 = binary_search(p, s, m-1, target);
   int t2 = binary_search(p, m+1, e, target);
   if (t1 >= 0) return t1;
   if (t2 >= 0) return t2;
   return -1;
}
