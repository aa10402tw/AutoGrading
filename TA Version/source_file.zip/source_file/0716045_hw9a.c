#include <stdio.h>

int SUM(int n);

int main(){
	int input;
	scanf("%d",&input);
	printf("%d\n",SUM(input));

	return 0;
}

int SUM(int n){
	if(n==1)
        return 1;
    else
        return n+SUM(n-1);
}
