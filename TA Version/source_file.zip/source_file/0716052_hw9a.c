//0716052_hw9a
#include <stdio.h>
#include <stdlib.h>

int SUM(int nN);

int main() {
	int nN, nAns;
	scanf("%d", &nN);
	nAns = SUM(nN);
	printf("%d\n", nAns);

	//system("pause");
	return 0;
}

int SUM(int nN) {
	if (nN == 1)
		return 1;
	else
		return nN + SUM(nN - 1);
}