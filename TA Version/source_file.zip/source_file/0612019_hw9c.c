#include <stdio.h>

int binary_search( int arr[] , int L , int R , int x );

int main(void){
int arr[100] , x , len ;
    scanf( "%d" , &len );
    for( int i = 0 ; i < len ; i++){
        scanf( "%d" , &arr[i] );
    }
    for( int i = 0 ; i < len ; i++){
        int min = i ;
        for( int j = i+1 ; j < len ; j++){
            if( arr[j] < arr[min] ) min = j;
        }
        int tmp = arr[min];
        arr[min] = arr[i];
        arr[i] = tmp;
    }
    scanf( "%d" , &x );
    printf( "%d" , binary_search( arr , 0 , len-1 , x ) );
return 0;
}

int binary_search( int arr[] , int L , int R , int x ){
    int mid = (L + R)/2;
    if(R>=L){
        if( x == arr[mid]) return mid;
        else if( x < arr[mid]) return binary_search( arr , L , mid , x );
        else return binary_search( arr , mid +1 , R , x );
    }
    return -1;
}
