#include <stdio.h>

void hanoi(int n,char start,char tmp,char end,int *p);

int main()
{
    /* Write your code here */
    int n,times=0;
    int*p=&times;
    char start='a',tmp='b',end='c';
    scanf("%d",&n);
    hanoi(n,start,tmp,end,&times);
    printf("%d",*p);
    return 0;
}

void hanoi(int n,char start,char tmp,char end,int *p)
{
    //static int times=0;
    if(n==1)
       (*p)++;
    else
    {
        hanoi(n-1,start,end,tmp,p);
        hanoi(1,start,tmp,end,p);
        hanoi(n-1,tmp,start,end,p);
    }

}
