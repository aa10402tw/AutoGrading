#include <stdio.h>

void hanoi(int n,int *sum/* Write your code here */);

int main() {
    /* Write your code here */
    int n,s,*sum=&s;
    s=0;
    scanf("%d",&n);
    hanoi(n,sum);
    printf("%d",s);
}

void hanoi(int n,int *sum/* Write your code here */){
    /* Write your code here */
    if(n==1)
        *sum+=1;

    if(n>1){
        int r=1;
        for(int i=1;i<n;i++){
            r*=2;
        }
        *sum+=r;
        hanoi(n-1,sum);
    }


}
