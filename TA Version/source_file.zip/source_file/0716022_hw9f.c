#include <stdio.h>
#include <string.h>
void queens(/* Write your code here */int *tbl,char *used,int n,int l);
int c=0;
int main(){ 
    /* Write your code here */
	int n;
	scanf("%d",&n);
	int tbl[n];
	char used[n];
	memset(used,0,sizeof(char)*n);
	queens(tbl,used,0,n);
	printf("%d\n",c);
	return 0;
}

void queens(/* Write your code here */int *tbl,char *used,int n,int l){
    /* Write your code here */
	if(n==l){
		c++;
		return;
	}
	for(int a=0;a<l;a++){
		if(!used[a]){
			int val=1;
			for(int b=n-1;b>=0&&val;b--){
				if(tbl[b]==a-(n-b)||tbl[b]==a+(n-b)) val=0;
			}
			if(val){
				used[a]=1;
				tbl[n]=a;
				queens(tbl,used,n+1,l);
				used[a]=0;
			}
		}
	}
}
