#include <stdio.h>

int GCD(int a,int b,int sm);

int main(){
   int a,b,sm;
   scanf("%d %d",&a,&b);
   sm=a<b?a:b;
   printf("%d",GCD(a,b,sm));
}

int GCD(int a,int b,int sm){
    int answer;
    if((a%sm==0) && (b%sm==0))return sm;
    answer=GCD(a,b,sm-1);
    return answer;
}

