#include <stdio.h>

int binary_search(int str[],int a,int goal,int N/* Write your code here */);

int main(void){
	/* Write your code here */
    int N,a=1,goal;
    int str[100];
    scanf("%d",&N);
    for(int i=1;i<=N;i++)
        scanf("%d",&str[i]);
    for(int i=1;i<=N;i++)
    {
        for(int j=1;j<=N-i;j++)
        {
            if(str[j]>str[j+1])
            {
                char tem=str[j];
                str[j]=str[j+1];
                str[j+1]=tem;
            }

        }
    }
    scanf("%d",&goal);
    printf("%d",binary_search(str,a,goal,N)-1);
}

int binary_search(int str[],int a,int goal,int N/* Write your code here */){
   /* Write your code here */
    if(a==N+1)
        return -1;
    if(str[a]==goal)
        return a;
    if(str[a]!=goal)
    {
        a++;
        binary_search(str,a,goal,N);
    }

}
