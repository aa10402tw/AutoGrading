#include <stdio.h>


int binary_search(int *a,int L,int H,int target);

int main(void){
    int len;int target;
    scanf("%d",&len);
    int a[len];
    for(int i=0;i<len;i++)
        scanf("%d",&a[i]);
    for(int i=0;i<len;i++){
        for(int j=i+1;j<len;j++){
            if(a[i]>a[j]){
                int c;
                c=a[i];
                a[i]=a[j];
                a[j]=c;
            }
        }
    }

    scanf("%d",&target);
    int L=0,H=len-1;
    printf("%d",binary_search(a,L,H,target));
    return 0;
}

int binary_search(int *a,int L,int H,int target){

    if(L<=H){

        int M=L+(H-L)/2;
        if(a[M]==target){

            return M;
        }

        else if(a[M]>target) {
            return binary_search(a,L,M-1,target);
        }
        else if(a[M]<target){
            return binary_search(a,M+1,H,target);
        }
        else
            return -1;
    }

}
