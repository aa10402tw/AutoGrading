#include <stdio.h>

int binary_search(/* Write your code here */);

int main(void){
	/* Write your code here */
	int n, b[101], i, m, z, r=0, tmp=0;
	scanf("%d", &n);
	for (i=0; i<n; i++)
    {
        scanf("%d", &b[i]);
    }
    for( i=0; i<n-1; i++)
   {
       for(int j=i+1; j<n; j++)
       {
           if(b[i]>b[i+1])
           {
               tmp=b[i];
               b[i]=b[i+1];
               b[i+1]=tmp;
           }
       }
   }
    scanf("%d", &m);
    z=binary_search(n-1,b,m);
    printf("%d", z);
}

int binary_search(/* Write your code here */int l, int b[], int m){
   /* Write your code here */
   if(b[l]==m)
   {
       return l ;
   }
   else if(l==0&&b[l]!=m)
   {
       return -1;
   }
  else
     return binary_search(l-1,b,m);
}
