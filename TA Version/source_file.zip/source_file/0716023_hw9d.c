#include <stdio.h>

void hanoi(int product, int n);

int main()
{
    int nPlate;
    while (scanf("%d", &nPlate) != EOF)
    {
        hanoi(1, nPlate);
    }
}

void hanoi(int product, int n)
{
    if (!n)
    {
        printf("%d\n", product - 1);
        return;
    }
    hanoi(product << 1, n - 1);
}