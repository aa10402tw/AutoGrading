//
//  main.c
//  0716004_hw9d.c
//
//  Created by 成文瑄 on 2018/11/20.
//  Copyright © 2018年 成文瑄. All rights reserved.
//

#include <stdio.h>

void hanoi( int *n, int *t);

int main() {
    /* Write your code here */
    int number, times=0;
    scanf("%d", &number);
    hanoi( &number, &times);
    printf("%d", times);
}

void hanoi(int *n, int *t){
    /* Write your code here */
    int tmp;
    if( *n==1)
        *t=*t+1;
    else{
        tmp=*n-1;
        *n=tmp;
        hanoi( n, t);
        *n=1;
        hanoi( n, t);
        *n=tmp;
        hanoi( n, t);
    }
}
