#include <stdio.h>
#include<string.h>
int str_times=0;

void permute(char *inp,int from,int last,char *str,int n);

int cmp(char *a,char *b,int n)
{
    int counts=0;
    for(;;)
    {
        //if(counts==n)
         //   break;
        if( /*strcmp(a+counts,b+counts)==0*/ *(a+counts)==*(b+counts))
        {
            counts++;
            continue;
        }
        else if( /* strcmp(a+counts,b+counts)>0*/  *(a+counts)>*(b+counts)  )
        {
            return 1;
        }
        else//( *(a+counts)<*(b+counts) )
        {
            return 0;
        }

    }

}
void swap_str(char *a,char *b,int n)
{
    char temp;
    for(int i=0;i<n;i++)
    {
        temp=*(a+i);
        *(a+i)=*(b+i);
        *(b+i)=temp;
    }

}




int stairs(int a)
{
    if(a==1) return 1;
    return a*stairs(a-1);
}
//sort last
void sorl(char *a,int n)
{
    char temp[10];
    int dic_order;
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n-1;j++)
        {
            dic_order=0;//record the order
            dic_order=cmp(a+j*n,a+(j+1)*n,n);
            if(dic_order>0)
            {
                swap_str( a+j*n,a+(j+1)*n,n );
            }
            //if(  strcmp( a+j*n,a+(j+1)*n ) >0 )
            //{
            //    strcpy(temp,a+j*n);
            //    strcpy(a+j*n,a+(j+1)*n);
            //    strcpy(a+(j+1)*n,temp);
            //}
        }
    }
}



//sort first
void sor(char *a,int n)
{
    char temp;
    for(int i=0; i<n; i++)
    {
        for(int j=0; j<n-1; j++)
        {
            if(  (int)(*(a+j))>(int)*(a+1+j) )
            {
                temp=*(a+j);
                *(a+j)=*(a+1+j);
                *(a+1+j)=temp;
            }
        }
    }
    //for(int i=0;i<n;i++)
    //   printf("%c ",*(a+i));
}




int main()
{
    char inp[10];
    scanf("%s",inp);
    int last=( strlen(inp) - 1 );
    int n=last+1;
    char str[stairs(last+1)][last+1];

    sor(inp,n);

    permute(inp,0,last,str,n);

    sorl(str,n);

    for(int i=0; i<stairs(n); i++)
    {
        for(int j=0; j<n; j++)
            printf("%c",str[i][j]);
        printf("\n");
    }
    return 0;
}

void permute(char *inp,int from,int last,char *str,int n)
{
    char temp1,temp2;
    if(from==last)
    {
        //printf("%s\n",inp);
        for(int i=0; i<n; i++)
        {
            *(str+n*str_times+i)=*(inp+i);
        }
        str_times++;

    }

    else
    {
        for(int i=from; i<=last; i++)
        {
            //swap( inp+from,inp+i )
            temp1=*(inp+from);
            *(inp+from)=*(inp+i);
            *(inp+i)=temp1;
            //
            permute( inp,from+1,last,str,n );
            //
            temp1=*(inp+from);
            *(inp+from)=*(inp+i);
            *(inp+i)=temp1;
        }
    }




}
