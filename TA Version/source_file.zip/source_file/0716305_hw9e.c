#include<stdio.h>
#include<string.h>

int str[11]={0};
char end[11];
int r=0;

void swap(char *,char *);

void permute(char *,int);

int main(){
    char input[9];
    scanf("%s",input);
    int len=strlen(input);
    for(int i=0;i<len;i++){
        for(int j=i+1;j<len;j++){
            if(input[i]>input[j]){
                swap(&input[i],&input[j]);
            }
        }
    }
    permute(input,len);
    return 0;
}

void swap(char *a,char *b){
    char c= *a;
    *a = *b;
    *b = c;
}

void permute(char *d,int len){
    for(int i=0;i<len;i++){
        for(;str[i]==1;i++);
        if(i!=len){
            str[i]=1;
            end[r++]=d[i];
            if(r==len){
                printf("%s\n",end);
            }
            permute(d,len);
            r--;
            str[i]=0;
        }
    }
}
