#include <stdio.h>
#include <string.h>
void permute(char *A, int s, int f);
void swap(char *x, char *y);
void selectionsortP(char *chars, int charSize);

int main()
{
    /* Write your code here */

    char inputA[10];
    scanf("%s", inputA);
    int n = strlen(inputA);
    int i = 0;
    
    while (i < n)
    {
        

        char c = inputA[i];
        //printf("%c\n", inputA[i]);
        int j = i - 1;
        while ((int)c < (int)inputA[j] && j >= 0)
        {

            int k = j + 1;
            inputA[k] = inputA[j];
            j--;
            //printf("j= %d\n", j);
        }
        inputA[++j] = c;
        i++;
    }
    permute(inputA, 0, n - 1);
    
}

void permute(char *A, int s, int f)
{
    /* Write your code here */

    if (s == f)
    {
        printf("%s\n", A);
        //return;
    }

    //int i =0;
    for (int i = s; i <= f; i++)
    {
        // if (s == 0)
        // {
        //     swap(A + s, A + i);
        //     selectionsortP((A + s + 1), (f - (s + 1)+1));
        //     //selectionSort();
        //     permute(A, s + 1, f);
        //     swap(A + s, A + i);
        // }
        // else
        // {
            swap(A + s, A + i);
            //after swap then selectionSort
            selectionsortP((A + s + 1), (f - (s + 1) + 1));
            permute(A, s + 1, f);
            //when recursive last and return then sort again
            selectionsortP((A + s + 1), (f - (s + 1) + 1));
            //swap(A + s, A + i);
            
        //}
    }
}

void swap(char *x, char *y)
{
    char temp;
    temp = *x;
    *x = *y;
    *y = temp;
}

void selectionsortP(char *chars, int charSize)
{
    // since we already know charSize is always <= 9,
    // which is pretty small, so we can just use a O(n^2) sorting algorithm,
    // for example, selection sort here.
    for (int i = 0; i < charSize; i++)
    {
        int minIndex = i;
        char minChar = chars[i];
        for (int j = i + 1; j < charSize; j++)
        {
            if (chars[j] < minChar)
            {
                minChar = chars[j];
                minIndex = j;
            }
        }
        if (minIndex != i)
        {
            char temp = chars[i];
            chars[i] = chars[minIndex];
            chars[minIndex] = temp;
        }
    }
}