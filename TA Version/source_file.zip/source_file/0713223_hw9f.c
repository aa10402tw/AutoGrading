#include <stdio.h>
#include <stdbool.h>

#define N 100

int sum=0, num_chess;

void queens(int n, int row, bool ori_board[N][N]/* Write your code here */);

int main(){
    /* Write your code here */
    int n;
    bool ori_board[N][N]={false};

    /*for(int i=0; i<N; i++){
        for(int j=0; j<N; j++){
            ori_board[i][j] = false;
        }
    }*/

    scanf("%d", &n);
    num_chess = n;

    queens(n, 0, ori_board);

    printf("%d\n", sum);

    return 0;
}

void queens(int n, int row, bool ori_board[N][N]/* Write your code here */){
    /* Write your code here */
    int i, coby_row;
    int row_minus_column, row_add_column;
    bool board[N][N];

    if(n == 0){
        sum++;
        return;
    }

    for(int j=row; j<num_chess; j++){
        for(int k=0; k<num_chess; k++){
            board[j][k] = ori_board[j][k];
        }
    }

    for(i=0; i<num_chess; i++){
        if(!board[row][i]){
            //printf("row: %d\n", row);
            //printf("i: %d\n", i);
            /*for(int j=0; j<num_chess; j++) //set row
                board[row][j] = true;*/
            for(int j=row+1; j<num_chess; j++) //set column
                board[j][i] = true;

            row_minus_column = row - i;
            for(int j=row+1; j<num_chess; j++){ //set diagonal 1
                for(int k=0; k<num_chess; k++)
                    if(j-k == row_minus_column)
                        board[j][k] = true;
            }
            row_add_column = row + i;
            for(int j=row+1; j<num_chess; j++){ //set diagonal 2
                for(int k=0; k<num_chess; k++)
                    if(j+k == row_add_column)
                        board[j][k] = true;
            }

            //n--;
            //row++;
            queens(n-1, row+1, board);
            //row--;
            //n++;
            for(int j=row; j<num_chess; j++){
                for(int k=0; k<num_chess; k++){
                    board[j][k] = ori_board[j][k];
                }
            }
        }
        else if(i == num_chess - 1)
            return;
    }
}
