#include <stdio.h>
#include <string.h>
#define print 0

void swap(char *a, char *b){
    char t = *a;
    *a = *b;
    *b = t;
}

void sort(char a[], int l, int r){

    for(int i=r ; i>l ; i--){
        for(int j=l ; j<i ; j++){
            if(a[j]>a[j+1])
                swap(&a[j], &a[j+1]);
        }
    }

}

void permute(char a[], int l, int r);

int main(){

    char str[100];
    scanf("%s", str);
    int len = strlen(str);

    sort(str, 0, len-1);
    permute(str, 0, len-1);

    return 0;
}

void permute(char a[], int l, int r){

    int i, j, k;
    char b[100];

    strcpy(b, a);
    if(l == r)
        printf("%s\n", b);

    sort(b, l, r);
    for(i=l ; i<=r ; i++){
            swap((b+l), (b+i));
            permute(b, l+1, r);
            swap((b+l), (b+i));

    }
}
