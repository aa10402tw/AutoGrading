#include <stdio.h>
#include <stdlib.h>
#include <math.h>

void queens(int x,int i,int *a);
int num=0;

int main(){
    int n;
    scanf("%d",&n);
    int a[n];
    queens(n,0,a);
    printf("%d",num);
    return 0;
}

void queens(int x,int i,int *a){
    int j,k;
    int p=0;
    if(x==i){
        num++;
    }
    else{
        for(j=0;j<x;j++){
            p=0;
            for(k=0;k<i;k++){
                if(j==a[k] || abs(j-a[k])==i-k){
                    p=1;
                }
            }
            if(p==0){
                a[i]=j;
                queens(x,i+1,a);
            }
        }
    }
}
