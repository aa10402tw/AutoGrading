#include <stdio.h>

int SUM(int n);

int main()
{
    int n;
    while (scanf("%d", &n) != EOF)
    {
        printf("%d\n", SUM(n));
    }
}

int SUM(int n)
{
    if (!n)
    {
        return 0;
    }
    return n + SUM(n - 1);
}