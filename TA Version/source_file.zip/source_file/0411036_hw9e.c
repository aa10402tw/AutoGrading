#include <stdio.h>
#include <stdlib.h>

void permute(char *c, int *p, char *out, int dep, int l);

int main(){
    char data[10];
    scanf("%s", data);
    int len = strlen(data);
    for (int i=0; i<len; i++){
        for (int j=i; j<len; j++){
            if (data[i] > data[j]){
                char t = data[i];
                data[i] = data[j];
                data[j] = t;
            }
        }
    }
    int l = 0;
    char out[len+1];
    out[0] = '\0';
    char c[len];
    int p[len];
    p[0] = 1;
    for (int i=1; i<len; i++) p[i] = 0;
    c[0] = data[0];
    for (int i=1; i<len; i++){
        if (data[i-1] == data[i]){
            p[l]++;
            continue;
        }
        l++;
        p[l]++;
        c[l] = data[i];
    }
    l++;
    //for (int i=0; i<len; i++) printf("%d ", p[i]);
    permute(c, p, out, len, l);
}

void permute(char *c, int *p, char *out, int dep, int l){
    if (dep == 0){
        printf("%s\n", out);
        return ;
    }
    for (int i=0; i<l; i++){
        if (p[i] == 0)continue;
        p[i]--;
        int len = strlen(out);
        out[len] = c[i];
        out[len+1] = '\0';
        permute(c, p, out, dep-1, l);
        out[len] = '\0';
        p[i]++;
    }

}
