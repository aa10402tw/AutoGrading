#include <stdio.h>

int binary_search(int s[],int begin,int end,int ans/* Write your code here */);

int main(void){
	int num,s[100],a;
	scanf("%d",&num);
	for(int i=0;i<num;i++){
        scanf("%d",&s[i]);
	}
	scanf("%d",&a);
	printf("%d",binary_search(s,0,num,a));
	return 0;
	/* Write your code here */
}

int binary_search(int s[],int begin,int end,int ans/* Write your code here */){
   for(int i=0;i<end;i++){
        for(int j=i;j<end;j++){
            if(s[j]<s[i]){
                int temp=s[j];
                s[j]=s[i];
                s[i]=temp;
            }
        }
   }

   int b=(end+begin)/2;
   if(end==begin&&s[b]!=ans){
    return -1;
   }
   if(s[b]>ans){
    return binary_search(s,begin,b,ans);
   }
   else if(s[b]<ans){
    return binary_search(s,b,end,ans);
   }
   else if(s[b]==ans){
    return b;
   }

   /* Write your code here */
}
