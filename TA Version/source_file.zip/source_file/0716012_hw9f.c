#include <stdio.h>
#include <stdlib.h>
void queens(int x,int n);
 int sum=0;
int n=0;
int *row,*dl,*dr;


int main(){
    int n,i;
    scanf("%d",&n);
    row=malloc(sizeof(int)*n);
    dl=malloc(sizeof(int)*(2*n-1));
    dr=malloc(sizeof(int)*(2*n-1));
    for(i=0;i<n;i++)
        row[i]=0;
    for(i=0;i<2*n-1;i++){
        dl[i]=0;
        dr[i]=0;
    }

    queens(n,n);
    free(row);
    free(dl);
    free(dr);
    printf("%d",sum);
}

void queens(int x,int n){
    int i;
    if(x==0)
        sum++;
    else{
            for(i=0;i<n;i++){
            int d1=x+i-1,d2=x-i+n-2;
            if(!row[i]&&!dl[d1]&&!dr[d2]){
            row[i]=1;dl[d1]=1;dr[d2]=1;
            queens(x-1,n);
            row[i]=0;dl[d1]=0;dr[d2]=0;
            }
    }
 }
}

