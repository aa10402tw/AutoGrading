#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <stdlib.h>

#define N 100
#define M 128

int num_chacter=0;
int compare(const void *p, const void *q);

void permute(char *array, int *count, char *result, int depth/* Write your code here */);

int main(){
    /* Write your code here */
    char array[N], result[N], copy_array[N];
    int count[N]={0};
    bool used[M-1]={false};
    int i, j=0, k;

    gets(array);

    qsort(array, strlen(array), sizeof(array[0]), compare);

    for(i=0; i<strlen(array); i++){            //get count_array and letter_array
        if(used[array[i]] == false){
            used[array[i]] = true;
            copy_array[j] = array[i];
            count[j]++;
            j++;
        }
        else if(used[array[i]] == true){
            for(k=0; k<j; k++){
                if(copy_array[k] == array[i])
                    count[k]++;
            }
        }
    }
    copy_array[j] = '\0';

    for(i=0; i<strlen(copy_array); i++){
        num_chacter += count[i];
    }

    /*for(i=0; i<j; i++){
        printf("%c %d\n", copy_array[i], count[i]);
    }*/

    permute(copy_array, count, result, 0);

    return 0;
}

void permute(char *array, int *count, char *result, int depth/* Write your code here */){
    /* Write your code here */
    int i;

    if(depth == num_chacter){
        for(int k=0; k<depth; k++)
            printf("%c", result[k]);
        printf("\n");
        return;
    }

    for(i=0; i<strlen(array); i++){
        if(count[i] == 0)
            continue;

        result[depth] = array[i];
        count[i]--;
        permute(array, count, result, depth+1);
        count[i]++;
    }
}

int compare(const void *p, const void *q)
{
    return *(const char *)p - *(const char *)q;
}
