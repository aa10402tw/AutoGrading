#include <stdio.h>
#include<string.h>
int f(int l){
	if(l==1){
		return 1;
	}
	return l*f(l-1);
}
int check(char c[], int start, int end){
	int i;
	for(i=start;i<end;i++){
		if(c[i]==c[end]){
			return 0;
		}
	}
	return 1;
}
void swap(char *a, char *b){
	char t;
	t=*a;
	*a=*b;
	*b=t;
}
void permute(char c[], int index, int l);

int g=0;
char a[100][100];

int main(){
	char c[100];
	gets(c);
	int l=strlen(c);
	int i, j;
	for(i=0;i<l-1;i++){
		for(j=i+1;j<l;j++){
			if(c[i]>c[j]){
				char t;
				t=c[i];
				c[i]=c[j];
				c[j]=t;
			}
		}
	}
	permute(c, 0, l);
	int t[100];
	for(i=0;i<g-1;i++){
		for(j=i+1;j<g;j++){
			if(strcmp(a[i], a[j])>0){
				strcpy(t, a[i]);
				strcpy(a[i], a[j]);
				strcpy(a[j], t);
			}
		}
	}
	for(i=0;i<g;i++){
		printf("%s\n", a[i]);
	}
}
void permute(char c[], int index, int l){
	if(index>=l){
		strcpy(a[g], c);
		g++;
		return;
	}
	int i;
	for(i=index;i<l;i++){
		if(check(c, index, i)){
			swap(&c[index], &c[i]);
			permute(c, index+1, l);
			swap(&c[index], &c[i]);
		}
	}
}
