#include <stdio.h>
#include <string.h>
#define space 300

void permute(int a,int b,char str[space]);

int main(){
    char str[space];
    scanf("%s",&str);
    int len=strlen(str);
    for(int j=0;j<len-1;j++){
            for(int r=0;r<len-1;r++){
                if(str[r]>str[r+1]){
                    char c=str[r];
                    str[r]=str[r+1];
                    str[r+1]=c;
                }
            }
        }
    permute(0,len,str);
    return 0;
}

void permute(int a,int b,char str[space]){
    int i;
    if(b==1){
        printf("%c\n",str[a]);
    }
    else if(b==2){
        for(i=0;i<a;i++){
            printf("%c",str[i]);
        }
        if(str[i]>str[i+1]){
            char c=str[i];
            str[i]=str[i+1];
            str[i+1]=c;
        }
        printf("%c%c\n",str[i],str[i+1]);
        for(i=0;i<a;i++){
            printf("%c",str[i]);
        }
        printf("%c%c\n",str[i+1],str[i]);
    }
    else{

        for(int i=0;i<b;i++){
            char c;
            c=str[a];
            str[a]=str[a+i];
            str[a+i]=c;
            permute(a+1,b-1,str);
            c=str[a];
            str[a]=str[a+i];
            str[a+i]=c;

        }

    }
}
