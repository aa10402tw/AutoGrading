#include <stdio.h>
static int count=0;
void hanoi(int n,char A,char B,char C);

int main() {
    int n;
    char A,B,C;
scanf("%d",&n);
hanoi(n,A,B,C);
printf("%d",count);
return 0;
}

void hanoi(int n,char A,char B,char C){

if(n==1){
    count++;
}else{
   hanoi(n-1,A,C,B);
   hanoi(1,A,B,C);
   hanoi(n-1,B,A,C);
}
}
