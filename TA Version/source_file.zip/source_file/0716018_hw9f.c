#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#define N 50
bool ok(int, int, int* , int* , int*,int);
void queens(int*, int*, int*, int,int);
int cos=0;
int main(void) {
    int column[N] = {0};
    int slope1[2 * N] = {0};
    int slope_1[2 * N] = {0};
    int len;
    scanf("%d",&len);
    queens(column, slope1, slope_1, 0, len);
    printf("%d",cos);
    return 0;
}
void queens(int* column, int* slope1, int* slope_1, int i,int L) {
    if(i == L) {
        cos++;
    }
    else {
        int j;
        for(j = 0; j < L; j++) {
            if(ok(i, j, column, slope1, slope_1,L)) {
                column[j] = slope1[i + j] = slope_1[i - j + L] = 1;
                queens(column, slope1, slope_1, i + 1, L);
                column[j] = slope1[i + j] = slope_1[i - j + L] = 0;
            }
        }
    }
}
bool ok(int i, int j, int* column, int* slope1, int* slope_1,int L) {
   return !(column[j] || slope1[i + j] || slope_1[i - j + L]);
}

