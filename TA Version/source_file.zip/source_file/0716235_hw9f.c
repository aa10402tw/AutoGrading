#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int sum=0;
int n,q[15]={0};
void queens(int r);

int main(){
    /* Write your code here */
    while(scanf("%d",&n)!=EOF)
    {
        for(int i=0;i<15;i++) q[i]=0;
        queens(n-1);
        printf("%d\n",sum);
        sum=0;
    }
    return 0;
}

int atk(int row,int column)
{
    for(int i=n-1;i>row;i--)
    {
        if(q[i]==column || abs(row-i)==abs(column-q[i]))
            return 1;
    }
    return 0;
}
void queens(int r){
    /* Write your code here */
    int pos=n-1;
    while(pos>=0)
    {
        if(atk(r,pos)==0)
        {
           q[r]=pos;
           if(r==0) sum++;
           else queens(r-1);
        }
        pos--;
    }
}
