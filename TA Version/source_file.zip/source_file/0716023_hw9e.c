#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void permute(char *string, int left, int len);
void swap(char *c1, char *c2);
void sort(char *string);
int compar(const void *c1, const void *c2);

int compar(const void *c1, const void *c2)
{
    return *(char *)c1 - *(char *)c2;
}

void swap(char *c1, char *c2)
{
    char tmp = *c1;
    *c1 = *c2;
    *c2 = tmp;
}

int main()
{
    char string[10];
    while (scanf("%s", string) != EOF)
    {
        permute(string, 0, strlen(string));
    }
}

void permute(char *string, int left, int len)
{
    if (left == len)
    {
        printf("%s\n", string);
        return;
    }

    qsort(string + left, len - left, sizeof(char), compar);

    int i;
    for (i = left; string[i]; i++)
    {
        char copy[10];
        strcpy(copy, string);
        swap(copy + left, copy + i);
        permute(copy, left + 1, len);
    }
}