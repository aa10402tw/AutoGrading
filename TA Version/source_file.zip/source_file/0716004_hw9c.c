//
//  main.c
//  0716004_hw9c.c
//
//  Created by 成文瑄 on 2018/11/20.
//  Copyright © 2018年 成文瑄. All rights reserved.
//
#include <stdio.h>

int binary_search( int R, int L, int a[], int goal);

int main(void){
    /* Write your code here */
    int n, i, j, goal, tmp;
    scanf("%d", &n);
    int a[n], L=1, R=n;
    for(i=0; i<n; i++)
        scanf("%d", &a[i]);
    scanf("%d", &goal);
    
    for(i=0; i<(n-1); i++){
        for(j=0; j<(n-i-1); j++){
            if(a[j]>a[j+1]){
                tmp=a[j];
                a[j]=a[j+1];
                a[j+1]=tmp;
            }
        }
    }
    printf("%d", binary_search( R, L, a, goal));
}

int binary_search( int R, int L, int a[], int goal){
    /* Write your code here */
    int M;
    if( R==L){
        if( a[R-1]==goal)
            return R-1;
        else
            return -1;
    }
    else if((R-(L-1))%2==1){
        M=(R+L)/2;
        if(a[M-1]==goal)
            return M-1;
        else if(a[M-1]>goal)
            return binary_search( M-1, L, a, goal);
        else
            return binary_search( R, M+1, a, goal);
    }
    else if((R-(L-1))%2==0){
        M=(R+L-1)/2;
        if(a[M-1]==goal)
            return M-1;
        else if(a[M-1]>goal)
            return binary_search( M-1, L, a, goal);
        else
            return binary_search( R, M+1, a, goal);
    }
}

