#include <stdio.h>
#include<stdbool.h>

void queens(int board[16][16],int col,int n,int *p);

bool is_safe(int board[16][16],int row,int col,int n);

int main(){
    /* Write your code here */
    int n;
    scanf("%d",&n);

    int count=0;

    int board[16][16]={0};


    queens(board,0,n,&count);

    printf("%d",count);

    return 0;
}

void queens(int board[16][16],int col,int n,int *p){
    /* Write your code here */
    if(col==n)
    {
        *p = *p + 1;
        return;
    }

    for(int row=0;row<n;row++)
    {
        if(is_safe(board,row,col,n)==true)
        {
            board[row][col]=1;

            queens(board,col+1,n,p);

            board[row][col]=0;
        }
    }
    return;
}

bool is_safe(int board[16][16],int row,int col,int n)
{
    int i,j;

    for(i=col-1;i>=0;i--)
    {
        if(board[row][i]==1)
            return false;
    }

    for(i=col-1,j=row-1 ; i>=0 && j>=0 ; i--,j--)
    {
        if(board[j][i]==1)
            return false;
    }

    for(i=col-1,j=row+1 ; j<n && i>=0 ;i--,j++)
    {
        if(board[j][i]==1)
            return false;
    }
    return true;
}
