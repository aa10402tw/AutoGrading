#include <stdio.h>

int GCD(int c, int d, int i);

int main(){

   int a, b, c, d;

   scanf("%d %d", &a, &b);
   if(a<b)
   {
       c = a;
       d = b;
   }
   else
   {
       c = b;
       d = a;
   }

   printf("%d", GCD(c, d, 1));

   return 0;
}

int GCD(int c, int d, int i){

    int j = i;

    for(i+=1;i<=c;i++)
    {
        if(c%i==0 && d%i==0)
        {
            if(i<c)
            {
                return GCD(c, d, i);
            }
            else
            {
                return i;
            }
        }
    }

    return j;

}
