#include <stdio.h>
#include <string.h>

void permute(char[], int, int);

void swap(char *x, char *y)
{
    char temp;
    temp = *x;
    *x = *y;
    *y = temp;
}
int main()
{
    char input[100];
    int len;
    scanf("%s", input);
    len = strlen(input);
    permute(input, 0, len - 1);
    return 0;
}

void permute(char *a, int from, int to)
{
    int i;
    if(from == to)
    {
        printf("%s\n", a);
    }
    else
    {
        for(i = from; i <= to; i++)
        {
            swap(a + from, a + i);
            permute(a, from + 1, to);
            swap(a + from, a + i);
        }
    }
}

