#include <stdio.h>

void hanoi(int);
int times=0;

int main(void)
{
    int x;
    scanf("%d",&x);

    hanoi(x);
    printf("%d",times);

    return 0;
}

void hanoi(int x)
{
    if(x==1)
    {
        times++;
        return;
    }
    hanoi(x-1);
    hanoi(1);
    hanoi(x-1);
}
