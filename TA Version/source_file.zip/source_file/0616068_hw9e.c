#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void permute(char str[], int len);
int compare(const void *x, const void *y);
void swap(char *x, char *y);

char main(){
    char str[11];
    gets(str);
    qsort(str, strlen(str), sizeof(char), compare);
    permute(str, strlen(str));
}

void permute(char str[], int len){
    int lpck = len - 1;
    while (lpck > 0 && str[lpck - 1] > str[lpck]) {
        lpck--;
    }
    if (lpck == 0) {
        printf("%s", str);
        return;
    }
    printf("%s\n", str);
    int rpck = len - 1;
    while (str[rpck] < str[lpck - 1]) {
        rpck--;
    }
    swap(str + lpck - 1, str + rpck);
    int index = len - 1;
    while (lpck < index) {
        swap(str + lpck++, str + index--);
    }
    permute(str, len);
}

int compare(const void *x, const void *y)
{
    return ( *(char *)x - *(char *)y );
}

void swap(char *x, char *y)
{
    char temp = *x;
    *x = *y;
    *y = temp;
}
