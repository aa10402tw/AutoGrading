#include <stdio.h>
int counter = 0 ;
void hanoi(int n,char,char,char);

int main() {
    /* Write your code here */
    int n;
    char A,B,C;
    scanf("%d",&n);
    hanoi(n,A,B,C);
    printf("%d",counter);
    return 0;
}

void hanoi(int n,char A,char B,char C){
    /* Write your code here */
    if(n == 1){
         counter++;
    }
    else{
        hanoi(n-1,A,C,B);
        counter++;
        hanoi(n-1,B,A,C);

    }

}
