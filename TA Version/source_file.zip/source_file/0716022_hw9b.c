#include <stdio.h>

int GCD(/* Write your code here */int,int);

int main(){
   /* Write your code here */
	int foo,bar;
	scanf("%d %d",&foo,&bar);
	printf("%d\n",GCD(foo,bar));
	return 0;
}

int GCD(/* Write your code here */int foo,int bar){
    /* Write your code here */
	if(!bar)return foo;
	return GCD(bar,foo%bar);
}
