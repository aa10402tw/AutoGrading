#include <stdio.h>

void queens(/* Write your code here */int n[15][15],int col,int x,int qs);

int end=0;

int safe(int n[15][15],int col,int row,int x){
    int i,j;
    for(i=col;i>=0;i--){
        if(n[i][row]==1)
            return 0;
    }

    for(i=col,j=row ; i>=0 && j>=0 ; i--,j--){
        if(n[i][j]==1)
            return 0;
    }

    for(i=col,j=row ; j<x && i>=0 ;i--,j++){
        if(n[i][j]==1)
            return 0;
    }
    return 1;
}

void queens(/* Write your code here */int n[15][15],int col,int x,int qs){
    /* Write your code here */
    if(qs==x){
        end++;
        return;
    }
    int j;
    for(j=0;j<x;j++){
        if(safe(n,col,j,x)){
            n[col][j]=1;
            queens(n,col+1,x,qs+1);
            n[col][j]=0;
        }
    }
}

int main(){
    /* Write your code here */
    int x;
    scanf("%d",&x);
    int n[15][15]={0};
    queens(n,0,x,0);
    printf("%d",end);
    return 0;
}
