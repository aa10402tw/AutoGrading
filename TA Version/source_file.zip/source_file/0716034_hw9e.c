#include <stdio.h>
#include<string.h>
#include<stdlib.h>

void permute(char str[],int len);

int cmp(const void *a,const void *b)
{
    return (*(char*)a-*(char*)b);
}

int findceil(char str[],char point,int after,int len)
{
    int l;

    int result=after;

    for(l=after+1;l<=len-1;l++)
    {
        if(str[l]>point && str[l]<str[after])
            result=l;
    }

    return result;
}

int main(){
    /* Write your code here */
    char str[15];
    scanf("%s",str);

    int len=strlen(str);

    qsort(str,len,sizeof(char),cmp);

    permute(str,len);

    return 0;

}

void permute(/* Write your code here */char str[],int len){
    /* Write your code here */

    int x=0;
    printf("%s\n",str);

    int i;
    for(i=len-2;i>=0;i--)
    {
        if(str[i]<str[i+1])
            break;
    }
    if(i==-1)
        x=1;

    int ceil=findceil(str,str[i],i+1,len);

    //����
    char temp=str[i];
    str[i]=str[ceil];
    str[ceil]=temp;

    qsort(str+i+1,len-i-1,sizeof(char),cmp);

    if(x==0){
        permute(str,len);
    }
}
