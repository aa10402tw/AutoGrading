#include <stdio.h>

int s = 0;

void hanoi(int n, char a, char b, char c);

int main() {
    /* Write your code here */
    int disk;
    scanf("%d", &disk);
    hanoi(disk, 'a', 'b', 'c');
    printf("%d", s);
    return 0;
}

void hanoi(int n, char a, char b, char c){
    /* Write your code here */
    if (n == 1)
        ++s;
    else{
        hanoi(n-1, a, c, b);
        ++s;
        hanoi(n-1, b, a, c);
    }
}
