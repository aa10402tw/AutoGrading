#include <stdio.h>
#include <stdlib.h>
int compare(const void *a, const void *b)
{
    return *(int*)a-*(int*)b;
}


int binary_search(int num[],int tar,int l,int r)
{
    if(l>r)
        return -1;
    else if(num[(int)((l+r)/2)]==tar)
        return (int)((l+r)/2);
    else if(num[(int)((l+r)/2)]>tar)
        return binary_search(num,tar,l,(int)((l+r)/2)-1);
    else if(num[(int)((l+r)/2)]<tar)
        return binary_search(num,tar,(int)((l+r)/2)+1,r);

}

int main(void){
    int n,t,i;
    scanf("%d",&n);
    int a[n];
    for(i=0;i<n;i++)
        scanf("%d",&a[i]);
    scanf("%d",&t);
    qsort(a,n,sizeof(int),compare);
    printf("%d",binary_search(a,t,0,n-1));

}
