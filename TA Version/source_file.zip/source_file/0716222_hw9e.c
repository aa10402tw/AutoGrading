#include <stdio.h>
#include <string.h>
void sort(char str[], int n);
void permute(char input[], int n, char output[], int used[]);

int main(){
    char input[10];
    scanf("%s",input);
    char output[strlen(input)+1];
    output[0]='\0';
    int used[strlen(input)];
    for(int i=0;i<strlen(input);i++)
        used[i]=0;
    sort(input,strlen(input));
    permute(input,strlen(input),output,used);
    return 0;
}
void sort(char str[], int n){
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            if(str[i]<str[j]){
                char temp=str[i];
                str[i]=str[j];
                str[j]=temp;
            }
        }
    }
}


void permute(char input[], int n, char output[], int used[]){
//#if DEBUG
//    printf("%s\n%s\n",input,output);
//    for(int i=0;i<n;i++)
//        printf("%d",used[i]);
//    printf("\n");
//#else
//    printf("output string length %d\n", strlen(output));
//#endif // DEBUG
    if(strlen(output)==n){
        printf("%s\n",output);
        return;
    }

    for(int i=0;i<n;i++){
        if(used[i]==0){
            output[strlen(output)+1]='\0';
            output[strlen(output)]=input[i];
            used[i]=1;
//            printf("add %c\n", input[i]);
            permute(input,n,output,used);
//            printf("delete %c\n", input[i]);
            used[i]=0;
            output[strlen(output)-1]='\0';

        }
    }

}
