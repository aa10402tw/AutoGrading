#include <stdio.h>
#include <stdlib.h>
int binary_search(int a[],int Lef,int Right,int fuck);

int cmp(const void *a,const void *b)
{
    return *(int*)a-*(int*)b;
}

int main(void){
	/* Write your code here */
	int kkk[100]={0},akb48;

	while(scanf("%d",&akb48)!=EOF)
    {
        for(int i=0;i<akb48;i++)
        {
            scanf("%d",&kkk[i]);
        }
        int target;
        scanf("%d",&target);
        qsort(kkk,akb48,sizeof(kkk[0]),cmp);
        binary_search(kkk,0,akb48,target);
    }

}

int binary_search(int a[],int Lef,int Right,int fuck){
   /* Write your code here */
   int M=(Lef+Right)/2;
   if(Lef<Right)
   {
       if(a[M]<fuck)
         binary_search(a,M+1,Right,fuck);
       else if(a[M]>fuck)
         binary_search(a,Lef,M,fuck);
       else
         printf("%d\n",M);
   }
   else
    printf("-1\n");
}
