#include <stdio.h>
#include <string.h>

void permute(char *str, long n);
void swap(char *a, char *b);
int fact(int a);
char save[370000][9];
int counter=0;

int main(){
    /* Write your code here */
    char ch[9];
    scanf("%s", ch);
    int n = (int)strlen(ch);
    permute(ch, n) ;
    
    for (int i = 0; i < fact(n); i++) {
        for (int j = 0; j < fact(n)-i-1; j++) {
            if (strcmp(save[j], save[j+1]) > 0) {
                char temp[9];
                strcpy(temp, save[j]);
                strcpy(save[j], save[j+1]);
                strcpy(save[j+1], temp);
            }
            
        }
    }
    for (int i = 0; i < fact(n); i++){
        printf("%s\n", save[i]);
    }
    return 0 ;
}

void permute(char *str, long n){
    /* Write your code here */
    long i;
    if(n==1) {
        strcpy(save[counter], str);
        counter+=1;
    }
    else {
        for(i=n-1; i>=0; i--) {
            swap(str+i, str+(n-1));
            permute(str, n-1);
            swap(str+i, str+(n-1));
        }
    }
}

void swap(char *a, char *b){
    char temp = *a;
    *a = *b;
    *b = temp;
}

int fact(int a){
    if(a==1)
        return a;
    else
        return a*fact(a-1);
}
