#include <stdio.h>
#include<string.h>
int use[11]= {0};
char finish[11];
int j=0;

void permute(char *ch, int len);
void swap(char *, char *);

int main()
{
    char cos[11];

    scanf("%s", cos);

    int len=strlen(cos);

    for(int i=0; i<len; i++)
    {
        for(int k=i+1; k<len; k++)
        {
            if(cos[i]>cos[k])
            {
                swap(&cos[i], &cos[k]);
            }
        }
    }

    permute(cos, len);

    return 0;

}

void permute(char *ch, int len)
{
    for (int i=0; i<len; i++)
    {
        for (; use[i]==1; i++);
        if (i!=len)
        {
            use[i]=1;
            finish[j++]=ch[i];
            if(j==len)
            {
                printf("%s\n", finish);
            }
            permute(ch, len);
            j--;
            use[i]=0;
        }
    }
}

void swap(char *a, char *b)
{
    char c=*a;
    *a=*b;
    *b=c;
}
