#include <stdio.h>

int SUM(int num/* Write your code here */);

int main(){
	int n;
	scanf("%d",&n);
	printf("%d",SUM(n));
	return 0;
	/* Write your code here */
}

int SUM(int num/* Write your code here */){
	if(num<0){
        return 0;
	}

	return num+SUM(num-1);

	/* Write your code here */
}
