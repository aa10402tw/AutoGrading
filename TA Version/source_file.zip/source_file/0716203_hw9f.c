#include <stdio.h>
#include<stdlib.h>

void queens(int i,int N,int *c,int *r,int *l,int *arr);
int times=0;
int main()
{
   int N;
    scanf("%d",&N);
    int c[N + 1]; //column
    int r[2 *N + 1]; // �k�W�ܥ��U
    int l[2 *N + 1]; // ���W�ܥk�U
    int arr[N + 1] ;
    int i;
    for (i = 1; i <= N; i++)
        c[i] = 1;
    for (i = 1; i <= 2 *N; i++)
        r[i] = l[i] = 1;
    queens(1,N,c,r,l,arr);
    printf("%d",times);
    return 0;
}

void queens(int i,int N,int *c,int *r,int *l,int *arr)
{
      int j;
    if (i > N)
        times++;
    else
    {
        for (j = 1; j <= N; j++)
        {
            if (c[j] == 1 && r[i + j] == 1 && l[i - j + N] == 1)
            {
                arr[i] = j;
                c[j] = r[i + j] = l[i - j + N] = 0;
                queens(i + 1,N,c,r,l,arr);
                c[j] = r[i + j] = l[i - j + N] = 1;
            }
        }
    }
}
