#include <stdio.h>

int SUM(int N);

int main(){
	int n;
	scanf("%d",&n);
	printf("%d",SUM(n));
	return 0;
}

int SUM(int N){
	if(N==1)
        return 1;
    if(N>=2)
        return N+SUM(N-1);
}
