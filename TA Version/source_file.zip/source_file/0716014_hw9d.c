#include <stdio.h>

void hanoi(int now,int ed,int ans);

int main() {
    int n;
    scanf("%d",&n);
    hanoi(1,n,1);
}

void hanoi(int now,int ed,int ans){
    if(now==ed)
        printf("%d\n",ans);
    else{
        hanoi(now+1,ed,ans*2+1);
    }
}
