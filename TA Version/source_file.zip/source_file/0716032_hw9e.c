#include<stdio.h>
#include<string.h>

char save[370000][9]={0};
int m=0;

void permute(int l,int r,char in[]);
void swap(char *a,char *b);

int main(){
    int r,fac=1;
    char in[9]={0};
    scanf("%s",in);
    r=strlen(in);

    permute(0,r,in);
    for(int i=1;i<=r;i++)
        fac*=i;

    for(int i=1;i<fac;i++){
        for(int j=0;j<fac-1;j++){
            char tem[9];
            if((strcmp(save[j],save[j+1]))>0){
            strcpy(tem,save[j]);
            strcpy(save[j],save[j+1]);
            strcpy(save[j+1],tem);
            }
        }
    }

    for(int i=0;i<fac;i++)printf("%s\n",save[i]);
    return 0;
}

void swap(char *a,char *b){
    char tem;
    tem=*a;
    *a=*b;
    *b=tem;
}

void permute(int l,int r,char in[]){
    if(l==r){
        strcpy(save[m++],in);
    }
    else {
        for(int i=l;i<r;i++){
        swap(&in[i],&in[l]);
        permute(l+1,r,in);
        swap(&in[i],&in[l]);
        }
    }
}
