#include <stdio.h>

int SUM(int);

int main(){
	int n;
	scanf("%d",&n);
	printf("%d",SUM(n));
}

int SUM(int N){
    int sum=0;
    if(N==1)
        return 1;
    return sum+=N+SUM(N-1);
	/* Write your code here */
}
