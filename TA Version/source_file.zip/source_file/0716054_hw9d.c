#include <stdio.h>

void hanoi(int n,int count);

int main() {
    int n;
    scanf("%d",&n);

    hanoi(n,1);
    return 0;
}

void hanoi(int n,int count){
    if (n==1) printf("%d",count);
    else{
        return hanoi(n-1,2*count+1);
    }
}
