#include <stdio.h>
int t=0,test=0;
void hanoi(int,char,char,char);

int main() {
    /* Write your code here */
    char a,b,c;
    int n;
    scanf("%d",&n);
    hanoi(n,'a','b','c');
    printf("%d",t);
    return 0;
} 

void hanoi(int n,char a,char b,char c){
    /* Write your code here */
    
	if(n==1){
		t++;
	}
	else{
		hanoi(n-1,a,c,b);
		hanoi(1,a,b,c);
		hanoi(n-1,b,a,c);
		
	}
}
