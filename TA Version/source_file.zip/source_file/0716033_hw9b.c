#include <stdio.h>

int GCD(/* Write your code here */int a,int b);

int main(){
   /* Write your code here */
   int a, b;
   scanf("%d %d",&a,&b);
   printf("%d", GCD(a,b));
   return 0;
}

int GCD(/* Write your code here */int a,int b){
    /* Write your code here */
    int c;
    if(a<b)
    {
        c=a;
        a=b;
        b=c;
    }
    if(b!=0)
        return GCD(b, a%b);
    else if(b==0)
        return a;
}
