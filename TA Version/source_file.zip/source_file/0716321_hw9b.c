#include <stdio.h>
#include <stdlib.h>
int GCD(int a, int b) {// 尼考曼徹斯法 我不會輾轉相除ＱＱ
    int c;
    while(a != b){
        if(a > b){
            a -= b;
            return GCD(a,b);
        }
        else if (a < b){
            b -= a;
            return GCD(a,b);
        }
    }
    return a;
}
int main(void ){
   int a,b;
   scanf("%d %d",&a,&b);
   printf("%d\n",GCD(a,b));
}

