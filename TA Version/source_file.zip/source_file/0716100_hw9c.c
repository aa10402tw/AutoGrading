#include <stdio.h>

int binary_search(int ans, int *quest, int L, int R/* Write your code here */);

int main(void){
	/* Write your code here */
	int quest[100], n, x;
	scanf("%d", &n);
	int L = 0, R = n - 1, ans, M;
	for(int i = 0;i < n;i++)
        scanf("%d", &quest[i]);
    for(int i = 0;i < n;i++)
    {
        for(int j = n - 1;j > i;j--)
        {
            if(quest[j - 1] > quest[j])
                {
                    x = quest[j - 1];
                    quest[j - 1] = quest[j];
                    quest[j] = x;
                }
        }
    }
    scanf("%d", &ans);
    printf("%d", binary_search(ans, quest, R, L));
    return 0;
}

int binary_search(int ans, int *quest, int R, int L/* Write your code here */){
   /* Write your code here */
    int M = (L + R) / 2;
    if(L > R)
        return -1;
    if(quest[M] == ans)
        return M;
    else if(quest[M] > ans)
    {
        R = M - 1;
        return binary_search(ans, quest, R, L);
    }
    else
    {
        L = M + 1;
        return binary_search(ans, quest, R, L);
    }
}
