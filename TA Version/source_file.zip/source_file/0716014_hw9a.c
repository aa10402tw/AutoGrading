#include <stdio.h>

int SUM(int now);

int main(){
	int n;
	scanf("%d",&n);
	printf("%d\n",SUM(n));
}

int SUM(int now){
	if(now==1)
        return 1;
	return now+SUM(now-1);
}
