#include <stdio.h>
#include <string.h>

void permute(char input[],int use[],int level,int len,char result[]);

int main(){
    char input[10],result[10];
    scanf("%s",&input);
    int len=strlen(input);
    for(int i=0;i<len;i++){
        for(int j=1;j<len;j++){
            if(input[j-1]>input[j]){
                char temp=input[j];
                input[j]=input[j-1];
                input[j-1]=temp;}}}
    int use[strlen(input)];
    for(int i=0;i<len;i++) use[i]=1;
    permute(input,use,0,len,result);
    return 0;
}

void permute(char input[],int use[],int level,int len,char result[]){
    if(level==len){
        result[len]='\0';
        printf("%s\n",result);
        return;}
    for(int i=0;i<len;i++){
        if(use[i]==0) continue;
        result[level]=input[i];
        use[i]--;
        permute(input,use,level+1,len,result);
        use[i]++;
    }
}
