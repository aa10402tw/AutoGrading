#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int n;
char a[100];
int v[100]= {0};
char t[100]="";
int top = 0;

int cmp(const void *a, const void *b)
{
    return *(char *)a - *(char *)b;
}

void permute(int);

int main()
{

    scanf("%s", a);

    n = strlen(a);

    t[0] = '\0';

    qsort(a, n, sizeof(char), cmp);


    permute(0);

    return 0;
}

void permute(int f)
{
    int i, j;

    if(f==n)
    {
        puts(t);
        /*printf("%c %d\n",a[0],top);*/
        return;

    }

    for (i = 0; i < n; i++)
    {
        if(v[i])
            continue;

        

        v[i] = 1;
        t[top++] = a[i];
        t[top] = '\0';


        permute(f+1);

        v[i] = 0;
        t[--top] = '\0';
    }
}