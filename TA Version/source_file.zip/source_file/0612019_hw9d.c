#include <stdio.h>

int count = 0;
void hanoi(int n);

int main() {
    int n;
    scanf( "%d" , &n);
    hanoi(n);
    printf( "%d" , count );
    return 0;
}

void hanoi(int n){
    if( n == 1 ) count++;
    else{
        hanoi(n-1);
        count++;
        hanoi(n-1);
    }
}
