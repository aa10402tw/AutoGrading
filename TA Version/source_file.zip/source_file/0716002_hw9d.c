#include <stdio.h>

void hanoi(int n ,int *t );

int main()
{
    int n,t=0;
    scanf("%d",&n);
    hanoi(n,&t);
    printf("%d",t);
    return 0;
}

void hanoi(int n,int *t)
{

    if(n==1){(*t)++;}
    else
    {
        hanoi(n-1,t);
        hanoi(1,t);
        hanoi(n-1,t);
    }
}
