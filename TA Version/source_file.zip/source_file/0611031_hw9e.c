#include <stdio.h>
#include <string.h>
#include <string.h>

int t=0;
int st=1;
char array[500][500];
int stair(int s);

void permute(char *a,int len,int *count,int l,char *b);
void printarray(char *b,int len);

int main(){
    char a[100];
    int l;
    int i;
    gets(a);
    l=strlen(a);
    int count[l];
    for(i=0;i<l;i++){
        count[i]=1;
    }
    char b[l];
    stair(l);
    permute(a,l,count,0,b);
}

void permute(char *a,int len,int *count,int l,char *b){
    char temp;
    int j,k;
    if(l==len){
        printarray(b,len);
    }
    else{
        for(j=0;j<len;j++){
            if(count[j]==0){
                continue;
            }
            else{
                count[j]=0;
                b[l]=a[j];
                l++;
                permute(a,len,count,l,b);
                count[j]++;
                l--;
            }
        }
    }
}
void printarray(char *b,int len){
    int i,j;
    char temp[len+1];
    for(i=0;i<len;i++){
        array[t][i]=b[i];
    }
    t++;
    if(t==st){
        for(i=0;i<t;i++){
            for(j=i+1;j<t;j++){
                if(strcmp(array[i],array[j])>0){
                    strcpy(temp,array[i]);
                    strcpy(array[i],array[j]);
                    strcpy(array[j],temp);
                }
            }
        }
        for(i=0;i<t;i++){
            printf("%s",array[i]);
            printf("\n");
        }
    }
}
int stair(int s){
    st*=s;
    if(s>1){
        return stair(s-1);
    }
}
