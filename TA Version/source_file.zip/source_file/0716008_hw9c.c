#include <stdio.h>

int binary_search(int* a,int num,int L,int R);

int main(void)
{
    int n,m,p,min;
    int a[120]={};
    scanf("%d",&n);
    for (int i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    for (int i=0;i<n;i++)
    {
        min=i;
        for (int j=i+1;j<n;j++)
        {
            if (a[min]>a[j]){min=j;}
        }
        if(i!=min)
        {
            int temp=a[i];
            a[i]=a[min];
            a[min]=temp;
        }
    }
    scanf("%d",&m);
    printf("%d",binary_search(a,m,0,n));
}

int binary_search(int* a,int num,int L,int R)
{
    if(R>=L)
    {
        if(a[(R+L)/2]==num){return (R+L)/2;}
        else if(a[(R+L)/2]>num){return binary_search(a,num,L,((R+L)/2)-1);}
        else {return binary_search(a,num,((R+L)/2)+1,R);}
        
    }
    else return -1;
    
    
}
/*#include <stdio.h>
 
 int binary_search(int* a,int num,int times,int n,int m);
 
 int main(void)
 {
 int n,m,j;
 int a[120]={};
 scanf("%d",&n);
 int k=n;
 for (j=0;k>0;j++)
 {
 k/=2;
 }
 //printf("%d~",j);
 for (int i=0;i<n;i++)
 {
 scanf("%d",&a[i]);
 }
 scanf("%d",&m);
 printf("%d",binary_search(a,m,j,n/2,n));
 }
 
 int binary_search(int* a,int num,int times,int n,int m)
 {
 //int i=num/2;
 //if (num==a[i]){return i;}
 for (int i=0;i<times;i++)
 {
 if (a[n]==num){return n;}
 else if(a[n]<num){return binary_search(a,num,times-i,n+(m-n)/2,m);}
 else{return binary_search(a,num,times-i,n/2,m);}
 }
 return -1;
 }*/
/*#include <stdio.h>
 #include <math.h>
 
 void hanoi(int a);
 
 int main()
 {
 int n;
 scanf("%d",&n);
 hanoi(n);
 return 0;
 }
 
 void hanoi(int a)
 {
 printf("%g",pow(2,a)-1);
 }*/


/*#include <stdio.h>
 #include <math.h>
 
 void hanoi(int a);
 
 int main()
 {
 int n;
 scanf("%d",&n);
 hanoi(n);
 return 0;
 }
 
 void hanoi(int a)
 {
 int t;
 if (a==1){t=1;}
 else
 return hanoi(a-1);
 printf("%d",t);
 }*/

