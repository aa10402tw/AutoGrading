#include<stdio.h>
#include<string.h>

int state[10] = { 0 };
char out[10];
int j = 0;

void permute(char *in, int len);

int main()
{
    char in[10], temp;

    scanf("%s", in);

    int len = strlen(in), i, k;

    for(i=0; i<len-1; i++)
    {
        for(k=0; k<len-1; k++)
            if(in[k]>in[k+1])
            {
                temp = in[k];
                in[k] = in[k+1];
                in[k+1] = temp;
            }

    }

    permute(in, len);

    return 0;
}

void permute(char *in, int len)
{
    for (int i = 0; i < len; i++)
    {
        for (; state[i] == 1; i++);

        if (i != len)
        {
            state[i] = 1;
            out[j++] = in[i];

            if (j == len)
            {
                printf("%s\n",out);
            }

            permute(in, len);

            j--;
            state[i] = 0;
        }
    }
}
