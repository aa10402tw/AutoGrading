#include <stdio.h>

void hanoi(int*i,int n);

int main() {
    int n,i=0;
    scanf("%d",&n);
    hanoi(&i,n);
    printf("%d",i);
    return 0;
}

void hanoi(int*i,int n){
    if(n==1)//�פ�j
        *i+=1;
    else
    {
        hanoi(i,n-1);//�_�l->�Ȧs
        *i+=1;
        hanoi(i,n-1);//�Ȧs->�ت�
    }
}
