#include <stdio.h>

int GCD(int a,int b);

int main()
{
    int m,n;
    scanf("%d%d",&m,&n);
    printf("%d",GCD(m,n));
    return 0;
}

int GCD(int a,int b)
{
    //輾轉相除法
    if(b==0){return a;}
    return GCD(b,a%b);
}

/*#include <stdio.h>

int binary_search();

int main(void){
   
}

int binary_search(/)
{
    
}*/
