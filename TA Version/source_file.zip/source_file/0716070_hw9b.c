#include <stdio.h>

int GCD(int u,int v);

int main(){
    int a,b,tt;
    scanf("%d %d",&a,&b);
    if(b>a){
        tt=a;
        a=b;
        b=tt;
    }
    printf("%d",GCD(a,b));
    return 0;
}

int GCD(int u,int v){
    int qq;
    while(v!=0){
        qq=u%v;
        u=v;
        v=qq;
    }
    return u;
}
