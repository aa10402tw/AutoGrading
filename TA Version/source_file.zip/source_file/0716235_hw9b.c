#include <stdio.h>

int GCD(int ba,int nana);

int main(){
   /* Write your code here */
   int n,k;
   while(scanf("%d %d",&n,&k)!=EOF)
   {
       printf("%d\n",GCD(n,k));
   }
}

int GCD(int ba,int nana){
    /* Write your code here */
    if(nana==0)
        return ba;
    else
        return GCD(nana,ba%nana);
}
