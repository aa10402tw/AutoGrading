#include <stdio.h>

void hanoi(int n,char A,char B,char C);

int main() {
    int n,i,s=2;
    scanf("%d",&n);
    (n,'A','B','C');
    for(i=1;i<n;i++) s*=2;
    printf("%d",s-1);
    return 0;
}

void hanoi(int n,char A,char B,char C){
    if(n==1) (1,A,B,C);
    else
    {

        (n-1,A,C,B);
        (1,A,B,C);
        (n-1,B,A,C);
    }
}
