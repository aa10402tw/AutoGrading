#include <stdio.h>

int binary_search(/* Write your code here */);

int main(void)
{
    int a[100],b=0,c,t,amount,search;
    scanf("%d",&amount);
    for(int i=0; i<amount; i++)
    {
        scanf("%d",&a[i]);
    }
    scanf("%d",&search);
    for(int i=0,j=0,k; i<amount-1; i++)
    {
        k=i;
        for(j=k+1;j<=amount-1;j++)
        {
            if(a[k]>a[j])
            {
                k=j;
            }
        }
        t=a[i];
        a[i]=a[k];
        a[k]=t;
    }
    c=binary_search(a,b,amount,search);
    printf("%d",c);
    return 0;
    /* Write your code here */
}

int binary_search(int *arr, int start, int end, int search/* Write your code here */)
{
    if (start > end)
        return -1;

    int mid=start+(end-start)/2;
    if (arr[mid]>search)
        return binary_search(arr,start,mid - 1,search);
    else if (arr[mid]<search)
        return binary_search(arr,mid+1,end,search);
    else
        return mid;

    /* Write your code here */
}

