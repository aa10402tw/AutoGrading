#include <stdio.h>
void sort(int n,int array[n]);
int binary_search(int L,int R,int *array,int target);
int main(void)
{
    int n,target;
    scanf("%d",&n);
    int array[n];
    for(int i=0;i<n;i++)
        scanf("%d",&array[i]);
    scanf("%d",&target);
    sort(n,array);
    printf("%d",binary_search(0,n-1,array,target));
}
void sort(int n,int array[n])
{
    for(int i=0;i<n;i++)
        for(int j=0;j<n-1;j++)
            if(array[j]>array[j+1])
            {
                int temp=array[j];
                array[j]=array[j+1];
                array[j+1]=temp;
            }
}

int binary_search(int L,int R,int *array,int target)
{
    int M=(L+R)/2;
    if(L>M)
        return -1;
    else
    {
        if(target==array[M])
            return M;
        if(target>array[M])
            return binary_search(M+1,R,array,target);
        else
            return binary_search(L,M-1,array,target);
    }
}

