#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int cmp(const void *a,const void *b)
{
    return *(char*)a-*(char*)b;
}

void swap(char *a,char *b)
{
    char x=*a;
    char y=*b;
    *a=y;
    *b=x;
}

void push(char c[],int k,int i)
{
    if(i==k)
        swap(&c[i],&c[k]);
    else
    for(int j=i;j>k;j--)
    {
        swap(&c[j],&c[j-1]);
    }
}

void pull(char c[],int k,int i)
{
    for(int j=k;j<i;j++)
    {
        if(i==k)
            continue;
        else
        swap(&c[j],&c[j+1]);
    }
}


void permute(char rarara[],int n,int k);

int main(){
    /* Write your code here */
    char c[17];
    while(scanf("%s",c)!=EOF)
    {
        qsort(c,strlen(c),sizeof(c[0]),cmp);
        permute(c,strlen(c),0);
    }

}

void permute(char c[],int n,int k){
    /* Write your code here */
    if(n==2)
    {
       printf("%s\n",c);
       swap(&c[strlen(c)-1],&c[strlen(c)]-2);
       printf("%s\n",c);
       swap(&c[strlen(c)-1],&c[strlen(c)]-2);
    }
    else
    {
        for(int i=k;i<strlen(c);i++)
        {
            push(c,k,i);
            permute(c,n-1,k+1);
            pull(c,k,i);
        }
    }






}
