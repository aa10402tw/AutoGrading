#include <stdio.h>

int binary_search(int u,int d,int goal,int store[u]);
void insertion_sort(int k,int a[k]);

int main(void)
{
   int n;
   int input[100]={};
   scanf("%d",&n);
   for(int i=0;i<n;i++)
      scanf("%d",&input[i]);
   insertion_sort(n,input);
   int search;
   scanf("%d",&search);
   printf("%d",binary_search(n-1,0,search,input));
   return 0;
}

int binary_search(int u,int d,int goal,int store[u])
{
   int k=(int)((u+d)/2);
   if(d>u)
      return -1;
   else if(store[k]==goal)
      return k;
   else if(store[k]>goal)
      return binary_search(k-1,d,goal,store);
   else//store[k]<goal
      return binary_search(u,k+1,goal,store);
}

void insertion_sort(int k,int a[k])
{
   for(int i=1;i<k;i++)
   {
      int j=i;
      int tempt=a[i];
      while(a[j-1]>tempt && j>0)
      {
         a[j]=a[j-1];
         j--;
      }
      a[j]=tempt;
   }
}
