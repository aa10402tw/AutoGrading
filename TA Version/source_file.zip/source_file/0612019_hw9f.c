#include <stdio.h>
#include <stdbool.h>

int sols, chess[15][15];

bool check ();
void queens ();

int main () {
  int N; scanf("%d", &N);
  queens(N, 0);
  printf("%d\n", sols);
  return 0;
}

bool check (int N, int row, int col) {
  for ( int i = 0; i < col; ++i )
    if ( chess[row][i] )
      return false;
  for ( int i = row, j = col; i >= 0 && j >= 0; --i, --j )
    if ( chess[i][j] )
      return false;
  for ( int i = row, j = col; j >= 0 && i < N; ++i, --j )
    if ( chess[i][j] )
      return false;

  return true;
}

void queens ( int N, int col ) {
  if ( col == N ) {
    sols++;
  }
  for ( int i = 0; i < N; ++i ) {
    if ( check(N, i, col) ) {
      chess[i][col] = 1;
      queens(N, col + 1);
      chess[i][col] = 0;
    }
  }
}
