#include <stdio.h>

int binary_search(int n[],int h,int d,int e);
int a,c,n[100];
int i,j,d=0;
int f;
int main(void){
	/* Write your code here */
	scanf("%d",&a);
	for(i=0;i<a;i++){
        scanf("%d",&n[i]);
	}
	for(i=0;i<a;i++){
        for(j=i;j<a;j++){
        if(n[i]>n[j]){
            c=n[j];
            n[j]=n[i];
            n[i]=c;
        }
	}
	}
	int h;
	scanf("%d",&h);
	binary_search(n,h,0,a);
	printf("%d",f);
	return 0;
}
int binary_search(int n[],int h,int d,int e){
   /* Write your code here */
   f=(d+e)/2;
   if(h>n[f]){
        d=f+1;
   }
   if(h<n[f]){
        e=f-1;
   }
   if(e==f && d==f && h!=n[f]){
    return -1;
   }
   if(h==n[f]){
    return f;
   }
   else{
    binary_search(n,h,d,e);
   }
}
