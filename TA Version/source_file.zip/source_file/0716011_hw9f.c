#include <stdio.h>

void queens(/* Write your code here */);
int num=0;
int main(){
    int n;
    scanf("%d",&n);
    int a[n+1][n+1];
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
            a[i][j]=0;
    }
    queens(n,a,0,n-1);
    printf("%d",num);

    /* Write your code here */
}

void queens(int n,int a[n+1][n+1],int b,int c/* Write your code here */){
    if(b==c)
    {
        for(int i=0;i<=c;i++)
        {
            if(a[b][i]==0)
            {
                num++;
                break;
            }
        }

    }
    else
    {/* Write your code here */
        for(int i=0;i<=c;i++)
        {
            if(a[b][i]==0)
            {
                for(int j=0;j<=c;j++)
                {
                    a[b][j]++;
                }
                for(int j=0;j<=c;j++)
                {
                    a[j][i]++;
                }
                int p=b,q=i;
                while(p>=0&&q<=c)//�k�W
                {
                    a[p][q]++;
                    p--,q++;
                }
                 p=b,q=i;
                while(p<=c&&q<=c)//�k�U
                {
                    a[p][q]++;
                    p++,q++;
                }
                 p=b,q=i;
                while(p>=0&&q>=0)//���W
                {
                    a[p][q]++;
                    p--,q--;
                }
                 p=b,q=i;
                while(p<=c&&q>=0)//���U
                {
                    a[p][q]++;
                    p++,q--;
                }
                queens(n,a,b+1,c);
                for(int j=0;j<=c;j++)
                {
                    a[b][j]--;
                }
                for(int j=0;j<=c;j++)
                {
                    a[j][i]--;
                }
                 p=b,q=i;
                while(p>=0&&q<=c)//�k�W
                {
                    a[p][q]--;
                    p--,q++;
                }
                 p=b,q=i;
                while(p<=c&&q<=c)//�k�U
                {
                    a[p][q]--;
                    p++,q++;
                }
                 p=b,q=i;
                while(p>=0&&q>=0)//���W
                {
                    a[p][q]--;
                    p--,q--;
                }
                 p=b,q=i;
                while(p<=c&&q>=0)//���U
                {
                    a[p][q]--;
                    p++,q--;
                }
            }
        }
    }
}
