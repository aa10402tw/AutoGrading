#include <stdio.h>

void queens(/* Write your code here */);

int main(){ 
    /* Write your code here */
    int n;
    scanf("%d",&n);
    queens(n);
    
}

void queens(/* Write your code here */){
    /* Write your code here */
}
