#include <stdio.h>

void queens(/* Write your code here */int m,int n,int s[m][n],int *p,int a);

int main(){
    /* Write your code here */
    int i,j,n,p=0,s[30][30];
    for(i=0;i<30;i++)
    {
        for(j=0;j<30;j++)
        {
            s[i][j]=1;
        }
    }
    scanf("%d",&n);
    queens(n,n,s,&p,0);



    printf("%d",p);

}

void queens(/* Write your code here */int m,int n,int s[m][n],int *p,int a){
    /* Write your code here */
    int j,k;

    for(j=0;j<n;j++)
    {
        if(s[a][j]<=0)
            continue;


        if(a==n-1)
        {
           *p=*p+1;
           return;
        }

        for(k=a;k<n;k++)
            {s[k][j]--;}

        for(k=0;k<n-a;k++)
        {
            if(j+k>=n)
                break;
            s[a+k][j+k]--;
        }
        for(k=0;k<n-a;k++)
        {
            if(j-k<0)
                break;
            s[a+k][j-k]--;
        }

        queens(n,n,s,p,a+1);

        for(k=a;k<n;k++)
            {s[k][j]++;}

        for(k=0;k<n-a;k++)
        {
            if(j+k>=n)
                break;
            s[a+k][j+k]++;
        }
        for(k=0;k<n-a;k++)
        {
            if(j-k<0)
                break;
            s[a+k][j-k]++;
        }
    }
}
