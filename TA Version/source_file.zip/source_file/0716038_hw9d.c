#include <stdio.h>

int i=0;
void hanoi(/* Write your code here */);

int main() {
    int num,c=1;
    scanf("%d",&num);
    hanoi(num,c);
    return 0;
    /* Write your code here */
}

void hanoi(int a,int b/* Write your code here */)
{
    if(a>0)
    {
        b=b*2;
        hanoi(--a,b);
    }
    else
    {
        printf("%d",b-1);
    }/* Write your code here */
}
