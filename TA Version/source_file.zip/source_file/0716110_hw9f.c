#include <stdio.h>
#include <math.h>
#include <stdlib.h>


int array[50]={0};
void queens(int row,int n);
int result = 0;
int queenscheck(int row,int col)
{

 for(int i=1;i<row;i++)
 {
  if(array[i] == col){
   return 0;}
  else{
   if(abs(array[i]-col) == abs(row - i)){
    return 0;}}
 }

 return 1;
}
int main(){
    /* Write your code here */
    int n;
    scanf("%d",&n);
    queens(1,n);
    printf("%d",result);
    return 0;
}

void queens(int row,int n){

   for(int col = 1;col<=n;col++){
        if(queenscheck(row,col)){
            array[row] = col;

            if(row==n){
                result++;
            }
            else{queens(row +1 ,n);}
        }
   }

}

