#include <stdio.h>

int SUM(int num);

int main()
{
    int num;

    scanf("%d", &num);

    printf("%d",SUM(num));
    return 0;

}

int SUM(int num)
{
    if(num > 0)

        return num + SUM(num-1);
    else
        return num;
}
