#include <stdio.h>

int GCD(/* Write your code here */);

int main(){
    /* Write your code here */
    int a, b;
   scanf("%d %d", &a, &b);
   printf("%d", GCD(a,b));
   return 0;

}

int GCD(/* Write your code here */int m, int n){
    /* Write your code here */
    int r;
    if(n==0)
        return m;
    else
        return GCD(n,m%n);
}
