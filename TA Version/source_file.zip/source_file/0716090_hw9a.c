#include <stdio.h>

int SUM(int,int,int/* Write your code here */);

int main(){
	/* Write your code here */
	int N,i,sum;
	scanf("%d",&N);
	printf("%d",SUM(N,0,0));
	return 0;
}

int SUM(int N,int i,int sum/* Write your code here */){
	/* Write your code here */
	i++;
	if(i<=N){
        sum+=i;
        return SUM(N,i,sum);
	}
	else return sum;

}
