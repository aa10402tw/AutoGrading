#include <stdio.h>

void hanoi(int);
int time=0;
int main() {
    int cos;
    scanf("%d",&cos);
    hanoi(cos);
    printf("%d",time);
    return 0;
}

void hanoi(int n){
    if(n==1){
        time++;
    }
    else{
        hanoi(1);
        hanoi(n-1);
        hanoi(n-1);
    }
}
