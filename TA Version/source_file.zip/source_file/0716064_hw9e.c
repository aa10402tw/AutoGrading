#include<stdio.h>
#include<string.h>
char a[362880][9];

void swap(char *a,char *b);
void selection_sort(int len,char *input);
void permutation(char *array,int l,int r);

int counter=0;
int fac(int n);
int main()
{
    char input[9];
    int i,j,min;
    scanf("%s",input);
    int len=(int)strlen(input);
   selection_sort(len,input);
    permutation(input,0,len-1);
    for( i=0; i<fac(len); i++)
    {
        min=i;
        for( j=i+1; j<(fac(len)); j++)
            if(strcmp(a[min],a[j])>0)
                min=j;
        if(min!=i)
        {
            char temp[9];
            strcpy(temp,a[i]);
            strcpy(a[i],a[min]);
            strcpy(a[min],temp);
        }
    }
    for(int i=0; i<fac(len); i++)
        printf("%s\n",a[i]);

    return 0;

}
void swap(char *a,char *b)
{
    char temp=*a;
    *a=*b;
    *b=temp;
}
void selection_sort(int len,char *input)
{
    int min;
    for(int i=0; i<len; i++)
    {
        min=i;
        for(int j=i+1; j<len; j++)
            if(input[min]>input[j])
                min=j;
        if(min!=i)
            swap(input+i,input+min);
    }
}
void permutation(char *array,int l,int r)
{
    if(l==r)
    {
// printf("%s\n",array);
        strcpy(a[counter],array);
        counter+=1;
    }
    else
    {
        for(int i=l; i<=r; i++)
        {
            swap((array+l),(array+i));
            permutation(array,l+1,r);
            swap((array+l),(array+i));
        }
    }
}
int fac(int n)
{
    if(n==1)
        return 1;
    else
        return n*fac(n-1);
}
