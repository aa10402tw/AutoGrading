#include <stdio.h>
#include <stdlib.h>
#define NMAX 100

static int num;

int compare_incrementing(const void *a,const void *b){
    return (*(int*)a-*(int*)b);
}

int binary_search(/* Write your code here */int n[],int lookfor,int f,int l);

int main(void){
	/* Write your code here */
	int n[NMAX],lookfor;
	scanf("%d",&num);
	for(int i=0;i<num;i++) scanf("%d",&n[i]);
	scanf("%d",&lookfor);
	qsort(n,num,sizeof(int),compare_incrementing);
	int p=binary_search(n,lookfor,0,num-1);
	printf("%d",p);
	return 0;
}

int binary_search(/* Write your code here */int n[],int lookfor,int f,int l){
    /* Write your code here */
    int m=(int)((f+l)/2);
    if(n[m]!=lookfor && n[m+1]!=lookfor && f==l-1) return -1;
    else if(n[m]>lookfor) binary_search(n,lookfor,f,m);
    else if(n[m]<lookfor) {
        if(l==m+1) return l;
        binary_search(n,lookfor,m,l);
    }
    else if(n[m]==lookfor) return m;
}
