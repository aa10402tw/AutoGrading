#include <stdio.h>

int step;

void hanoi(int n,int A[],int B[],int C[]);

int main() {
    int n;
    while(scanf("%d",&n)==1){
    int A[n],B[n],C[n];
    step=0;
    for(int i=0;i<n;i++){
        A[i]=1;
        B[i]=0;
        C[i]=0;
    }
    hanoi(n,A,B,C);
    printf("%d\n",step);
    }
}

void hanoi(int n,int A[],int B[],int C[]){
    if(n==1){
        for(int i=n-1;i<=0;i--){
            if(A[i]==1){
                A[i]=0;
                break;
            }
        }
        for(int i=0;i<n;i++){
            if(C[i]==0){
                C[i]=1;
                break;
            }
        }
        step++;
    }
    else{
        hanoi(n-1,A,C,B);
        hanoi(1,A,B,C);
        hanoi(n-1,B,A,C);
    }
}
