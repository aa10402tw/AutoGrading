#include <stdio.h>
#include <string.h>
int num=0;
char mychar[326880][100];

void permute(char seq[],int i,int n);

int main(){
    char seq[100];

    gets(seq);
    int n=strlen(seq);

    char temp;
    //for(int i=0;i<n;i++){
    //    for(int j=0;j<n-1;j++){
    //        if((int)seq[j]>(int)seq[j+1]){
    //            temp=seq[j];
    //            seq[j]=seq[j+1];
    //            seq[j+1]=temp;
    //        }
    //    }
    // }
    permute(seq,0,n);



    char temp2[100];
    //for(int i=0;i<100;i++){
    //    temp2[i]='\0';
    //}

    for(int i=0;i<num;i++){
        for(int j=0;j<num-1;j++){
            if(strcmp(mychar[j],mychar[j+1])==1){

                strcpy(temp2,mychar[j]);
                //memset(mychar[j],0,sizeof(mychar[j]));
                strcpy(mychar[j],mychar[j+1]);
                //memset(mychar[j+1],0,sizeof(mychar[j+1]));
                strcpy(mychar[j+1],temp2);
            }
        }
    }
    for(int i=0;i<326880;i++){
        if(strlen(mychar[i])==0){
            break;
        }
        else{
            printf("%s\n",mychar[i]);
        }
    }

}

void permute(char seq[],int i,int n){

    void swap(char*a,char*b){
        char temp;
        temp=*a;
        *a=*b;
        *b=temp;
    }
    if(i==n-1){

        for(int j=0;j<n;j++){
            mychar[num][j]=seq[j];
        }
        num++;

    }
    else{

        for(int j=i;j<n;j++){
            swap(&seq[i],&seq[j]);
            permute(seq,i+1,n);
            swap(&seq[i],&seq[j]);
        }
    }
}
