#include <stdio.h>

void hanoi(int);
int times=0;

int main() {
    int disk;
    scanf("%d",&disk);

    hanoi(disk);
    printf("%d",times);
} 

void hanoi(int a){
    
    if(a == 1)
        times++;
    else
    {
        hanoi(a-1);
        hanoi(1);
        hanoi(a-1);
    } 
        
    return;

}