#include<stdio.h>
#include<stdbool.h>
//#include<math.h>
int sol=0;
int size,chessboard[14];
void queens(int);
bool check(int);
int main(){ 
    /* Write your code here */
	scanf("%d",&size);
    queens(0);
    printf("%d",sol);
    return 0;
}
void queens(int n){
    /* Write your code here */
    int i;
	if(n>1&&check(n)==false){
    	return;
	}
	if(n==size){
    	sol++;
    	return;
	}
	for(i=0;i<size;i++){
		chessboard[n]=i;
		queens(n+1);
	}
}
bool check(int n){
	int j;
	n--;
	for(j=0;j<n;j++){
		if(chessboard[j]==chessboard[n]||((chessboard[j]-chessboard[n])==n-j||(chessboard[j]-chessboard[n])==j-n)){
			return false;
		}
	}
	return true;
}
