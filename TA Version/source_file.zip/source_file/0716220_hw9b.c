#include <stdio.h>

int GCD(int a,int b/* Write your code here */);//�̤j���]��

int main(){
 int m ,n ;
 scanf("%d %d",&m,&n);
 printf("%d",GCD(m,n));
 return 0;  /* Write your code here */
}

int GCD(int a,int b/* Write your code here */){
  int tmp ;
  if(a%b==0){return b;}
return GCD(b,a%b); /* Write your code here */
}
