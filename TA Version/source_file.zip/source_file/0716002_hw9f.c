#include <stdio.h>
#define	MAXSIZE	14
#define	TRUE	1
#define	FALSE	0

int board[MAXSIZE];
int r_used[MAXSIZE * 2 - 1];
int l_used[MAXSIZE * 2 - 1];
int size;
int count;
void queen( int n )
int main()
{
    int i;
    scanf("%d",&size);
    for( i = 0; i < size; i++ )
    {
        board[i] = i;
    }
    for( i = 0; i < size * 2 - 1; i++ )
    {
        r_used[i] = l_used[i] = FALSE;
    }
    count = 0;
    queen( 0 );
    printf("%d", count);

    return 0;
}
void queen( int n )
{
    int i;
    if( n == size )
    {
        count++;
    }
    else
    {
        for( i = n; i < size; i++ )
        {
            int m = board[i];
            if( r_used[m + n] || l_used[m - n + size - 1] )
                continue;
            r_used[m + n] = l_used[m - n + size - 1] = TRUE;
            board[i] = board[n];
            board[n] = m;
            queen( n + 1 );
            r_used[m + n] = l_used[m - n + size - 1] = FALSE;
            board[n] = board[i];
            board[i] = m;
        }
    }
}
