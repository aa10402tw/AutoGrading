#include <stdio.h>

int GCD(int a,int b);

int main(){
    int n,m;
    scanf("%d %d",&n,&m);
    printf("%d",GCD(n,m));
    return 0;
}

int GCD(int a,int b){
    if(a==0) return b;
    else if(b==0) return a;
    if(b>a) GCD(a,b-=a);
    else if(a>b) GCD(a-=b,b);

}
