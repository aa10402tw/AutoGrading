#include <stdio.h>

int GCD(int,int);

int main(){
   int in1,in2;

   scanf("%d%d",&in1,&in2);
   printf("%d",GCD(in1,in2));
}

int GCD(int a,int b){
   if(b==0)
      return a;
   else
      return GCD(b,a%b);
}