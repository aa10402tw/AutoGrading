#include <stdio.h>
int n;
void hanoi(int,char,char,char /*Write your code here */);

int main() {
    /* Write your code here */
    int i;
    n=0;
    scanf("%d",&i);
    hanoi(i,'A','B','C');
    printf("%d",n);
    return 0;
}

void hanoi(int i,char A,char B,char C/* Write your code here */){
    /* Write your code here */
    if(i==1){
        n++;
    }
    else{
        hanoi(i-1,A,C,B);
        hanoi(1,A,B,C);
        hanoi(i-1,B,A,C);
    }
}
