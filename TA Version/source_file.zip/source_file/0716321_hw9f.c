#include<stdio.h>
#include <stdlib.h>
#include <stdbool.h>
int onboard[200],times = 0;
void queens(int row,int n);
int check(int row,int col){
    for(int i = 1;i <= row-1;i++) {
        if(onboard[i] == col)
            return false;
        else if(abs(onboard[i]-col) == abs(i-row))
            return false;
    }
    return true; 
}
int main(void) {
    int n;
    scanf("%i",&n);
    queens(1,n);
    printf("%i\n",times);
    return 0;
}
void queens(int row,int n) {
    for(int col=1;col<=n;++col) {
        if(check(row,col)) {
            onboard[row] = col; 
            if(row == n) 
                times++; 
            else 
            queens(row+1,n);//push下去 媽的之前想解數獨學回朔法學不會ＱＱ
        }
    }
}
