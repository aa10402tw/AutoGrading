#include <stdio.h>

void sort(int n,int in[]);
int binary_search(int m,int n,int in[],int search);


int main(void){
	int n,search;
	scanf("%d",&n);
	int in[n];
	for(int i=0;i<n;i++)scanf("%d",&in[i]);
    sort(n,in);
	scanf("%d",&search);
	printf("%d",binary_search(0,n,in,search));
}

void sort(int n,int in[]){
    int tem;
	for(int i=1;i<n;i++){
        for(int j=0;j<(n-1);j++){
            if(in[j]>in[j+1]){
                tem=in[j+1];
                in[j+1]=in[j];
                in[j]=tem;
            }
        }
	}
}
int binary_search(int m,int n,int in[],int search){
    if(m>n)return -1;
    if(in[(m+n)/2]==search)return ((m+n)/2);
    if(in[(m+n)/2]<search)return binary_search(((m+n)/2)+1,n,in,search);
    if(in[(m+n)/2]>search)return binary_search(m,((m+n)/2)-1,in,search);
}
