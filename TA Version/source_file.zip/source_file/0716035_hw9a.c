#include<stdio.h>

int sum(int);

int main(void)
{
    int x;
    scanf("%d",&x);
    printf("%d",sum(x));

    return 0;
}

int sum(int a)
{
    if(a==1)
        return 1;
    else
        return a+sum(a-1);
}
