#include <stdio.h>

int GCD(int a,int b);

int main(){
    int a,b;
    scanf("%d %d",&a,&b);
    if(a>b){
        int c;
        c=a;
        a=b;
        b=c;
    }
    printf("%d",GCD(a,b));
    return 0;
}

int GCD(int a,int b){
    if(a==0)
        return b;
    else
        return GCD(b%a,a);
}
