#include <stdio.h>
#include<string.h>
int used[1000]={};
char c[1000]={};
char ans[1000][1000]={};
int cnt=0;
void permute(int now,int len);

int main(){

    gets(c);
    permute(0,strlen(c));
    for(int i=0;i<cnt;i++){
        for(int j=1;j<cnt-i;j++){
            if(strcmp(ans[j-1],ans[j])>0){
                char temp[1000];
                strcpy(temp,ans[j-1]);
                strcpy(ans[j-1],ans[j]);
                strcpy(ans[j],temp);
            }
        }
    }
    for(int i=0;i<cnt;i++){
        puts(ans[i]);
    }
}

void permute(int now,int len){
    if(now==len){
        int ok=1;
        for(int i=0;i<cnt;i++){
            if(strcmp(ans[i],ans[cnt])==0){
                ok=0;
                break;
            }
        }
        if(ok){
            cnt++;
            strcpy(ans[cnt],ans[cnt-1]);
        }
        return ;
    }
    for(int i=0;i<len;i++){
        if(!used[i]){
            used[i]=1;
            ans[cnt][now]=c[i];
            permute(now+1,len);
            used[i]=0;
        }
    }
}
