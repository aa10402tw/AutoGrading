#include <stdio.h>

void queens(int num);

int num_n, total;
int *col,*left,*right;
char** board;

int main(void){
    int i, j;

    scanf("%d", &num_n);

    right = malloc(sizeof(int) * (2*num_n-1));
    left = malloc(sizeof(int) * (2*num_n-1));
    col = malloc(sizeof(int) * num_n);
    board = malloc(sizeof(char*) * num_n);

    total = 0;
    for (i = 0; i<num_n; i++){
        col[i] = 1;
        board[i] = malloc(sizeof(char) * num_n);
    }

    for (i = 0; i < 2*num_n - 1; i++){
        right[i] = left[i] = 1;
    }

    queens(0);

    printf("%d", total);

    for (i = 0; i<num_n; i++){
        free(board[i]);
    }

    free(board);
    free(col);
    free(right);
    free(left);

    return 0;
}

void queens(int num){
    if (num < num_n){
        int a,b,c;
        for (a = 0; a<num_n; a++){
                b = a - num + num_n - 1;
                c = a + num;

            if (col[a] && right[b] && left[c]){
                col[a] = right[b] = left[c] = 0;

                queens(num + 1);

                col[a] = right[b] = left[c] = 1;
            }
        }
    }
    else{
        total++;
    }
}
