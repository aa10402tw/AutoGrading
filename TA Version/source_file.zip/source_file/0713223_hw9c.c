#include <stdio.h>
#include <stdlib.h>

#define N 100

int binary_search(int *array, int first, int last, int num/* Write your code here */);
int compare(const void *p, const void *q);

int main(void){
	/* Write your code here */
    int array[N];
    int n, num, ans;
    int i, first, last;

    scanf("%d", &n);
    for(i=0; i<n; i++){
        scanf("%d", &array[i]);
    }
    scanf("%d", &num);

    qsort(array, n, sizeof(array[0]), compare);

    first = 0;
    last = n - 1;

    ans = binary_search(array, first, last, num);

    printf("%d", ans);

    return 0;
}

int binary_search(int *array, int first, int last, int num/* Write your code here */){
   /* Write your code here */
    int n;

    if(first == last && array[first] == num){
        return first;
    }
    if(first > last)
        return -1;

    n = first + last;
    n /= 2;

    //printf("%d %d %d\n", first, last, n);
    if(array[n] > num)
        last = n - 1;
    else if(array[n] < num)
        first = n + 1;
    if(array[n] == num)
        return n;

    return binary_search(array, first, last, num);
}

int compare(const void *p, const void *q)
{
    return *((const int *)p) - *((const int *)q);
}
