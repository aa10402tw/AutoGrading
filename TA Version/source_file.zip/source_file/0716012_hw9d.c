#include <stdio.h>
static int sum=0;

void hanoi(int n,char a,char b,char c);

int main() {
    int n;
    while(scanf("%d",&n)!=EOF){
    hanoi(n,'A','B','C');
    printf("%d\n",sum);
    sum=0;
    }
}

void hanoi(int n,char a,char b,char c){
    if(n==1)
        sum++;
    else{
        hanoi(n-1,a,c,b);
        hanoi(1,a,b,c);
        hanoi(n-1,b,a,c);
    }
}
