#include <stdio.h>

void permute(int, int, char*);
void swap(int, char*);

int main(){
    int len,i,j;
    char alpha[11],temp;
    gets(alpha);
    len = strlen(alpha);
    swap(len, alpha);
    permute(0 , len, alpha);
    return 0;
}

void swap(int n, char* a){
    int i,j,temp;
    for(j=0;j<n;j++){
        for (i = 0; i < n - 1 - j; i++){
            if(a[i] > a[i + 1]){
                temp = a[i];
                a[i] = a[i + 1];
                a[i + 1] = temp;
            }
        }
    }
}


void permute(int ind, int number, char* arr){
    int i;
    char j;
    if(ind == number){
        for(i = 0; i < number; i++)
            printf("%c" , arr[i]);
        printf( "\n" );
    }
    else{
        for(i = ind; i < number; i++){
            j = arr[i];
            arr[i] = arr[ind];
            arr[ind] = j;
            permute(ind+1 , number, arr);
            arr[ind] = arr[i];
            arr[i] = j;
            }
        }
}
