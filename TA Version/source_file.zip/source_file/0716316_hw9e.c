#include <stdio.h>
#include <string.h>
#include <stdbool.h>
void permute(char *,char *,int,bool *);

int main(){ 
    /* Write your code here */
    char str[100],seq[100];
    int n,a,b,buf;
    bool check[100];
	gets(str);
    n=0;
    for(a=0;a<strlen(str);a++){
    	for(b=0;b<strlen(str)-1;b++){
    		if(str[b]>str[b+1]){
    			buf=str[b];
    			str[b]=str[b+1];
    			str[b+1]=buf;
			}
		}
	}
    permute(str,seq,n,check);
    return 0;
}

void permute(char *str,char *seq,int n,bool *check){  
    /* Write your code here */
    int i;
	if(n<strlen(str)){
		for(i=0;i<strlen(str);i++){
			if(!check[i]){
				seq[n]=str[i];
				check[i]=true;
				n++;
			    permute(str,seq,n,check);
			    n--;
			    check[i]=false;
			}
	    }
	    return;
	}
	else{
		for(i=0;i<strlen(str);i++){
			printf("%c",seq[i]);
		}
		printf("\n");
	}
} 
