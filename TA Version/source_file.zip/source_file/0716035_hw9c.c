#include<stdio.h>

int binary_search(int*,int,int,int);
void swap(int*,int*);
void bubble(int*,int);

int main(void)
{
    int n,target;
    scanf("%d",&n);
    int a[n];
    for(int i=0;i<n;i++)
        scanf("%d",&a[i]);
    scanf("%d",&target);

    bubble(a,n);
    printf("%d",binary_search(a,target,0,n));

    return 0;
}

int binary_search(int*a,int x,int i,int n)
{
    if(i==n)
        return -1;
    if(x==*a++)
        return i;
    return binary_search(a,x,i+1,n);
}

void swap(int*a,int*b)
{
    int t;
    t=*a;
    *a=*b;
    *b=t;
}

void bubble(int*a,int n)
{
    int i,j;
    for(i=0;i<n-1;i++)
        for(j=0;j<n-1;j++)
            if(a[j]>a[j+1])
                swap(&a[j],&a[j+1]);
}

