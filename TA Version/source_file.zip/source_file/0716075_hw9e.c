#include <stdio.h>
#include<string.h>
void swap(char *, char *);
void sort(char *, int );
void permute(char *, int);

char result[10];
int used[10]={0};
int j=0;
int main(){
	char str[10];
    scanf("%s",str);
	sort(str, strlen(str));
	permute(str, strlen(str));
	return 0;
}

void swap(char *a, char *b){
	char tmp=*a;
	*a=*b;
	*b=tmp;
	return;
}

void sort(char *num, int n){
	int i;
	for(i=0;i<n;i++){
		for(int g=i+1;g<n;g++){
			if(num[i]>num[g]){
				swap(&num[i],&num[g]);
			}
		}
	}
}

void permute(char *str,int len){
	int i;
	for(i=0;i<len;i++){
		while(used[i]==1) i++;
		if(i!=len){
			used[i]=1;
			result[j++]=str[i];
			if(j==len)
				printf("%s\n",result);
			permute(str,len);
			j--;
			used[i]=0;
		}
	}
}
