#include <stdio.h>

void queens(int i,int n);
int c[15][15];
int ans=0;
int main()
{
    int b;
    int temp=0;
    scanf("%d",&b);
    for(int h=0;h<b;h++){
        for(int k=0;k<b;k++){
          c[h][k]=0;
        }
    }
    queens(temp,b);
    printf("%d",ans);
    return 0;
}

void queens(int i,int n)
{
    int j,temp1,temp2,temp3,temp4,temp5,temp6,time1=0,time2=0;
    for(j=0; j<n; j++)
    {
        if(c[i][j]!=0)
            continue;//make i and j to the place they should go
        temp5=temp3=temp1=i;
        temp6=temp4=temp2=j;
        if(i==n-1)
        {
            ans++;
            return;
        }  //success and go back
        for(temp3=i;temp3<n;temp3++)
            c[temp3][temp4]++;    //column
        for(;temp1<n&&temp2<n;)
        {
            temp1++;
            temp2++;
            if(temp1>=n||temp2>=n)
                break;
            c[temp1][temp2]++;//diagonal right down
        }
        for(;temp5<n&&temp6>=0;)
        {
            temp5++;
            temp6--;
            if(temp6<0||temp5>=n)
                break;
            c[temp5][temp6]++;//diagonal left down
        }


        queens(i+1,n);


        for(temp3=i;temp3<n;temp3++)
            c[temp3][temp4]--;    //column
        for(;temp1>i&&temp2>j;)
        {
             c[temp1][temp2]--;
             temp1--;
            temp2--;//diagonal right down
        }
        for(;temp5>i&&temp6<j;)
        {
            c[temp5][temp6]--;
            temp5--;
            temp6++;
            //diagonal left down

        }
    }
}
